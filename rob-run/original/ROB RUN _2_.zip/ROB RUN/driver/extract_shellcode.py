import struct, sys, os

path = sys.argv[1]
out = sys.argv[2]
data = open(path, 'rb').read()

machine, nsec, tds, symoff, nsym, optsize, chars = struct.unpack_from('<HHIIIHH', data, 0)
print("machine", hex(machine), "sections", nsec, "optsize", optsize)
sec_off = 20 + optsize
sections = []
for i in range(nsec):
    off = sec_off + i * 40
    name = data[off:off+8].rstrip(b'\x00').decode(errors='ignore')
    vsize, vaddr, rawsize, rawptr, relptr, lineptr, nrel, nline, sflags = struct.unpack_from('<IIIIIIHHI', data, off+8)
    sections.append((name, vaddr, rawsize, rawptr, relptr, nrel, sflags))
    print(f"  {name} vaddr={vaddr:x} size={rawsize} rel={nrel} flags={sflags:x}")

target = None
for s in sections:
    if s[0] == '.sc':
        target = s
        break
if not target:
    print("no .sc section")
    sys.exit(1)

name, vaddr, rawsize, rawptr, relptr, nrel, sflags = target
blob = data[rawptr:rawptr+rawsize]
print("blob size", len(blob))

for i in range(nrel):
    roff = relptr + i * 10
    rva, symidx, rtype = struct.unpack_from('<IIH', data, roff)
    print(f"  RELOC at +0x{rva:x} type={rtype} sym={symidx}")

with open(out, 'w', encoding='utf-8') as f:
    f.write("#pragma once\n")
    f.write("static const unsigned char kShellcode[] = {\n")
    for i in range(0, len(blob), 16):
        chunk = blob[i:i+16]
        f.write("    " + ", ".join(f"0x{b:02x}" for b in chunk) + ",\n")
    f.write("};\n")
    f.write(f"static const unsigned int kShellcodeSize = {len(blob)};\n")
print("wrote", out)
