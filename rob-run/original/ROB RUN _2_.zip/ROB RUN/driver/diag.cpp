// C++20, diag.cpp — read-only pre-flight for the kernel injector. No patches, no execution.
#include <windows.h>
#include <shellapi.h>
#include <psapi.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "shell32.lib")

namespace {

constexpr wchar_t kServiceName[] = L"gdrv";
constexpr wchar_t kDevicePath[]  = L"\\\\.\\GIO";
constexpr DWORD   kIoctlMemcpy   = 0xC3502808;
constexpr DWORD   kIoctlAlloc    = 0xC3502800;

using NtQsiFn = LONG(NTAPI*)(ULONG, PVOID, ULONG, PULONG);
NtQsiFn g_ntqsi = nullptr;

struct IoMemcpy { void* dest; void* src; DWORD size; DWORD pad; };

bool is_admin() {
    BOOL admin = FALSE; PSID sid = nullptr; SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
            0, 0, 0, 0, 0, 0, &sid)) {
        CheckTokenMembership(nullptr, sid, &admin);
        FreeSid(sid);
    }
    return admin != FALSE;
}

void relaunch() {
    wchar_t exe[MAX_PATH]{}; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    ShellExecuteW(nullptr, L"runas", exe, nullptr, nullptr, SW_SHOWNORMAL);
}

bool privilege(const wchar_t* name) {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) return false;
    LUID luid{}; bool ok = false;
    if (LookupPrivilegeValueW(nullptr, name, &luid)) {
        TOKEN_PRIVILEGES tp{}; tp.PrivilegeCount = 1; tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        ok = AdjustTokenPrivileges(token, FALSE, &tp, sizeof(tp), nullptr, nullptr) != 0;
    }
    CloseHandle(token);
    return ok;
}

bool ensure_service(const std::wstring& path) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE);
    if (!scm) return false;
    SC_HANDLE svc = CreateServiceW(scm, kServiceName, kServiceName, SERVICE_ALL_ACCESS,
        SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, path.c_str(),
        nullptr, nullptr, nullptr, nullptr, nullptr);
    if (!svc) { DWORD e = GetLastError(); if (e == ERROR_SERVICE_EXISTS) svc = OpenServiceW(scm, kServiceName, SERVICE_ALL_ACCESS); }
    bool ok = false;
    if (svc) {
        if (StartServiceW(svc, 0, nullptr)) ok = true;
        else if (GetLastError() == ERROR_SERVICE_ALREADY_RUNNING) ok = true;
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
    return ok;
}

HANDLE open_driver() {
    return CreateFileW(kDevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
}

bool kread(HANDLE dev, void* dst, uint64_t src, size_t size) {
    auto* d = static_cast<BYTE*>(dst);
    while (size) {
        DWORD chunk = size > 0x1000 ? 0x1000 : static_cast<DWORD>(size);
        IoMemcpy arg{ d, reinterpret_cast<void*>(src), chunk, 0 };
        DWORD ret = 0;
        if (!DeviceIoControl(dev, kIoctlMemcpy, &arg, sizeof(arg), nullptr, 0, &ret, nullptr)) return false;
        d += chunk; src += chunk; size -= chunk;
    }
    return true;
}

uint64_t kread64(HANDLE dev, uint64_t addr) { uint64_t v = 0; kread(dev, &v, addr, 8); return v; }
uint32_t kread32(HANDLE dev, uint64_t addr) { uint32_t v = 0; kread(dev, &v, addr, 4); return v; }

uint64_t g_ntos = 0;

// Parse the in-memory export table of ntoskrnl and resolve one name.
uint32_t export_rva(HANDLE dev, const char* want) {
    uint8_t dos[0x40]{};
    if (!kread(dev, dos, g_ntos, sizeof(dos)) || dos[0] != 'M' || dos[1] != 'Z') return 0;
    uint32_t lfanew = *reinterpret_cast<uint32_t*>(dos + 0x3C);
    uint8_t nt[0x108]{};
    if (!kread(dev, nt, g_ntos + lfanew, sizeof(nt))) return 0;
    if (nt[0] != 'P' || nt[1] != 'E') return 0;
    uint16_t optsize = *reinterpret_cast<uint16_t*>(nt + 20);
    uint64_t opt = g_ntos + lfanew + 24;
    uint32_t exp_rva = 0;
    if (!kread(dev, &exp_rva, opt + 112, 4) || !exp_rva) return 0;
    (void)optsize;

    uint64_t ed_va = g_ntos + exp_rva;
    uint8_t ed[40]{};
    if (!kread(dev, ed, ed_va, 40)) return 0;
    uint32_t nnames = *reinterpret_cast<uint32_t*>(ed + 24);
    uint32_t funcs = *reinterpret_cast<uint32_t*>(ed + 28);
    uint32_t names = *reinterpret_cast<uint32_t*>(ed + 32);
    uint32_t ords = *reinterpret_cast<uint32_t*>(ed + 36);

    for (uint32_t i = 0; i < nnames && i < 8192; ++i) {
        uint32_t name_rva = 0;
        if (!kread(dev, &name_rva, g_ntos + names + i * 4, 4)) return 0;
        char buf[64]{};
        if (!kread(dev, buf, g_ntos + name_rva, sizeof(buf) - 1)) continue;
        if (std::strcmp(buf, want) == 0) {
            uint16_t ord = 0;
            if (!kread(dev, &ord, g_ntos + ords + i * 2, 2)) return 0;
            uint32_t rva = 0;
            if (!kread(dev, &rva, g_ntos + funcs + ord * 4, 4)) return 0;
            return rva;
        }
    }
    return 0;
}

} // namespace

int wmain() {
    if (!is_admin()) { relaunch(); return 0; }
    privilege(L"SeDebugPrivilege");
    privilege(L"SeLockMemoryPrivilege");

    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    g_ntqsi = reinterpret_cast<NtQsiFn>(GetProcAddress(ntdll, "NtQuerySystemInformation"));
    if (!g_ntqsi) { wprintf(L"[!] no NtQuerySystemInformation\n"); return 1; }

    wchar_t exe[MAX_PATH]{}; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir(exe); auto slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir.resize(slash + 1);
    const std::wstring sys = dir + L"gdrv.sys";

    if (!ensure_service(sys)) { wprintf(L"[!] service failed %lu\n", GetLastError()); return 1; }
    HANDLE dev = open_driver();
    if (dev == INVALID_HANDLE_VALUE) { wprintf(L"[!] device failed %lu\n", GetLastError()); return 1; }

    LPVOID bases[1024]{}; DWORD needed = 0;
    EnumDeviceDrivers(bases, sizeof(bases), &needed);
    g_ntos = reinterpret_cast<uint64_t>(bases[0]);
    wprintf(L"[*] ntos base 0x%llx\n", static_cast<unsigned long long>(g_ntos));

    const char* funcs[] = { "PsLookupProcessByProcessId", "KeStackAttachProcess",
        "KeUnstackDetachProcess", "ZwAllocateVirtualMemory", "RtlCreateUserThread", "ObfDereferenceObject" };
    for (auto f : funcs) {
        uint32_t rva = export_rva(dev, f);
        if (rva) wprintf(L"[*] %hs rva 0x%x\n", f, rva);
        else wprintf(L"[!] export %hs not found\n", f);
    }

    uint64_t gdrv_base = 0;
    for (DWORD i = 0; i < needed / sizeof(LPVOID) && i < 1024; ++i) {
        wchar_t name[MAX_PATH]{};
        if (GetDeviceDriverBaseNameW(bases[i], name, MAX_PATH) && _wcsicmp(name, L"gdrv.sys") == 0) {
            gdrv_base = reinterpret_cast<uint64_t>(bases[i]);
            break;
        }
    }
    wprintf(L"[*] gdrv base 0x%llx\n", static_cast<unsigned long long>(gdrv_base));
    if (!gdrv_base) { wprintf(L"[!] gdrv module not found\n"); CloseHandle(dev); return 1; }

    // SYSTEM_HANDLE_INFORMATION
    ULONG size = 0x200000;
    std::vector<uint8_t> buf;
    LONG st = 0;
    for (int tries = 0; tries < 5; ++tries) {
        buf.resize(size);
        st = g_ntqsi(16, buf.data(), size, &size);
        if (st == static_cast<LONG>(0xC0000004)) continue;
        break;
    }
    wprintf(L"[*] handle query status 0x%lx size %lu\n", static_cast<unsigned long>(st), size);

    uint64_t device_obj = 0;
    if (st == 0) {
        uint32_t count = *reinterpret_cast<uint32_t*>(buf.data());
        uint8_t* entries = buf.data() + 8;
        struct Entry {
            uint16_t pid; uint16_t bt; uint8_t type; uint8_t attr; uint16_t handle;
            uint64_t object; uint32_t access; uint32_t pad;
        };
        static_assert(sizeof(Entry) == 0x18, "entry layout");
        const uint32_t self = GetCurrentProcessId();
        const uint16_t target_handle = static_cast<uint16_t>(reinterpret_cast<uintptr_t>(dev));
        for (uint32_t i = 0; i < count; ++i) {
            Entry e{};
            std::memcpy(&e, entries + i * sizeof(Entry), sizeof(e));
            if (e.pid == self && e.handle == target_handle) {
                device_obj = e.object;
                wprintf(L"[*] handle entry type=%u attr=0x%x access=0x%x object=0x%llx\n",
                    e.type, e.attr, e.access, static_cast<unsigned long long>(device_obj));
                break;
            }
        }
    }
    if (!device_obj) { wprintf(L"[!] device object not found\n"); CloseHandle(dev); return 1; }

    auto kernel_ptr = [](uint64_t p) { return p >= 0xFFFF800000000000ull; };
    if (!kernel_ptr(device_obj) || (device_obj & 7)) {
        wprintf(L"[!] device object not a kernel pointer: 0x%llx\n", static_cast<unsigned long long>(device_obj));
        CloseHandle(dev);
        return 1;
    }
    uint16_t dev_type = 0, dev_size = 0;
    kread(dev, &dev_type, device_obj, 2);
    kread(dev, &dev_size, device_obj + 2, 2);
    wprintf(L"[*] device object: type=%u size=0x%x\n", dev_type, dev_size);
    if (dev_type != 3 || dev_size < 0xA0 || dev_size > 0x300) {
        wprintf(L"[!] device object layout mismatch, abort\n");
        CloseHandle(dev);
        return 1;
    }

    const uint64_t driver_obj = kread64(dev, device_obj + 0x8);
    if (!kernel_ptr(driver_obj) || (driver_obj & 7)) {
        wprintf(L"[!] driver object not a kernel pointer: 0x%llx\n", static_cast<unsigned long long>(driver_obj));
        CloseHandle(dev);
        return 1;
    }
    const uint64_t drv_start = kread64(dev, driver_obj + 0x18);
    const uint32_t drv_size = kread32(dev, driver_obj + 0x20);
    wprintf(L"[*] driver obj 0x%llx start=0x%llx size=0x%x\n",
        static_cast<unsigned long long>(driver_obj), static_cast<unsigned long long>(drv_start), drv_size);
    if (drv_start != gdrv_base) {
        wprintf(L"[!] DriverStart does not match EnumDeviceDrivers base, abort\n");
        CloseHandle(dev);
        return 1;
    }

    const uint64_t major_dc = kread64(dev, driver_obj + 0xE0);
    const uint64_t expected_dispatch = gdrv_base + 0x1A20;
    uint8_t prologue[8]{};
    kread(dev, prologue, expected_dispatch, 8);
    static const uint8_t want_prologue[8] = { 0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x08, 0x48 };
    wprintf(L"[*] major[IRP_MJ_DEVICE_CONTROL] 0x%llx expected 0x%llx prologue=%02x%02x%02x%02x\n",
        static_cast<unsigned long long>(major_dc), static_cast<unsigned long long>(expected_dispatch),
        prologue[0], prologue[1], prologue[2], prologue[3]);
    if (major_dc != expected_dispatch || std::memcmp(prologue, want_prologue, sizeof(want_prologue)) != 0) {
        wprintf(L"[!] dispatch mismatch, abort\n");
        CloseHandle(dev);
        return 1;
    }

    // pool alloc + PTE probe
    struct AllocIn { uint64_t size; uint64_t out; } ai{ 0x1000, 0 };
    DWORD ret = 0;
    if (DeviceIoControl(dev, kIoctlAlloc, &ai, sizeof(ai), &ai, sizeof(ai), &ret, nullptr)) {
        const uint64_t pool_va = ai.size; // driver overwrites the input buffer start
        wprintf(L"[*] pool request done ret=%lu first_qword=0x%llx\n", ret,
            static_cast<unsigned long long>(pool_va));
        uint64_t sysproc = kread64(dev, g_ntos + 0xCFC420);
        uint64_t cur = sysproc, self_ep = 0;
        for (int i = 0; i < 4096; ++i) {
            if (kread32(dev, cur + 0x440) == GetCurrentProcessId()) { self_ep = cur; break; }
            uint64_t fl = kread64(dev, cur + 0x448);
            if (!fl) break;
            cur = fl - 0x448;
            if (cur == sysproc) break;
        }
        if (self_ep) {
            const uint64_t cr3 = kread64(dev, self_ep + 0x28);
            wprintf(L"[*] self ep 0x%llx cr3 0x%llx\n", static_cast<unsigned long long>(self_ep),
                static_cast<unsigned long long>(cr3));
            uint64_t pml4e = 0, pdpte = 0, pde = 0, pte = 0;
            kread(dev, &pml4e, (cr3 & ~0xFFFull) + 8 * ((pool_va >> 39) & 0x1FF), 8);
            kread(dev, &pdpte, (pml4e & 0x000FFFFFFFFFF000ull) + 8 * ((pool_va >> 30) & 0x1FF), 8);
            kread(dev, &pde, (pdpte & 0x000FFFFFFFFFF000ull) + 8 * ((pool_va >> 21) & 0x1FF), 8);
            kread(dev, &pte, (pde & 0x000FFFFFFFFFF000ull) + 8 * ((pool_va >> 12) & 0x1FF), 8);
            wprintf(L"[*] pte 0x%llx present=%d rw=%d nx=%d\n", static_cast<unsigned long long>(pte),
                static_cast<int>(pte & 1), static_cast<int>((pte >> 1) & 1), static_cast<int>((pte >> 63) & 1));
        }
    } else {
        wprintf(L"[!] pool alloc failed %lu\n", GetLastError());
    }

    CloseHandle(dev);

    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_ALL_ACCESS);
    if (scm) {
        SC_HANDLE svc = OpenServiceW(scm, kServiceName, SERVICE_STOP | DELETE);
        if (svc) {
            SERVICE_STATUS ss{};
            ControlService(svc, SERVICE_CONTROL_STOP, &ss);
            DeleteService(svc);
            CloseServiceHandle(svc);
            wprintf(L"[*] service stopped and deleted\n");
        }
        CloseServiceHandle(scm);
    }

    wprintf(L"[*] diag done, no patches applied\n");
    return 0;
}
