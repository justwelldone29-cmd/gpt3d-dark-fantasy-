// C++20, inject.cpp — kernel-side injector for internal.dll via gdrv dispatch patch.
// Default mode is DRY: every check runs, nothing is patched. --go performs the patch.
#include <windows.h>
#include <shellapi.h>
#include <psapi.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <cstddef>

#include "shellcode_blob.h"

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "shell32.lib")

namespace {

constexpr wchar_t kServiceName[] = L"gdrv";
constexpr wchar_t kDevicePath[]  = L"\\\\.\\GIO";
constexpr DWORD   kIoctlMemcpy   = 0xC3502808;
constexpr DWORD   kIoctlAlloc    = 0xC3502800;
constexpr DWORD   kIoctlPhysMap  = 0xC3502004;
constexpr DWORD   kIoctlPhysUnmap= 0xC3502008;

constexpr uint64_t kPsInitialSystemProcess = 0xCFC420;
constexpr uint64_t kEprocessDirectoryTableBase = 0x28;
constexpr uint64_t kEprocessUniqueProcessId = 0x440;
constexpr uint64_t kEprocessActiveLinks = 0x448;
constexpr uint64_t kEprocessPeb = 0x550;

constexpr uint64_t kGdrvDispatchRva = 0x1A20;
constexpr uint64_t kPoolSize = 0x3000;
constexpr uint64_t kShellcodeOff = 0x200;
constexpr uint64_t kCtxOff = 0x1000;

using NtQsiFn = LONG(NTAPI*)(ULONG, PVOID, ULONG, PULONG);
using NtQipFn = LONG(NTAPI*)(HANDLE, ULONG, PVOID, ULONG, PULONG);
NtQsiFn g_ntqsi = nullptr;
NtQipFn g_ntqip = nullptr;

struct IoMemcpy { void* dest; void* src; DWORD size; DWORD pad; };
struct PhysMap { uint32_t iface; uint32_t bus; uint64_t addr; uint32_t addressSpace; uint32_t length; };
struct PhysUnmap { uint64_t va; uint64_t size; };

#pragma pack(push, 8)
struct Ctx {
    uint64_t orig_dispatch;
    uint64_t fn_lookup;
    uint64_t fn_open;
    uint64_t fn_alloc;
    uint64_t fn_thread;
    uint64_t fn_close;
    uint64_t fn_deref;
    uint64_t pid;
    uint64_t loadlibrary;
    uint64_t path_len;
    uint64_t status;
    uint64_t ps_process_type;
    uint16_t path[128];
};
#pragma pack(pop)
static_assert(offsetof(Ctx, path) == 96, "ctx layout");
static_assert(offsetof(Ctx, status) == 80, "ctx layout");

bool is_kernel_pointer(uint64_t p) {
    return p >= 0xFFFF800000000000ull;
}

bool is_admin() {
    BOOL admin = FALSE; PSID sid = nullptr; SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
            0, 0, 0, 0, 0, 0, &sid)) {
        CheckTokenMembership(nullptr, sid, &admin);
        FreeSid(sid);
    }
    return admin != FALSE;
}

bool privilege(const wchar_t* name) {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) return false;
    LUID luid{}; bool ok = false;
    if (LookupPrivilegeValueW(nullptr, name, &luid)) {
        TOKEN_PRIVILEGES tp{}; tp.PrivilegeCount = 1; tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        ok = AdjustTokenPrivileges(token, FALSE, &tp, sizeof(tp), nullptr, nullptr) != 0;
    }
    CloseHandle(token);
    return ok;
}

bool ensure_service(const std::wstring& path) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE);
    if (!scm) return false;
    SC_HANDLE svc = CreateServiceW(scm, kServiceName, kServiceName, SERVICE_ALL_ACCESS,
        SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, path.c_str(),
        nullptr, nullptr, nullptr, nullptr, nullptr);
    if (!svc) { DWORD e = GetLastError(); if (e == ERROR_SERVICE_EXISTS) svc = OpenServiceW(scm, kServiceName, SERVICE_ALL_ACCESS); }
    bool ok = false;
    if (svc) {
        if (StartServiceW(svc, 0, nullptr)) ok = true;
        else if (GetLastError() == ERROR_SERVICE_ALREADY_RUNNING) ok = true;
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
    return ok;
}

void remove_service() {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_ALL_ACCESS);
    if (!scm) return;
    SC_HANDLE svc = OpenServiceW(scm, kServiceName, SERVICE_STOP | DELETE);
    if (svc) {
        SERVICE_STATUS ss{};
        ControlService(svc, SERVICE_CONTROL_STOP, &ss);
        DeleteService(svc);
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
}

HANDLE open_driver() {
    return CreateFileW(kDevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
}

bool kread(HANDLE dev, void* dst, uint64_t src, size_t size) {
    auto* d = static_cast<BYTE*>(dst);
    while (size) {
        DWORD chunk = size > 0x1000 ? 0x1000 : static_cast<DWORD>(size);
        IoMemcpy arg{ d, reinterpret_cast<void*>(src), chunk, 0 };
        DWORD ret = 0;
        if (!DeviceIoControl(dev, kIoctlMemcpy, &arg, sizeof(arg), nullptr, 0, &ret, nullptr)) return false;
        d += chunk; src += chunk; size -= chunk;
    }
    return true;
}

bool kwrite(HANDLE dev, uint64_t dst, const void* src, size_t size) {
    auto* s = static_cast<const uint8_t*>(src);
    while (size) {
        DWORD chunk = size > 0x1000 ? 0x1000 : static_cast<DWORD>(size);
        IoMemcpy arg{ reinterpret_cast<void*>(dst), const_cast<uint8_t*>(s), chunk, 0 };
        DWORD ret = 0;
        if (!DeviceIoControl(dev, kIoctlMemcpy, &arg, sizeof(arg), nullptr, 0, &ret, nullptr)) return false;
        dst += chunk; s += chunk; size -= chunk;
    }
    return true;
}

uint64_t kread64(HANDLE dev, uint64_t addr) { uint64_t v = 0; kread(dev, &v, addr, 8); return v; }
uint32_t kread32(HANDLE dev, uint64_t addr) { uint32_t v = 0; kread(dev, &v, addr, 4); return v; }

uint64_t g_ntos = 0;

uint32_t export_rva(HANDLE dev, const char* want) {
    uint8_t dos[0x40]{};
    if (!kread(dev, dos, g_ntos, sizeof(dos)) || dos[0] != 'M' || dos[1] != 'Z') return 0;
    uint32_t lfanew = *reinterpret_cast<uint32_t*>(dos + 0x3C);
    uint8_t nt[0x108]{};
    if (!kread(dev, nt, g_ntos + lfanew, sizeof(nt))) return 0;
    if (nt[0] != 'P' || nt[1] != 'E') return 0;
    uint32_t exp_rva = 0;
    if (!kread(dev, &exp_rva, g_ntos + lfanew + 24 + 112, 4) || !exp_rva) return 0;
    uint8_t ed[40]{};
    if (!kread(dev, ed, g_ntos + exp_rva, 40)) return 0;
    uint32_t nnames = *reinterpret_cast<uint32_t*>(ed + 24);
    uint32_t funcs = *reinterpret_cast<uint32_t*>(ed + 28);
    uint32_t names = *reinterpret_cast<uint32_t*>(ed + 32);
    uint32_t ords = *reinterpret_cast<uint32_t*>(ed + 36);
    for (uint32_t i = 0; i < nnames && i < 8192; ++i) {
        uint32_t name_rva = 0;
        if (!kread(dev, &name_rva, g_ntos + names + i * 4, 4)) return 0;
        char buf[64]{};
        if (!kread(dev, buf, g_ntos + name_rva, sizeof(buf) - 1)) continue;
        if (std::strcmp(buf, want) == 0) {
            uint16_t ord = 0;
            if (!kread(dev, &ord, g_ntos + ords + i * 2, 2)) return 0;
            uint32_t rva = 0;
            if (!kread(dev, &rva, g_ntos + funcs + ord * 4, 4)) return 0;
            return rva;
        }
    }
    return 0;
}

uint64_t map_phys(HANDLE dev, uint64_t pa, uint32_t size) {
    PhysMap m{ 0, 0, pa, 0, size };
    DWORD ret = 0;
    if (!DeviceIoControl(dev, kIoctlPhysMap, &m, sizeof(m), &m, sizeof(m), &ret, nullptr)) return 0;
    uint64_t va = 0;
    std::memcpy(&va, &m, 8);
    return va;
}

void unmap_phys(HANDLE dev, uint64_t va) {
    PhysUnmap u{ va, 0 };
    DWORD ret = 0;
    DeviceIoControl(dev, kIoctlPhysUnmap, &u, sizeof(u), nullptr, 0, &ret, nullptr);
}

bool phys_read(HANDLE dev, uint64_t pa, void* out, size_t size) {
    auto* o = static_cast<uint8_t*>(out);
    while (size) {
        uint64_t page = pa & ~0xFFFull;
        size_t off = static_cast<size_t>(pa & 0xFFF);
        size_t n = (size < 0x1000 - off) ? size : 0x1000 - off;
        uint64_t va = map_phys(dev, page, 0x1000);
        if (!va) return false;
        std::memcpy(o, reinterpret_cast<void*>(va + off), n);
        unmap_phys(dev, va);
        o += n; pa += n; size -= n;
    }
    return true;
}

uint64_t va_to_pa(HANDLE dev, uint64_t cr3, uint64_t va) {
    uint64_t pml4e = 0, pdpte = 0, pde = 0, pte = 0;
    uint64_t pml4 = cr3 & ~0xFFFull;
    if (!phys_read(dev, pml4 + 8 * ((va >> 39) & 0x1FF), &pml4e, 8) || !(pml4e & 1)) return 0;
    uint64_t pdpt = pml4e & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pdpt + 8 * ((va >> 30) & 0x1FF), &pdpte, 8) || !(pdpte & 1)) return 0;
    if (pdpte & 0x80) return (pdpte & 0x000FFFFFC0000000ull) + (va & 0x3FFFFFFFull);
    uint64_t pd = pdpte & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pd + 8 * ((va >> 21) & 0x1FF), &pde, 8) || !(pde & 1)) return 0;
    if (pde & 0x80) return (pde & 0x000FFFFFFFE00000ull) + (va & 0x1FFFFFull);
    uint64_t pt = pde & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pt + 8 * ((va >> 12) & 0x1FF), &pte, 8) || !(pte & 1)) return 0;
    return (pte & 0x000FFFFFFFFFF000ull) + (va & 0xFFFull);
}

bool read_process(HANDLE dev, uint64_t cr3, uint64_t va, void* out, size_t size) {
    auto* o = static_cast<uint8_t*>(out);
    while (size) {
        uint64_t pa = va_to_pa(dev, cr3, va);
        if (!pa) return false;
        size_t off = static_cast<size_t>(va & 0xFFF);
        size_t n = (size < 0x1000 - off) ? size : 0x1000 - off;
        if (!phys_read(dev, pa, o, n)) return false;
        o += n; va += n; size -= n;
    }
    return true;
}

uint64_t find_eprocess(HANDLE dev, DWORD pid) {
    uint64_t sys = kread64(dev, g_ntos + kPsInitialSystemProcess);
    if (!sys) return 0;
    uint64_t cur = sys;
    for (int i = 0; i < 8192; ++i) {
        if (kread32(dev, cur + kEprocessUniqueProcessId) == pid) return cur;
        uint64_t fl = kread64(dev, cur + kEprocessActiveLinks);
        if (!fl) return 0;
        cur = fl - kEprocessActiveLinks;
        if (cur == sys) return 0;
    }
    return 0;
}

DWORD find_pid(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{ sizeof(pe) };
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

uint64_t target_kernel32_base(HANDLE dev, uint64_t cr3, uint64_t peb) {
    uint8_t ldr_ptr[8]{};
    if (!read_process(dev, cr3, peb + 0x18, ldr_ptr, 8)) return 0;
    uint64_t ldr = *reinterpret_cast<uint64_t*>(ldr_ptr);
    if (!ldr) return 0;
    uint64_t head = ldr + 0x10;
    uint64_t entry = 0;
    if (!read_process(dev, cr3, head, &entry, 8)) return 0;
    uint64_t first = entry;
    for (int i = 0; i < 256; ++i) {
        uint64_t dll_base = 0;
        if (!read_process(dev, cr3, entry + 0x30, &dll_base, 8)) return 0;
        uint16_t len = 0;
        uint64_t buf = 0;
        if (!read_process(dev, cr3, entry + 0x58, &len, 2)) return 0;
        if (!read_process(dev, cr3, entry + 0x60, &buf, 8)) return 0;
        if (len > 0 && len < 128 && buf) {
            wchar_t name[64]{};
            if (read_process(dev, cr3, buf, name, len)) {
                if (_wcsicmp(name, L"kernel32.dll") == 0) return dll_base;
            }
        }
        if (!read_process(dev, cr3, entry, &entry, 8)) return 0;
        if (entry == first || !entry) break;
    }
    return 0;
}

std::vector<uint8_t> build_trampoline(uint64_t ctx, uint64_t sc) {
    std::vector<uint8_t> b;
    auto push = [&](uint8_t v) { b.push_back(v); };
    auto imm64 = [&](uint8_t op, uint64_t v) {
        b.push_back(0x48); b.push_back(op);
        for (int i = 0; i < 8; ++i) b.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xFF));
    };
    push(0x51);                       // push rcx
    push(0x52);                       // push rdx
    b.insert(b.end(), { 0x48, 0x83, 0xEC, 0x28 }); // sub rsp, 0x28 (shadow space)
    imm64(0xB9, ctx);                 // mov rcx, ctx
    imm64(0xB8, sc);                  // mov rax, sc
    b.insert(b.end(), { 0xFF, 0xD0 }); // call rax
    b.insert(b.end(), { 0x48, 0x83, 0xC4, 0x28 }); // add rsp, 0x28
    push(0x5A);                       // pop rdx
    push(0x59);                       // pop rcx
    b.push_back(0x48); b.push_back(0xA1); // mov rax, [ctx]
    for (int i = 0; i < 8; ++i) b.push_back(static_cast<uint8_t>((ctx >> (8 * i)) & 0xFF));
    b.insert(b.end(), { 0xFF, 0xE0 }); // jmp rax
    return b;
}

} // namespace

int wmain(int argc, wchar_t** argv) {
    const bool go = (argc > 1 && _wcsicmp(argv[1], L"--go") == 0);
    if (!is_admin()) {
        wprintf(L"[!] run elevated (UAC). mode=%ls\n", go ? L"GO" : L"DRY");
        return 1;
    }
    privilege(L"SeDebugPrivilege");
    privilege(L"SeLockMemoryPrivilege");

    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    g_ntqsi = reinterpret_cast<NtQsiFn>(GetProcAddress(ntdll, "NtQuerySystemInformation"));
    g_ntqip = reinterpret_cast<NtQipFn>(GetProcAddress(ntdll, "NtQueryInformationProcess"));
    if (!g_ntqsi || !g_ntqip) { wprintf(L"[!] ntdll imports\n"); return 1; }

    wchar_t exe[MAX_PATH]{}; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir(exe); auto slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir.resize(slash + 1);

    const std::wstring dll_path = L"C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.dll";
    const size_t path_len = dll_path.size() + 1;
    if (path_len > 128) { wprintf(L"[!] path too long\n"); return 1; }
    if (GetFileAttributesW(dll_path.c_str()) == INVALID_FILE_ATTRIBUTES) {
        wprintf(L"[!] internal.dll missing\n"); return 1;
    }

    const DWORD pid = find_pid(L"ROB RUN.exe");
    if (!pid) { wprintf(L"[!] ROB RUN.exe not running\n"); return 1; }
    wprintf(L"[*] target pid=%lu dll=%ls\n", pid, dll_path.c_str());

    if (!ensure_service(dir + L"gdrv.sys")) { wprintf(L"[!] service failed %lu\n", GetLastError()); return 1; }
    HANDLE dev = open_driver();
    if (dev == INVALID_HANDLE_VALUE) { wprintf(L"[!] device failed %lu\n", GetLastError()); remove_service(); return 1; }

    LPVOID bases[1024]{}; DWORD needed = 0;
    EnumDeviceDrivers(bases, sizeof(bases), &needed);
    g_ntos = reinterpret_cast<uint64_t>(bases[0]);

    const uint32_t rva_lookup = export_rva(dev, "PsLookupProcessByProcessId");
    const uint32_t rva_open = export_rva(dev, "ObOpenObjectByPointer");
    const uint32_t rva_alloc = export_rva(dev, "ZwAllocateVirtualMemory");
    const uint32_t rva_thread = export_rva(dev, "RtlCreateUserThread");
    const uint32_t rva_close = export_rva(dev, "ZwClose");
    const uint32_t rva_deref = export_rva(dev, "ObfDereferenceObject");
    wprintf(L"[*] exports: %x %x %x %x %x %x\n", rva_lookup, rva_open, rva_alloc, rva_thread, rva_close, rva_deref);
    // Verified against ntoskrnl 10.0.19041.6456; abort if the running kernel differs.
    if (rva_lookup != 0x625CA0 || rva_open != 0x653F10 || rva_alloc != 0x3F9D70 ||
        rva_thread != 0x90FF30 || rva_close != 0x3F9C50 || rva_deref != 0x2CB830) {
        wprintf(L"[!] kernel export RVAs differ from the verified build, abort\n");
        CloseHandle(dev); remove_service(); return 1;
    }
    const uint64_t ps_process_type = kread64(dev, g_ntos + 0xCFC410);
    wprintf(L"[*] PsProcessType 0x%llx\n", static_cast<unsigned long long>(ps_process_type));
    if (!is_kernel_pointer(ps_process_type)) {
        wprintf(L"[!] PsProcessType invalid, abort\n"); CloseHandle(dev); remove_service(); return 1;
    }

    uint64_t gdrv_base = 0;
    for (DWORD i = 0; i < needed / sizeof(LPVOID) && i < 1024; ++i) {
        wchar_t name[MAX_PATH]{};
        if (GetDeviceDriverBaseNameW(bases[i], name, MAX_PATH) && _wcsicmp(name, L"gdrv.sys") == 0) {
            gdrv_base = reinterpret_cast<uint64_t>(bases[i]); break;
        }
    }
    if (!gdrv_base) { wprintf(L"[!] gdrv base not found\n"); CloseHandle(dev); remove_service(); return 1; }

    // handle -> device -> driver
    ULONG hsize = 0x200000;
    std::vector<uint8_t> hbuf;
    LONG hst = 0;
    for (int i = 0; i < 5; ++i) {
        hbuf.resize(hsize);
        hst = g_ntqsi(16, hbuf.data(), hsize, &hsize);
        if ((hst & 0xFFFFFFFF) == 0xC0000004) continue;
        break;
    }
    uint64_t device_obj = 0;
    if (hst == 0) {
        uint32_t count = *reinterpret_cast<uint32_t*>(hbuf.data());
        uint8_t* entries = hbuf.data() + 8;
        struct Entry { uint16_t pid; uint16_t bt; uint8_t type; uint8_t attr; uint16_t handle; uint64_t object; uint32_t access; uint32_t pad; };
        const uint32_t self = GetCurrentProcessId();
        const uint16_t target_handle = static_cast<uint16_t>(reinterpret_cast<uintptr_t>(dev));
        for (uint32_t i = 0; i < count; ++i) {
            Entry e{};
            std::memcpy(&e, entries + i * sizeof(Entry), sizeof(e));
            if (e.pid == self && e.handle == target_handle) { device_obj = e.object; break; }
        }
    }
    if (!device_obj) { wprintf(L"[!] device object not found\n"); CloseHandle(dev); remove_service(); return 1; }

    auto kernel_ptr = [](uint64_t p) { return p >= 0xFFFF800000000000ull; };
    // The handle points at a FILE_OBJECT; DeviceObject is at FILE_OBJECT+0x8.
    const uint64_t file_obj = device_obj;
    if (!kernel_ptr(file_obj) || (file_obj & 7)) { wprintf(L"[!] bad file object\n"); CloseHandle(dev); remove_service(); return 1; }
    uint16_t file_type = 0, file_size = 0;
    kread(dev, &file_type, file_obj, 2);
    kread(dev, &file_size, file_obj + 2, 2);
    wprintf(L"[*] file object type=%u size=0x%x\n", file_type, file_size);
    if (file_type != 5 || file_size < 0xA0 || file_size > 0x300) {
        wprintf(L"[!] file object layout, abort\n"); CloseHandle(dev); remove_service(); return 1;
    }

    const uint64_t device_obj2 = kread64(dev, file_obj + 0x8);
    if (!kernel_ptr(device_obj2) || (device_obj2 & 7)) { wprintf(L"[!] bad device object\n"); CloseHandle(dev); remove_service(); return 1; }
    uint16_t dev_type = 0, dev_size = 0;
    kread(dev, &dev_type, device_obj2, 2);
    kread(dev, &dev_size, device_obj2 + 2, 2);
    wprintf(L"[*] device object type=%u size=0x%x\n", dev_type, dev_size);
    if (dev_type != 3 || dev_size < 0xA0 || dev_size > 0x300) { wprintf(L"[!] device layout\n"); CloseHandle(dev); remove_service(); return 1; }

    const uint64_t driver_obj = kread64(dev, device_obj2 + 8);
    if (!kernel_ptr(driver_obj) || (driver_obj & 7)) { wprintf(L"[!] bad driver obj\n"); CloseHandle(dev); remove_service(); return 1; }
    const uint64_t drv_start = kread64(dev, driver_obj + 0x18);
    if (drv_start != gdrv_base) { wprintf(L"[!] DriverStart mismatch\n"); CloseHandle(dev); remove_service(); return 1; }
    const uint64_t major_dc = kread64(dev, driver_obj + 0xE0);
    const uint64_t expected = gdrv_base + kGdrvDispatchRva;
    uint8_t prologue[8]{};
    kread(dev, prologue, expected, 8);
    static const uint8_t want_prologue[8] = { 0x48, 0x8B, 0xC4, 0x48, 0x89, 0x58, 0x08, 0x48 };
    if (major_dc != expected || std::memcmp(prologue, want_prologue, 8) != 0) {
        wprintf(L"[!] dispatch mismatch 0x%llx vs 0x%llx prologue %02x%02x\n",
            static_cast<unsigned long long>(major_dc), static_cast<unsigned long long>(expected), prologue[0], prologue[1]);
        CloseHandle(dev); remove_service(); return 1;
    }
    wprintf(L"[*] driver obj 0x%llx dispatch 0x%llx verified\n",
        static_cast<unsigned long long>(driver_obj), static_cast<unsigned long long>(major_dc));

    // target process info
    const uint64_t target_ep = find_eprocess(dev, pid);
    if (!target_ep) { wprintf(L"[!] target EPROCESS not found\n"); CloseHandle(dev); remove_service(); return 1; }
    const uint64_t cr3 = kread64(dev, target_ep + kEprocessDirectoryTableBase);
    const uint64_t peb = kread64(dev, target_ep + kEprocessPeb);
    const uint64_t section_base = kread64(dev, target_ep + 0x520);
    wprintf(L"[*] target ep 0x%llx cr3 0x%llx peb 0x%llx base 0x%llx\n",
        static_cast<unsigned long long>(target_ep), static_cast<unsigned long long>(cr3),
        static_cast<unsigned long long>(peb), static_cast<unsigned long long>(section_base));

    // Cross-check PEB against NtQueryInformationProcess and validate the read path.
    struct PROCESS_BASIC_INFORMATION { void* Reserved1; void* PebBaseAddress; void* Reserved2[2]; uintptr_t UniqueProcessId; void* Reserved3; } pbi{};
    HANDLE hp = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    ULONG rl = 0;
    LONG qst = hp ? g_ntqip(hp, 0, &pbi, sizeof(pbi), &rl) : -1;
    if (hp) CloseHandle(hp);
    wprintf(L"[*] query peb 0x%llx status 0x%lx\n", static_cast<unsigned long long>(reinterpret_cast<uint64_t>(pbi.PebBaseAddress)), static_cast<unsigned long>(qst));
    if (qst != 0 || reinterpret_cast<uint64_t>(pbi.PebBaseAddress) != peb) {
        wprintf(L"[!] PEB cross-check failed, abort\n"); CloseHandle(dev); remove_service(); return 1;
    }
    uint16_t mz = 0;
    if (!read_process(dev, cr3, section_base, &mz, 2) || mz != 0x5A4D) {
        wprintf(L"[!] target image read failed (mz=0x%x), abort\n", mz);
        CloseHandle(dev); remove_service(); return 1;
    }
    wprintf(L"[*] target image verified (MZ)\n");

    const uint64_t tk32 = target_kernel32_base(dev, cr3, peb);
    HMODULE ok32 = GetModuleHandleW(L"kernel32.dll");
    const uint64_t loadlibrary = tk32 + (reinterpret_cast<uint64_t>(GetProcAddress(ok32, "LoadLibraryW")) - reinterpret_cast<uint64_t>(ok32));
    wprintf(L"[*] target kernel32 0x%llx LoadLibraryW 0x%llx\n",
        static_cast<unsigned long long>(tk32), static_cast<unsigned long long>(loadlibrary));
    if (!tk32) { wprintf(L"[!] kernel32 lookup failed\n"); CloseHandle(dev); remove_service(); return 1; }

    // pool allocation
    struct AllocIn { uint64_t size; uint64_t out; } ai{ kPoolSize, 0 };
    DWORD aret = 0;
    if (!DeviceIoControl(dev, kIoctlAlloc, &ai, sizeof(ai), &ai, sizeof(ai), &aret, nullptr)) {
        wprintf(L"[!] pool alloc failed %lu\n", GetLastError()); CloseHandle(dev); remove_service(); return 1;
    }
    const uint64_t pool = ai.size;
    wprintf(L"[*] pool va 0x%llx ret=%lu\n", static_cast<unsigned long long>(pool), aret);
    if (!kernel_ptr(pool)) { wprintf(L"[!] bad pool va\n"); CloseHandle(dev); remove_service(); return 1; }

    // build trampoline + ctx + shellcode
    const uint64_t sc_va = pool + kShellcodeOff;
    const uint64_t ctx_va = pool + kCtxOff;
    auto tramp = build_trampoline(ctx_va, sc_va);
    if (kShellcodeSize + kShellcodeOff > kCtxOff || sizeof(Ctx) > kPoolSize - kCtxOff) {
        wprintf(L"[!] blob does not fit\n"); CloseHandle(dev); remove_service(); return 1;
    }

    Ctx ctx{};
    ctx.orig_dispatch = major_dc;
    ctx.fn_lookup = g_ntos + rva_lookup;
    ctx.fn_open = g_ntos + rva_open;
    ctx.fn_alloc = g_ntos + rva_alloc;
    ctx.fn_thread = g_ntos + rva_thread;
    ctx.fn_close = g_ntos + rva_close;
    ctx.fn_deref = g_ntos + rva_deref;
    ctx.pid = pid;
    ctx.loadlibrary = loadlibrary;
    ctx.path_len = path_len;
    ctx.status = 0xFFFFFFFFFFFFFFFFull;
    ctx.ps_process_type = ps_process_type;
    for (size_t i = 0; i < path_len; ++i) ctx.path[i] = static_cast<uint16_t>(dll_path[i]);

    if (!kwrite(dev, pool, tramp.data(), tramp.size()) ||
        !kwrite(dev, sc_va, kShellcode, kShellcodeSize) ||
        !kwrite(dev, ctx_va, &ctx, sizeof(ctx))) {
        wprintf(L"[!] kernel write failed\n"); CloseHandle(dev); remove_service(); return 1;
    }
    uint8_t rb[16]{};
    uint64_t rb_ctx = 0;
    kread(dev, rb, pool, sizeof(rb));
    kread(dev, &rb_ctx, ctx_va + offsetof(Ctx, orig_dispatch), 8);
    if (std::memcmp(rb, tramp.data(), sizeof(rb)) != 0 || rb_ctx != major_dc) {
        wprintf(L"[!] read-back mismatch, abort\n"); CloseHandle(dev); remove_service(); return 1;
    }
    wprintf(L"[*] staged and verified: trampoline=%zu shellcode=%u ctx=%zu\n", tramp.size(), kShellcodeSize, sizeof(ctx));

    // NX check on pool page via our own CR3
    const uint64_t self_ep = find_eprocess(dev, GetCurrentProcessId());
    if (!self_ep) { wprintf(L"[!] self EPROCESS not found\n"); CloseHandle(dev); remove_service(); return 1; }
    const uint64_t self_cr3 = kread64(dev, self_ep + kEprocessDirectoryTableBase);
    uint64_t pml4e = 0, pdpte = 0, pde = 0, pte = 0;
    kread(dev, &pml4e, (self_cr3 & ~0xFFFull) + 8 * ((pool >> 39) & 0x1FF), 8);
    kread(dev, &pdpte, (pml4e & 0x000FFFFFFFFFF000ull) + 8 * ((pool >> 30) & 0x1FF), 8);
    kread(dev, &pde, (pdpte & 0x000FFFFFFFFFF000ull) + 8 * ((pool >> 21) & 0x1FF), 8);
    kread(dev, &pte, (pde & 0x000FFFFFFFFFF000ull) + 8 * ((pool >> 12) & 0x1FF), 8);
    wprintf(L"[*] pool pte 0x%llx present=%d rw=%d nx=%d\n", static_cast<unsigned long long>(pte),
        static_cast<int>(pte & 1), static_cast<int>((pte >> 1) & 1), static_cast<int>((pte >> 63) & 1));
    if (!(pte & 1) || (pte >> 63) & 1) {
        wprintf(L"[!] pool page not executable, abort (no patch)\n");
        CloseHandle(dev); remove_service(); return 1;
    }

    if (!go) {
        wprintf(L"[*] DRY RUN OK: all checks passed, patch NOT applied. rerun with --go\n");
        CloseHandle(dev); remove_service(); return 0;
    }

    // patch dispatch
    uint64_t tramp_va = pool;
    if (!kwrite(dev, driver_obj + 0xE0, &tramp_va, 8)) {
        wprintf(L"[!] patch write failed\n"); CloseHandle(dev); remove_service(); return 1;
    }
    wprintf(L"[*] dispatch patched -> 0x%llx, calling...\n", static_cast<unsigned long long>(tramp_va));

    uint8_t dummy[8]{};
    DWORD dret = 0;
    BOOL io = DeviceIoControl(dev, 0xDEADBEEF, dummy, sizeof(dummy), dummy, sizeof(dummy), &dret, nullptr);
    wprintf(L"[*] ioctl returned %d err %lu\n", io, GetLastError());

    // restore no matter what
    uint64_t restore = major_dc;
    kwrite(dev, driver_obj + 0xE0, &restore, 8);
    const uint64_t check = kread64(dev, driver_obj + 0xE0);
    wprintf(L"[*] dispatch restored: 0x%llx (%s)\n", static_cast<unsigned long long>(check),
        check == major_dc ? L"ok" : L"MISMATCH");

    const uint64_t status = kread64(dev, ctx_va + offsetof(Ctx, status));
    wprintf(L"[*] shellcode status 0x%llx\n", static_cast<unsigned long long>(status));

    CloseHandle(dev);
    remove_service();
    wprintf(L"[*] done. driver unloaded\n");
    return 0;
}
