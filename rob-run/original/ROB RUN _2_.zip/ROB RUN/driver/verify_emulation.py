# verify_emulation.py — Unicorn pre-flight v2 (handle-based shellcode).
import struct
from unicorn import *
from unicorn.x86_const import *

SC_OBJ = r"C:\Users\sss\Desktop\ROB RUN\driver\shellcode.obj"

def load_sc():
    obj = open(SC_OBJ, "rb").read()
    machine, nsec, tds, symoff, nsym, optsize, chars = struct.unpack_from('<HHIIIHH', obj, 0)
    sec_off = 20 + optsize
    for i in range(nsec):
        off = sec_off + i * 40
        name = obj[off:off+8].rstrip(b'\x00').decode(errors='ignore')
        vsize, vaddr, rawsize, rawptr, relptr, lineptr, nrel, nline, sflags = struct.unpack_from('<IIIIIIHHI', obj, off+8)
        if name == '.sc':
            return obj[rawptr:rawptr+rawsize], nrel
    raise RuntimeError("no .sc")

SC, RELOCS = load_sc()
print("shellcode bytes:", len(SC), "relocs:", RELOCS)

# ---------- trampoline ----------
def build_trampoline(ctx_addr, sc_addr):
    b = bytearray()
    b += b"\x51"
    b += b"\x52"
    b += b"\x48\x83\xEC\x28"
    b += b"\x48\xB9" + struct.pack('<Q', ctx_addr)
    b += b"\x48\xB8" + struct.pack('<Q', sc_addr)
    b += b"\xFF\xD0"
    b += b"\x48\x83\xC4\x28"
    b += b"\x5A"
    b += b"\x59"
    b += b"\x48\xA1" + struct.pack('<Q', ctx_addr)
    b += b"\xFF\xE0"
    return bytes(b)

TRAMP = build_trampoline(0x40000, 0x20000)
print("trampoline bytes:", len(TRAMP))

mu = Uc(UC_ARCH_X86, UC_MODE_64)
mu.mem_map(0x10000, 0x1000)
mu.mem_map(0x20000, 0x1000)
mu.mem_map(0x30000, 0x1000)
mu.mem_map(0x40000, 0x1000)
mu.mem_map(0x50000, 0x10000)
mu.mem_write(0x10000, TRAMP)
mu.mem_write(0x20000, b"\xC3")
mu.mem_write(0x30000, b"\xF4")
mu.mem_write(0x40000, struct.pack('<Q', 0x30000))
STACK = 0x60000 - 0x108
state = {"sc_rcx": None, "sc_rsp": None, "orig_rcx": None, "orig_rdx": None}

def hook_t(uc, addr, size, data):
    if addr == 0x20000:
        state["sc_rcx"] = uc.reg_read(UC_X86_REG_RCX)
        state["sc_rsp"] = uc.reg_read(UC_X86_REG_RSP)
    elif addr == 0x30000:
        state["orig_rcx"] = uc.reg_read(UC_X86_REG_RCX)
        state["orig_rdx"] = uc.reg_read(UC_X86_REG_RDX)
        uc.emu_stop()

mu.hook_add(UC_HOOK_CODE, hook_t)
mu.reg_write(UC_X86_REG_RSP, STACK)
mu.mem_write(STACK, struct.pack('<Q', 0xDEADBEEF))
mu.reg_write(UC_X86_REG_RCX, 0xAAA)
mu.reg_write(UC_X86_REG_RDX, 0xBBB)
mu.emu_start(0x10000, 0, count=1000)
rsp_after = mu.reg_read(UC_X86_REG_RSP)
ret_slot = struct.unpack('<Q', mu.mem_read(STACK, 8))[0]
print("TRAMP rcx=0x%x rsp%%16=%d orig=0x%x/0x%x rsp_after=0x%x slot=0x%x" % (
    state["sc_rcx"], state["sc_rsp"] % 16, state["orig_rcx"], state["orig_rdx"], rsp_after, ret_slot))

# ---------- shellcode ----------
SC_ADDR = 0x1000000
STUB = 0x2000000
CTX = 0x3000000
USER = 0x4000000
STACK2 = 0x5000000 + 0x8000 - 8

mu2 = Uc(UC_ARCH_X86, UC_MODE_64)
mu2.mem_map(SC_ADDR, 0x10000)
mu2.mem_map(STUB, 0x1000)
mu2.mem_map(CTX, 0x1000)
mu2.mem_map(USER, 0x10000)
mu2.mem_map(0x5000000, 0x10000)
mu2.mem_write(SC_ADDR, SC)
mu2.mem_write(STUB, b"\xCC" * 0x1000)

S = {
    "lookup": STUB + 0x100,
    "open":   STUB + 0x200,
    "alloc":  STUB + 0x300,
    "thread": STUB + 0x400,
    "close":  STUB + 0x500,
    "deref":  STUB + 0x600,
}
PID = 0x1234
LOADLIB = 0x7FF800001000
PSTYPE = 0x777777777777
PATH = [ord(c) for c in "C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.dll"] + [0, 0]
PATH_LEN = len(PATH) - 1  # incl null, without the padding element
PATH = PATH[:PATH_LEN]

ctx = bytearray(1024)
struct.pack_into('<Q', ctx, 0, 0x7000000)
struct.pack_into('<Q', ctx, 8, S["lookup"])
struct.pack_into('<Q', ctx, 16, S["open"])
struct.pack_into('<Q', ctx, 24, S["alloc"])
struct.pack_into('<Q', ctx, 32, S["thread"])
struct.pack_into('<Q', ctx, 40, S["close"])
struct.pack_into('<Q', ctx, 48, S["deref"])
struct.pack_into('<Q', ctx, 56, PID)
struct.pack_into('<Q', ctx, 64, LOADLIB)
struct.pack_into('<Q', ctx, 72, PATH_LEN)
struct.pack_into('<Q', ctx, 88, PSTYPE)
for i, ch in enumerate(PATH):
    struct.pack_into('<H', ctx, 96 + i * 2, ch)
mu2.mem_write(CTX, bytes(ctx))

calls = []
align_ok = True

def hook_s(uc, addr, size, data):
    global align_ok
    if not (STUB <= addr < STUB + 0x1000):
        if addr == 0x7000000:
            uc.emu_stop()
        return
    rsp = uc.reg_read(UC_X86_REG_RSP)
    if rsp % 16 != 8:
        align_ok = False
    ret = struct.unpack('<Q', uc.mem_read(rsp, 8))[0]
    name = [k for k, v in S.items() if v == addr]
    name = name[0] if name else "?"
    a = [uc.reg_read(r) for r in (UC_X86_REG_RCX, UC_X86_REG_RDX, UC_X86_REG_R8, UC_X86_REG_R9)]
    calls.append({"name": name, "rsp": rsp, "ret": ret, "a": a, "st": []})
    rax = 0
    if name == "lookup":
        uc.mem_write(a[1], struct.pack('<Q', 0xDEADBEEF))
    elif name == "open":
        objt = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x20, 8))[0]
        mode = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x28, 8))[0]
        hptr = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x30, 8))[0]
        calls[-1]["st"] = [objt, mode, hptr]
        uc.mem_write(hptr, struct.pack('<Q', 0xAAAAAAAA))
    elif name == "alloc":
        uc.mem_write(a[1], struct.pack('<Q', USER))
    elif name == "thread":
        start = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x30, 8))[0]
        param = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x38, 8))[0]
        thptr = struct.unpack('<Q', uc.mem_read(rsp + 8 + 0x40, 8))[0]
        calls[-1]["st"] = [start, param, thptr]
        if thptr:
            uc.mem_write(thptr, struct.pack('<Q', 0x1234))
    uc.reg_write(UC_X86_REG_RAX, rax)
    uc.reg_write(UC_X86_REG_RSP, rsp + 8)
    uc.reg_write(UC_X86_REG_RIP, ret)

mu2.hook_add(UC_HOOK_CODE, hook_s)
mu2.reg_write(UC_X86_REG_RSP, STACK2)
mu2.mem_write(STACK2, struct.pack('<Q', 0x7000000))
mu2.reg_write(UC_X86_REG_RCX, CTX)
try:
    mu2.emu_start(SC_ADDR, 0x7000000, count=200000)
except UcError as e:
    print("SC emu error:", e)

status = struct.unpack('<Q', mu2.mem_read(CTX + 80, 8))[0]
print("SC calls:", [(c["name"], c["rsp"] % 16) for c in calls])
print("SC status:", hex(status), "align_ok:", align_ok)
for c in calls:
    if c["name"] == "lookup":
        print("  lookup pid=0x%x" % c["a"][0])
    if c["name"] == "open":
        print("  open obj=0x%x attrs=0x%x access=0x%x type=0x%x mode=%d hptr=0x%x" % (
            c["a"][0], c["a"][1], c["a"][3], c["st"][0], c["st"][1], c["st"][2]))
    if c["name"] == "alloc":
        print("  alloc handle=0x%x baseptr=0x%x sizeptr=0x%x" % (c["a"][0], c["a"][1], c["a"][3]))
    if c["name"] == "thread":
        print("  thread handle=0x%x start=0x%x param=0x%x thptr=0x%x" % (
            c["a"][0], c["st"][0], c["st"][1], c["st"][2]))
    if c["name"] == "close":
        print("  close handle=0x%x" % c["a"][0])
path_bytes = mu2.mem_read(USER, PATH_LEN * 2)
want = b"".join(struct.pack('<H', ch) for ch in PATH)
print("SC path copied:", path_bytes == want, "len", PATH_LEN)
