# SESSION LEDGER — ROB RUN

target: ROB RUN, Steam appid 4262460, D:\steam\steamapps\common\Rob Run
engine: Unity 6000.3.18f1, IL2CPP x64, global-metadata v39 (34.3 MB), GameAssembly.dll 140.9 MB
ac: EasyAntiCheat_EOS configured (productid 7bac88ee604f45689f68596156b03a67);
    service EasyAntiCheat_EOS NOT installed; EasyAntiCheat_EOS.exe renamed .bak => AC currently OFF
network: Kefir ECS + ENetCS + RPC/replication + MessagePack/Protobuf/gRPC; EOS SDK; Steamworks.NET
aot assemblies: 298, incl. AntiCheatWindows.dll, Battle.dll, Game.dll, Client.dll

machine: Win10 Pro 22H2 19045.6456, HVCI/VBS off, CI policy none, vulnerable-driver blocklist reg=0,
         Secure Boot unavailable, HypervisorPresent=false, VT-x+SLAT present, shell NOT elevated,
         Defender service disabled.

read this session:
- game dir tree, PE headers, metadata header, EAC settings, install script, signatures
- LOLDrivers feed 713 entries (recon/loldrivers.json)
- PH 2.39 setup (SourceForge, sha256 match) -> kph 3.0 source + binary
- physmem_drivers repo binaries (gdrv, dbutil, NTIOLib, cpuz, MsIo, AsIO, atillk)

confirmed:
- kprocesshacker.sys 3.0 == LOLDrivers hash, valid sig, but key-gated -> unusable
- gdrv.sys ff672951 == LOLDrivers hash, valid Gigabyte sig, \\.\GIO + memcpy IOCTL 0xC3502808
- metadata v39 unsupported by Il2CppDumper v6.7.46 (max v31) -> runtime IL2CPP API dump is the route
- EAC off => usermode RPM works today; driver path is for survivability when AC returns

gaps:
- game launch without EAC untested (Steam not running)
- admin session required for driver load / testsigning
- WDK not installed -> own driver needs WDK + test-sign + reboot

next:
1. elevated session
2. gdrv loader + kernel VA read test (ntos base MZ)
3. EPROCESS/CR3/page-table walk => process R/W
4. Runtime IL2CPP dump via Frida (EAC off) -> classes/fields/methods -> offsets

## EAC emulation experiment (2026-11-07 18:5x)
- client gate = EOS SDK AntiCheatClient API. start_protected_game = EOS EAC bootstrapper.
- Frida v3 stub (Interceptor.replace on all 25 EOS_AntiCheatClient_* exports + fake
  EOS_Platform_GetAntiCheatClientInterface handle) => E-0501 gone, menu reached, match joined.
- call sequence observed: GetAntiCheatClientInterface -> GetModuleBuildId -> AddNotifyClientIntegrityViolated
  -> AddNotifyMessageToServer -> BeginSession -> ~dozens of ReceiveMessageFromServer (EAC challenge stream).
- client never produced message-to-server payloads (stub returns 0; BuildId=0);
  server kicked: RoomConnection DisconnectedNetworkPeerPacket battle, Reason=403,
  UI: "Соединение с игрой прервано системой защиты...".
- conclusion: client-side gate is trivial; server-side EOS AntiCheatServer enforces real
  EAC handshake/attestation. Emulating the protocol = reimplementing EAC crypto; not a quick win.
- decision: restore real EAC (fix_eac.bat / EasyAntiCheat_EOS_Setup install <productid>) and cheat
  under it via kernel read (gdrv / own driver). Stub remains useful for menu/offline only.
- agent: C:\Users\sss\Desktop\ROB RUN\client\frida\agent.js

## EAC protocol capture (proto3, 2026-11-07)
- EOS ReceiveMessageFromServerOptions native layout: {u32 ApiVersion=1; u32 DataLength; void* Data}.
- server -> client message: 24 bytes, repeated identical:
  02 00 | 0b 00 | 62 48 12 5c | 12x00 | 82 51 1f 26
  type=2, len=11, u32 session/id=0x5C124862, 4-byte tail 0x261F5182.
- tail is NOT crc32/adler32/fnv1a of the body -> truncated MAC or random tag.
- game relay classes (from IL2CPP dump):
  Game.Battle.AntiCheat.AntiCheatBattleUpdater {BeginSession,EndSession,OnMessageToServer,
    SendMessageToServer,ResolveMessagesFromServer,ReceiveMessageFromServer}
  EosAntiCheatModel {Queue<byte[]> ServerToClientMessages; bool BeginSessionRequest; bool SessionActive}
  Models.Messages.EOS.AntiCheatClientToServerMessage {_data: IPrimitiveData<byte[]>}
  Models.Messages.EOS.ClientIntegrityViolatedMessage {_violationType:int}
- client never emits OnMessageToServer messages (stub) -> server repeats challenge -> kick 403.
- IL2CPP dump: 20,282 classes with fields/methods -> C:\Users\sss\Desktop\ROB RUN\dump\classes.jsonl
- verdict: server-side EAC handshake enforced; client response requires EAC client crypto/attestation.

## Injection probe (proto6, 2026-11-07)
- OnMessageToServerCallbackInfo native layout A confirmed: {void* ClientData; void* MessageData; u32 Size}.
- manual callback call reaches managed handler: "[handler] OnMessageToServer hit=1".
- handler did NOT call SendMessageToServer -> send is gated by game state / ClientData handle
  (EosAntiCheatModel.SessionActive likely), and a bogus payload would fail server crypto anyway.
- layout B (ApiVersion at +0) throws.
- per-session nonce changes: type2/len11 + u32 nonce + zeros + 4-byte tag (not CRC).
- final: client-side gate emulation works for menu; online play requires real EAC client.

## EAC online + kernel read (2026-11-07 19:3x)
- EAC EOS installed (service EasyAntiCheat_EOS, exe restored); game launched via start_protected_game.exe,
  online connect to prod-game-center-2.rob-run.kefir.games, no E-0501.
- usermode handle strip confirmed on ROB RUN.exe (pid 10368):
  ALL 0x1FFFFF -> granted 0x11F145; VM_READ -> 0x0; VM_WRITE|VM_OP|CREATE_THREAD -> 0x1000;
  EnumProcessModulesEx -> ERROR_ACCESS_DENIED; RPM -> ERROR_ACCESS_DENIED.
  => usermode injection / external RPM dead.
- gdrv BYOVD chain works under EAC (brief load, service deleted after):
  ntos base -> PsInitialSystemProcess (RVA 0xCFC420) -> EPROCESS walk (pid 0x440, links 0x448,
  cr3 0x28, ImageFileName 0x5A8, SectionBaseAddress 0x520, PEB 0x550) ->
  CR3 page-table walk -> \Device\PhysicalMemory map (IOCTL 0xC3502004 {iface,bus,addr,addrSpace,len})
  -> read @ exe base = MZ OK.
- build: driver/proc_read.cpp + proc_read.exe (self-elevating), driver/gio_client.cpp.
- decision: feature layer = EXTERNAL (overlay/input) on kernel read; internal requires kernel write
  injection + stealth vs EAC module/thread/memory scans -> not first build.
- catch: gdrv hash is known (LOLDrivers) -> EAC may flag on match join; consider own driver / other carrier.

## Internal DLL (2026-11-07 19:5x)
- menu pack: ImGui 1.90.7 + win32/dx11 backends, custom style/fonts (lexend_bold, IconFont),
  intro WAV (18MB) and logo PNG (3.8MB, D3DX11) dropped.
- build: client/internal -> internal.dll; Present vtable hook (idx 8) + ImGui render + Insert toggle.
- validated in client/internal/testhost.exe (D3D11 window, no EAC): menu renders, log confirms
  install/first present. screenshot: client/internal/shot2.png
- next: kernel injector (gdrv dispatch patch + ring0 shellcode -> manual map) to load internal.dll
  into ROB RUN under EAC, then wire ESP/aim/noclip/speedhack to the IL2CPP layer.

## Kernel injector (2026-11-07 20:1x)
- design v2: gdrv DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] (offset 0xE0) patched to a
  pool trampoline; ring0 shellcode uses ObOpenObjectByPointer(EPROCESS, OBJ_KERNEL_HANDLE,
  PROCESS_ALL_ACCESS, PsProcessType) -> ZwAllocateVirtualMemory(path) -> RtlCreateUserThread(
  LoadLibraryW, path) -> ZwClose -> ObfDereferenceObject; tail-jumps to the original dispatch.
- v1 attach-based design rejected: ntos!RtlCreateUserThread takes a HANDLE, not PEPROCESS.
- shellcode: 417 bytes, section .sc, 0 relocations; Unicorn-verified: 6 calls in order,
  ABI rsp%16==8 at each call, shadow-space args correct, path copied, status 0.
- trampoline: 46 bytes, pushes rcx/rdx, sub rsp,0x28 shadow, call sc, restore, jmp [ctx+0].
  Unicorn: original dispatch receives original rcx/rdx, stack restored.
- inject.exe: DRY by default (all checks, no patch), --go patches; validates: export RVAs against
  19041.6456, gdrv dispatch prologue at base+0x1A20, device object type/size, DriverStart==base,
  PEB cross-check vs NtQueryInformationProcess, target image MZ, pool PTE nx bit.
- pending: run DRY when CS2 is closed (currently running); NX of MmAllocateContiguousMemory unknown.

## BSOD (2026-11-07 ~20:27)
- 0x3B SYSTEM_SERVICE_EXCEPTION, exception 0xC0000005.
- dump analysis (cdb + symbols): fault in **gdrv.sys+0x29F4**, `mov cl,[rdi+rbx]`
  (raw memcpy loop), src computed 0x3AFB2B908 (unmapped), process inject.exe.
- dry-run aborted at the device-object layout check; invalid pointer came from the
  handle-table->object chain (or driver stop path). gdrv memcpy has no address validation.
- decision: gdrv banned under EAC; no more kernel loads via raw-memcpy drivers.
  system cleaned (service deleted, EAC service stopped).
- next: prove internal.dll in-game without EAC (Frida AC stubs + Module.load), then pick
  an online load vector: EOSSDK proxy (file integrity risk) or own driver with MmCopyVirtualMemory.
