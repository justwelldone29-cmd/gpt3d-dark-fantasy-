# BYOVD carrier shortlist — ROB RUN (2026-11-07)

Vetting chain: SHA256 == LOLDrivers catalog sample + Authenticode valid + PE inspected.
No local AV on box (Defender AMServiceEnabled=False), so hash-match is the malware gate.
MalwareBazaar/VT API require keys (401 without).

| Driver | SHA256 | Signer | Sig | Primitive | Status |
|---|---|---|---|---|---|
| gdrv.sys | ff6729518a380bf57f1bc6f1ec0aa7f3012e1618b8d9b0f31a61d299ee2b4339 | GIGA-BYTE TECHNOLOGY CO., LTD. | Valid | `\\.\GIO`; IOCTL 0xC3502800 alloc, 0xC3502808 memcpy(dst,src,size) => kernel VA R/W; 0xC3502004/2008; 0xC3502580 MmMapIoSpace phys map; MSR | **PICK** |
| dbutil_2_3.sys | 0296e2ce999e67c76352613a718e11516fe1b0efc3ffdb8918fc999dd76a73a5 | Dell Inc. | Valid | CVE-2021-21551, write-what-where | fallback |
| NTIOLib_X64.sys | d8b58f6a89a7618558e37afc360cd772b6731e3ba367f8d58734ecee2244a530 | Micro-Star Int'l Co. Ltd. | chain UnknownError | physmem map | fallback |
| cpuz141.sys | ded2927f9a4e64eefd09d0caba78e94f309e3a6292841ae81d5528cab109f95d | CPUID | Valid | MSR/PCI/phys | fallback |
| MsIo64.sys | 525d9b51a80ca0cd4c5889a96f857e73f3a80da1ffbae59851e0f51bdfb0b6cd | MICSYS Technology | Valid | IO/phys | fallback |
| AsIO64.sys | b48a309ee0960da3caaaaf1e794e8c409993aeb3a2b64809f36b97aac8a1e62a | ASUSTeK | Valid | IO/phys | fallback |
| atillk64.sys | 5c04c274a708c9a7d993e33be3ea9e6119dc29527a767410dbaf93996f87369a | ATI Technologies | Valid | phys | fallback |
| kprocesshacker.sys (3.0) | 70211a3f90376bbc61f49c22a63075d1d4ddd53f0aefa976216c46e6ba39a9f4 | Wen Jia Liu | Valid | process R/W but key-gated | **DEAD** |

## KPH dead-end (verified in source, PH 2.39)
- `KphValidateKey()` requires `Client->VerificationSucceeded && KeysGenerated` for usermode.
- Keys are delivered only by `KphRetrieveKeyViaApc()` -> requires `VerificationSucceeded`.
- `KphVerifyClient()` = ECDSA P-256 over client code range, private key held by wj32.
- `KPH_READVIRTUALMEMORYUNSAFE` (0x9999/0x83A) is L2-key protected. Device `\Device\KProcessHacker3`, no symlink (GLOBALROOT only).
- Result: unusable from usermode without the vendor signing key. Do not ship.

## gdrv notes
- Device `\\.\GIO` (wide strings `\Device\GIO`, `DosDevices\GIO` in .text).
- IOCTL constants present in .text: 0xC3502800, 0xC3502808, 0xC3502004, 0xC3502008, 0xC3502580.
- PDB: `legacygdrv64\x64\Release\gdrv64.pdb`.
- Load: `sc create gdrv type= kernel binPath= <path>` + `sc start gdrv` (admin).
- Detection: driver object + service key, `MmUnloadedDrivers` after stop; known hash -> EAC/BE signatured.
