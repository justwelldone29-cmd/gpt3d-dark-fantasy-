# HANDOFF — брифинг для следующего инженера/ИИ

Этот файл описывает всё, что нужно, чтобы продолжить проект без перечитывания истории чата.
Читать первым. Дальше — `ARCHITECTURE.md`, `IL2CPP-MAP.md`, `BUILD.md`.

## 1. Задача

Внутренний чит для **ROB RUN** (Steam appid `4262460`, Unity 6000.3.18f1, IL2CPP, EOS Anti-Cheat).
Цель: меню + ESP (боксы, скелет, метки, HP), затем aim/noclip/speedhack, и в перспективе — рабочий инжект под реальным EAC.

Проект живёт в `C:\Users\sss\Desktop\ROB RUN`, игра — в `D:\steam\steamapps\common\Rob Run`.

## 2. Состояние на момент передачи

### Работает и проверено в живой игре

- DLL грузится в процесс, Present-хук встаёт, ImGui-меню рисуется.
- Меню: `Insert`, перетаскивание за шапку, виртуальный курсор, кастомные тумблеры, табы.
- ESP: боксы по костям, скелет (позвоночник, руки, ноги, шея, голова-круг), дистанция, дедуп, отсев своего персонажа.
- Метки `PLAYER` / `BOT` (боты — по `NpcView` в иерархии или близости 3D-маркера).

### Не доделано

- **HP-бар** — заглушён: `CharacterOverlayStatView._progress.fillAmount` всегда `0.00`.
- **NPC vs игрок** — эвристика, полноценной классификации из модели сущности нет.
- **Aim / noclip / speedhack** — только тумблеры в UI, логики нет.
- **Инжект под EAC** — не решён. Текущий путь (заглушки EOS AC + `Module.load`) сервер детектит: кик и временный бан.

## 3. Жёсткие ограничения (не нарушать)

1. **Тесты только на отдельном аккаунте.** Игра F2P (`is_free: true`), любой новый Steam-аккаунт подходит. Бан серверный, срок ~1 час с момента детекта; запуски его не продлевают, но и не снимают. На основном аккаунте не запускать — каждая новая детекция даёт новый бан. После сессий через harness основной аккаунт получил блокировку «Нарушение правил безопасности» (временная). Каждый онлайн-запуск с модифицированным клиентом это повторяет.
2. **`gdrv.sys` не загружать.** Он дал BSOD `0x3B SYSTEM_SERVICE_EXCEPTION` в `gdrv+0x29F4` (`mov cl,[rdi+rbx]`, bad src `0x3AFB2B908`) и удалён из проекта. BYOVD при этом разрешён — нужен другой подписанный carrier.
3. **Не запускать kernel-тесты при работающем CS2** на этой машине.
4. **Сборка только при закрытой игре** — DLL залочена процессом.

## 4. Карта проекта

| Путь | Что там |
|---|---|
| `client/internal/` | исходники DLL, `build.bat`, готовый `internal.dll` |
| `client/internal/hook/present.cpp` | Present-хук, окно, ввод, виртуальный курсор, вызов `esp::Render` |
| `client/internal/menu/ui.cpp` | меню, табы, тумблеры |
| `client/internal/features/il2cpp.cpp` | резолв экспортов `GameAssembly.dll`, `invoke`, массивы, строки |
| `client/internal/features/esp.cpp` | весь ESP: риг, бокс, скелет, локалка, боты, HP |
| `client/frida/run_menu_test.py` + `menu_test.js` | спавн игры, заглушки `EOS_AntiCheatClient_*`, загрузка DLL |
| `client/frida/proto*.js` | эксперименты с протоколом EAC (не трогать без нужды) |
| `dump/classes.jsonl` | 20 282 IL2CPP-класса: `{"a","n","p","f","m"}` = assembly, name, parent, fields, methods |
| `driver/` | kernel-инжектор и шеллкод; драйверов нет, нужен новый carrier (BYOVD разрешён) |
| `recon/ledger.md` | журнал разведки: BSOD, протокол, EAC |
| `recon/drivers.md` | разбор кандидатов BYOVD |

## 5. Как запустить и проверить

```powershell
# 1. закрыть игру
Get-Process 'ROB RUN' -ErrorAction SilentlyContinue | Stop-Process -Force

# 2. собрать
cmd /c "C:\Users\sss\Desktop\ROB RUN\client\internal\build.bat"     # ждать BUILD_OK

# 3. запустить harness (Steam залогинен, аккаунт тестовый)
python "C:\Users\sss\Desktop\ROB RUN\client\frida\run_menu_test.py" 1800

# 4. лог DLL
Get-Content 'C:\Users\sss\Desktop\ROB RUN\client\internal\internal.log' -Tail 40
```

Инжект вручную (если нужен):
`Module.load("C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.dll")` из Frida-скрипта.

## 6. Ближайшие задачи (в порядке ценности)

### 6.1 Модель сущностей — уже найдена

Цепочка проверена в игре (`docs/RE-WORKFLOW.md`):

```
Start.UnityEntry._game → Game.Game.<GameModel> → GameModel._battleModel
 → BattleModel.<BattleEntitiesModel> → BattleEntitiesModel._worldEntitiesModel
 → WorldEntitiesModel._battleCharacters (Dictionary<int, BattleCharacterModel>)
```

Перебор даёт `actors=8..10`, `bots=7..9` (`PlayerBattleModel == null`).
Осталось: позиция модели. `<CenterPosition>` пустой — читать `<Transform>` → `_x/_y/_z` (each `IPrimitiveData<float>`, concrete `FloatData`, value in `BasePrimitiveData<float>._value`). После этого — привязка модели к костям по координате и HP из `<PrivateModel>.<Health>._health._value`.

### 6.2 Инструменты для дебага

x64dbg / runtime IL2CPP dumper / Cheat Engine — методика в `docs/RE-WORKFLOW.md`.

### 6.3 Инжект под EAC

Факты:

- `EAC` ставит на процесс `ROB RUN.exe` handle-маску `QUERY_LIMITED`: `VM_READ` и `VM_WRITE|CREATE_THREAD` срезаны, `OpenProcess` для инжекта не работает.
- EOS AntiCheat client (`EOSSDK-Win64-Shipping.dll`) обменивается с сервером 24-байтными сообщениями (`02 00 0b 00 ...`), MAC на сессионном nonce, не CRC. Сервер проверяет handshake — заглушки приводят к кику/бану.
- Рабочие направления: (а) прокси/подмена `EOSSDK-Win64-Shipping.dll` до старта AC, (б) ручной маппинг DLL и перехват потока до инициализации AC, (в) kernel-маппер на чистом подписанном драйвере — но `gdrv` мёртв, нужен новый carrier.

## 7. Конвенции кода

- C++20, MSVC, `snake_case` функции, `PascalCase` типы, без исключений в горячем пути.
- Все настройки — константы сверху файла (`k_max_dist`, `k_box_width_ratio`, …), без магических чисел ниже.
- Логи — только через `EspLog`/`Log` с префиксом (`[esp]`, `[rig]`, `[ov]`), лог-файл `client/internal/internal.log`.
- O(1) в кадре: всё, что дорого (поиск объектов, имена костей), кэшируется и обновляется по таймеру (400 мс / 1.5 с).
- Имена костей матчатся **по суффиксу**, префиксы (`M_`/`F_`) между префабами различаются.

## 8. Грабли (уже наступлено)

| Грабли | Симптом | Решение |
|---|---|---|
| `ImGui::Checkbox` не получает клик | hover есть, press нет | кастомный `Toggle` на `InvisibleButton` + `IsItemClicked` |
| WndProc игры в другом потоке | клики теряются | ввод через `GetAsyncKeyState` + `GetCursorPos` в потоке Present |
| Игра прячет курсор | курсора не видно | рисовать свой курсор в `GetForegroundDrawList` |
| `Renderer.bounds` у skinned mesh | боксы-гиганты | бокс по костям (head_2 / feet) |
| Несколько SMR на персонажа | дубли боксов/скелетов | дедуп по hips + по позиции 0.9 м |
| Свой персонаж в кадре | гигантский бокс | ближайший к камере `BattleCharacterEntityView` + отсев по высоте бокса |
| `Camera.main` до загрузки сцены | `null` | ждать, логировать `[esp] no camera` |
| Строки IL2CPP | `object_name(Transform*)` возвращает пусто | имя брать через `Object.get_name` → потом читать String |

## 9. Как перепроверять данные на новом билде

1. `dump/classes.jsonl` — grep по имени класса/поля, получить namespace и состав.
2. В рантайме: `Resources.FindObjectsOfTypeAll(Type)` + лог количества.
3. Координаты/позиции: `Transform.get_position` (boxed `Vector3`), экран — `Camera.WorldToScreenPoint`.
4. Оффсеты полей не хардкодить: `il2::field_offset(klass, "<Field>k__BackingField")` в рантайме.
5. Любой новый факт писать в `recon/ledger.md` с тегом `read` / `confirmed` / `inferred`.

## 10. Критерии готовности текущего этапа

- [ ] Бокс, скелет и метка для каждого персонажа в кадре, без своего тела.
- [ ] HP-бар заполняется по реальному здоровью.
- [ ] `BOT` / `PLAYER` различаются по модели, а не по маркеру.
- [ ] Никлайм: ники игроков отображаются в метке.
- [ ] Инжект, не палящийся сервером (или решение тестировать только оффлайн).
