# IL2CPP-MAP — что используется и как перепроверять

Сборка: Unity **6000.3.18f1**, IL2CPP, `global-metadata.dat` **v39** (Il2CppDumper не поддерживает).
Полный дамп классов: `dump/classes.jsonl` — 20 282 записи, формат:

```json
{"a":"Battle.dll","n":"Game.Battle.Entities.Npc.NpcView","p":"UnityEngine.MonoBehaviour",
 "f":[["<Nickname>k__BackingField",0,"UnityEngine.Localization.LocalizedString"]],
 "m":[["Get",0,"0x7ffc818c6010"]]}
```

`a` — сборка, `n` — полное имя класса, `p` — родитель, `f` — поля `[имя, атрибуты, тип]`, `m` — методы `[имя, argc, RVA]`.

> Важно: RVA в дампе — из **этого** билда; на патче всё переезжает. Классы и имена полей стабильнее.


## 0. Runtime SDK dump (актуально)

Полный дамп снят с живой игры: `dump/full_sdk.jsonl` (23.8 МБ, 38 077 классов).

Формат строки:

```json
{"a":"Battle.dll","n":"Game.Battle.BattleEntitiesModel","p":"System.Object",
 "f":[["_worldEntitiesModel",96,"Models.Models.WorldEntities.WorldEntitiesModel",4]],
 "m":[["get_Player",0,9457568]]}
```

`f` — `[имя, offset, тип, flags]` (`flags & 0x10` = static), `m` — `[имя, argc, rva]` от базы `GameAssembly.dll`.
Снято скриптом `client/frida/dump_il2cpp.js` через `client/frida/run_dump.py` (заглушки EOS AC обязательны, иначе игра падает с `E-0501`).

### Оффсеты текущего билда (0.7.0.4017)

| Класс | Поле | Offset |
|---|---|---|
| `Start.UnityEntry` | `_game` | +0x010 |
| `Game.Game` | `<GameModel>k__BackingField` | +0x0D8 |
| `Game.GameModel` | `_battleModel` | +0x010 |
| `Game.Battle.BattleModel` | `<BattleEntitiesModel>k__BackingField` | +0x090 |
| `Game.Battle.BattleModel` | `<WorldEntitiesModel>k__BackingField` | +0x510 |
| `Game.Battle.BattleEntitiesModel` | `_models` | +0x050 |
| `Game.Battle.BattleEntitiesModel` | `_worldEntitiesModel` | +0x060 |
| `Models.Models.WorldEntities.WorldEntitiesModel` | `_notSpawnedBattleCharacters` | +0x010 |
| `Models.Models.WorldEntities.WorldEntitiesModel` | `_battleCharacters` | +0x018 |
| `BattleCharacterModel` | `<PrivateModel>k__BackingField` | +0x010 |
| `BattleCharacterModel` | `<Id>k__BackingField` | +0x038 |
| `BattleCharacterModel` | `<Transform>k__BackingField` | +0x058 |
| `BattleCharacterModel` | `<IsDead>k__BackingField` | +0x0F0 |
| `BattleCharacterModel` | `<PlayerBattleModel>k__BackingField` | +0x258 |
| `BattleCharacterModel` | `<CenterPosition>k__BackingField` | +0x290 |
| `BattleCharacterPrivateModel` | `<Health>k__BackingField` | +0x1B0 |
| `Models.Models.Health.HealthModel` | `_health` | +0x010 |
| `Models.Models.Health.HealthModel` | `_maxAmount` | +0x020 |
| `Models.Models.Health.HealthModel` | `_criticalHealth` | +0x024 |
| `Models.Models.TransformModel.TransformModel` | `_x`, `_y`, `_z` | +0x010 / +0x018 / +0x020 |
| `Models.Models.PositionModel.PositionModel` | `X`, `Y`, `Z` | +0x010 / +0x014 / +0x018 |
| `BattleCharacterEntityView` | `<FollowCamera>k__BackingField` | +0x058 |

`IPrimitiveData<T>` (`FloatData`/`IntData`) — значение в `BasePrimitiveData<T>._value`; offset для инфлированного generic-класса брать в рантайме: `il2cpp_field_get_offset(il2cpp_class_get_field_from_name(il2cpp_object_get_class(data), "_value"))`.

### Что из этого уже используется в DLL

- Позиция: `BattleCharacterModel.<Transform>` → `_x/_y/_z` → `_value`.
- HP: `<PrivateModel>.<Health>._health._value` / `_maxAmount`.
- Бот: `<PlayerBattleModel> == null`.
- Привязка модели к отрисованному персонажу — по ближайшей позиции (radius 2 м).

## 1. UnityEngine — то, на чём стоит ESP

| Класс | Что берём | Как |
|---|---|---|
| `UnityEngine.Camera` | `get_main` (static), `WorldToScreenPoint` | `il2::find_method` + `invoke` |
| `UnityEngine.Component` | `get_transform`, `get_gameObject` | |
| `UnityEngine.Transform` | `get_position`, `get_parent`, `get_root` | `position` — boxed `Vector3` |
| `UnityEngine.Renderer` | `get_bounds` (не используется, заменено костями) | |
| `UnityEngine.SkinnedMeshRenderer` | `get_bones`, `get_rootBone` | массив `Transform[]` |
| `UnityEngine.Resources` | `FindObjectsOfTypeAll(Type)` | основной способ получить объекты сцены |
| `UnityEngine.Object` | `get_name` | вернуть `String`, читать через `il2::object_name` |
| `UnityEngine.UI.Image` | `get_fillAmount` | HP-попытка, всегда 0 |

`WorldToScreenPoint` возвращает `Vector3`: `z` = расстояние вперёд, `x/y` — пиксели от левого-нижнего. В ESP: `screen.y = DisplaySize.y - v.y`.

## 2. Игровые классы

### Персонаж

| Класс (namespace + имя) | Поля | Зачем |
|---|---|---|
| `Game.Battle.EntityModel.BattleCharacter.Views.BattleCharacterEntityView` | `<FollowCamera>k__BackingField` (offset **88**), `<MovementView>`, `<HeadPosition>` | поиск локального игрока |
| `Game.Battle.Entities.Npc.NpcView` | `<Nickname>`, `<MarkerRoot>`, `<IsTrader>`, `<IsVigilant>` | метка NPC |
| `Game.Battle.Markers.Markers3D.View.Marker3DView` | `<TransformView>`, `<AlphaView>` | 3D-маркеры (жёлтый «!») для классификации ботов |
| `Game.Battle.EntityModel.BattleCharacter.Stats.CharacterOverlayStatView` | `_rectTransform`, `_progress`, `<Nickname>` | HUD-оверлей: HP-бар и ник (HP пока не читается) |
| `Utils.PlayerSkeletonDebugRenderer.PlayerSkeletonDebugRendererComponent` | `_getBattleCharacters` (`Func<IEnumerable<BattleCharacterModel>>`) | **ключ к моделям** (HP/ник/тип) |

### Модель (доступна через Start.UnityEntry)

Цепочка, проверенная в игре (см. `docs/RE-WORKFLOW.md`):

```
Start.UnityEntry._game                      (MonoBehaviour, 1 экземпляр)
 → Game.Game.<GameModel>k__BackingField
 → GameModel._battleModel
 → BattleModel.<BattleEntitiesModel>k__BackingField
 → BattleEntitiesModel._worldEntitiesModel
 → WorldEntitiesModel._battleCharacters    Dictionary<int, BattleCharacterModel>
```

| Класс | Поля | Зачем |
|---|---|---|
| `Models.Models.BattleCharacter.BattleCharacterModel` | `<Id>` (int), `<PrivateModel>`, `<IsDead>`, `<Transform>`, `<PlayerBattleModel>`, `<CenterPosition>` | всё о персонаже |
| `Models.Models.BattleCharacterPrivate.BattleCharacterPrivateModel` | `<Health>` (`HealthModel`) | HP |
| `Models.Models.Health.HealthModel` | `_health` (`IPrimitiveData<int>`), `_maxAmount`, `_criticalHealth` | HP |
| `Models.Models.TransformModel.TransformModel` | `_x`, `_y`, `_z` (`IPrimitiveData<float>`) | мировая позиция |
| `Framework.Replication.Data.Primitive.BasePrimitiveData<T>` | `_value` (T) | как читать `IPrimitiveData<T>` |
| `Models.Data.BattleCharacterSlotData` | `<Nickname>` (`IPrimitiveData<string>`) | ник |

Проверено: перебор `_battleCharacters` работает, `PlayerBattleModel == null` даёт ботов (7–9 из 8–10 акторов).
Не решено: `CenterPosition` не даёт координат — читать `<Transform>` → `_x/_y/_z` → `FloatData._value`.

## 3. Кости персонажа

Дамп `SkinnedMeshRenderer.bones` (60 костей, порядок стабилен для базового префаба):

```
0  M_spine_1_jnt      12 L_arm_0_jnt      32 R_arm_0_jnt      52 L_leg_1_jnt
1  M_spine_2_jnt      13 L_arm_1_jnt      33 R_arm_1_jnt      53 L_leg_2_jnt
2  M_spine_3_jnt      14 L_arm_2_jnt      34 R_arm_2_jnt      54 L_leg_3_jnt
3  M_neck_jnt         15 L_arm_3_jnt      35 R_arm_3_jnt      55 L_foot_1_jnt
4  M_head_1_jnt       16..31 пальцы/кисть  36..51 пальцы/кисть  56 R_leg_1_jnt
5  M_head_2_jnt                                                57 R_leg_2_jnt
6..11 глаза/веки                                               58 R_leg_3_jnt
                                                               59 R_foot_1_jnt
```

Встречаются варианты на 38, 53, 54, 61, 84, 94 кости — у них те же имена, поэтому матчинг **по суффиксу**:

```
_spine_1_jnt, _spine_2_jnt, _spine_3_jnt, _neck_jnt,
_head_1_jnt, _head_2_jnt,
L_arm_0_jnt … L_arm_3_jnt, R_arm_0_jnt … R_arm_3_jnt,
L_leg_1_jnt … L_leg_3_jnt, R_leg_1_jnt … R_leg_3_jnt,
L_foot_1_jnt, R_foot_1_jnt
```

`Rig.ok` = найдены `hips`, `head_2`, `foot_L`, `foot_R`. Полный набор слотов = `mask 0x3FFFFF` (лог `[slots]`).

## 4. Резолв API (features/il2cpp.cpp)

Экспорты `GameAssembly.dll`, которые реально нужны:

```
il2cpp_domain_get                il2cpp_domain_get_assemblies
il2cpp_class_from_name           il2cpp_class_get_method_from_name
il2cpp_runtime_invoke            il2cpp_object_unbox
il2cpp_object_get_class          il2cpp_class_get_name
il2cpp_class_get_type            il2cpp_type_get_object
il2cpp_array_length              il2cpp_thread_attach
il2cpp_runtime_class_init        il2cpp_class_get_field_from_name
il2cpp_field_get_offset
```

Правила:

- `il2cpp_thread_attach(domain)` обязателен для потока Present.
- Возврат `struct`/примитивов — boxed, разворачивать `il2cpp_object_unbox`.
- Массив: данные с `+0x20`, элемент — `void*`.
- Строка: длина `int32 @ +0x10`, UTF-16 символы с `+0x14`.
- Поле: `il2cpp_field_get_offset(il2cpp_class_get_field_from_name(klass, "<X>k__BackingField"))`, не хардкодить.

## 5. Как обновлять под новый билд

1. Новый `global-metadata.dat` → перегенерить `dump/classes.jsonl` (скрипт дампа в `client/frida/run_dump.py` / `dump_il2cpp.js`).
2. Проверить, что живы классы из таблиц выше (`Select-String` по `n`).
3. Перепроверить offset `_FollowCamera` (был 88) — он зависит от порядка полей.
4. Проверить набор костей: залогировать `bones[]` первого персонажа при `[rig]`.
5. Перезапустить, посмотреть `[esp] api ok=1` и `[rig] n=… b0='M_spine_1_jnt'`.

## 6. Теги достоверности

| Факт | Тег |
|---|---|
| Имена костей, порядок, `mask 0x3FFFFF` | `confirmed` (лог `[slots]`, `[rig]`) |
| Offset `_FollowCamera = 88` | `confirmed` (работает поиск локалки) |
| `Marker3DView` как маркер квестовых NPC | `inferred` (по близости, нужна проверка на нескольких NPC) |
| `CharacterOverlayStatView._progress` = HP | `inferred`, `fillAmount` всегда 0 → механизм другой |
| `PlayerSkeletonDebugRendererComponent._getBattleCharacters` | `read` (дамп), в рантайме не проверялось |
| `BattleCharacterModel.<PlayerBattleModel>` = признак игрока | `inferred` |
