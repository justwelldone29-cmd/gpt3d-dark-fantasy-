# ARCHITECTURE

## Поток запуска

```
DllMain(DLL_PROCESS_ATTACH)
└─ CreateThread → bootstrap()
   ├─ ждём окно игры (FindWindow / hwnd из swapchain)
   ├─ вешаем Present hook на IDXGISwapChain::Present (vtable[8])
   ├─ первый Present → создаём ImGui context, ImGui_ImplWin32/DX11, RTV, подменяем WndProc
   └─ каждый Present → Render(sc)
```

`hook/present.cpp` держит всё состояние кадра: устройство, контекст, окно, размеры, RTV.
`ImGui_ImplWin32_WndProcHandler` **не используется для меню** — он живёт в главном потоке игры, а ImGui-контекст создаётся в потоке Present. Из-за этого клики терялись.

## Ввод и курсор

- Меню открывается/закрывается `Insert` (опрос `GetAsyncKeyState` в потоке Present).
- Позиция мыши: `GetCursorPos` → `ScreenToClient`, кнопки: `GetAsyncKeyState(VK_LBUTTON/VK_RBUTTON)`.
- Игра каждый кадр прячет и клипует курсор, поэтому:
  - `ClipCursor(nullptr)` при открытом меню;
  - рисуется **свой** курсор (треугольник во `GetForegroundDrawList`), он не зависит от системного;
  - движение считается по дельтам реальной мыши, экранные координаты клампятся в `DisplaySize`.
- Меню не таскается штатным `Begin` — заголовок это `InvisibleButton` на 26 px, позиция окна хранится в `menu_pos` и подаётся через `SetNextWindowPos(..., Always)`.
- Все чекбоксы — кастомный `Toggle()` на `InvisibleButton` + `IsItemClicked(0)`; стандартный `ImGui::Checkbox` не получал press в этом окружении.

## IL2CPP

Игра — Unity 6000.3.18f1, IL2CPP, `global-metadata.dat` версии 39 (Il2CppDumper её не понимает).

`features/il2cpp.cpp` резолвит экспорты `GameAssembly.dll`:

```
il2cpp_domain_get, il2cpp_domain_get_assemblies, il2cpp_class_from_name,
il2cpp_class_get_method_from_name, il2cpp_runtime_invoke, il2cpp_object_unbox,
il2cpp_object_get_class, il2cpp_class_get_name, il2cpp_class_get_type,
il2cpp_type_get_object, il2cpp_array_length, il2cpp_thread_attach,
il2cpp_runtime_class_init, il2cpp_class_get_field_from_name, il2cpp_field_get_offset
```

Вызов метода: `il2::invoke(method, obj, params)`. Возврат значимых типов (`Vector3`, `Bounds`, `float`, `bool`) — boxed, разворачивается `il2::unbox`.
`Resources.FindObjectsOfTypeAll(Type)` используется как основной способ получить объекты сцены: `SkinnedMeshRenderer`, `BattleCharacterEntityView`, `Marker3DView`, `CharacterOverlayStatView`.

Поток Present не является IL2CPP-потоком — при первом обращении нужен `il2cpp_thread_attach` (выполняется в `il2::init/ensure_thread`).

## ESP — конвейер

Файл `features/esp.cpp`, вызывается каждый кадр из Present **до** `ImGui::Render()`:

```
esp::Render(GetBackgroundDrawList())
├─ resolve_api()                  # один раз: классы + MethodInfo
├─ Camera.main → позиция камеры
├─ каждую 1 с: пересборка списка персонажей (FindObjectsOfTypeAll(SkinnedMeshRenderer))
├─ каждые 3 с: 3D-маркеры; каждые 2 с: перебор моделей сущностей
└─ для каждого персонажа:
   ├─ rig из кэша (renderer → Rig), иначе build_rig()
   ├─ дедуп по hips + по позиции 0.35 м
   ├─ отсев локалки (экран + высота бокса)
   └─ отрисовка: бокс, скелет, метка, дистанция
```

W2S: один раз за кадр читаются `worldToCameraMatrix` и `projectionMatrix`, дальше `clip = (P·V) * world` в C++, `ndc = clip.xyz / clip.w`, экран = `(ndc.x*0.5+0.5)*W`, `(0.5-ndc.y*0.5)*H`. Вызов `Camera.WorldToScreenPoint` больше не используется (fallback, если матрицы не достались).

### Rig

Скелет персонажа — 60–94 кости, имена в стиле `M_spine_1_jnt`, `L_arm_0_jnt`.
Слоты (`Slot` в `esp.cpp`): `S_HIPS, S_SPINE2, S_SPINE3, S_NECK, S_HEAD1, S_HEAD2, S_ARM_L0..L3, S_ARM_R0..R3, S_LEG_L0..L2, S_LEG_R0..R2, S_FOOT_L, S_FOOT_R`.

Сопоставление — по **суффиксу** имени (`_spine_1_jnt`, `L_arm_0_jnt`, …), потому что префиксы различаются между префабами (`M_`/`F_`). `Rig.ok` требует hips + head_2 + оба стопа.

Кэш `unordered_map<void*, Rig>` чистится при обновлении списка рендереров; имена читаются только на промахе кэша.

### Бокс

Считается не по `Renderer.bounds`, а по костям:

```
top    = project(M_head_2).y
bottom = max(project(L_foot_1).y, project(R_foot_1).y)
pad    = height * 0.06
width  = height * 0.45, центр по X — проекция hips
```

Бокс высотой больше 75 % экрана отбрасывается — это собственное тело в третьем лице.

### Скелет

Рёбра: `hips→spine2→spine3`, `spine3→arm0→arm1→arm2→arm3` (обе руки), `hips→leg1→leg2→leg3→foot` (обе ноги), `neck/spine3→head1→head2`. Голова — окружность в `head_2`, радиус от расстояния `head_1…head_2` (3–22 px).

Линия рисуется только если обе точки спроецировались с `z > 0.1`.

### Локалка

1. Ищем `BattleCharacterEntityView` с непустым `<FollowCamera>k__BackingField` (offset 88), выбираем **ближайший к камере** (в третьем лице это всегда свой персонаж).
2. Кандидат отбрасывается, если его позиция ближе 1.5 м к найденной или его цепочка предков (6 уровней) содержит этот transform.
3. Дополнительный отсев — по высоте бокса (см. выше).
4. Если маркер не найден — удаляется ближайший к камере персонаж в радиусе 3.2 м.

### BOT / PLAYER

Метка ставится, если выполняется любое:

- в иерархии есть `Game.Battle.Entities.Npc.NpcView`;
- голова персонажа в пределах 1.4 м от любого `Game.Battle.Markers.Markers3D.View.Marker3DView` (жёлтый «!» над квестовыми NPC).

Иначе — `PLAYER`. Оранжевый цвет для ботов, голубой для игроков.

### HP

HUD-оверлей `CharacterOverlayStatView` находится (`_rectTransform`, `_progress`), но `Image.fillAmount` у него всегда `0.00` — HP так не читается. Отрисовка HP-бара заглушена условием `hp > 0.01`. Нужен доступ к `Models.Models.BattleCharacter.BattleCharacterModel` → `<PrivateModel>` → `<Health>` (см. `docs/IL2CPP-MAP.md`).

## Модель сущностей

Резолвится в рантайме (подробности — `docs/RE-WORKFLOW.md`):

```
Start.UnityEntry._game → Game.Game.<GameModel> → GameModel._battleModel
 → BattleModel.<BattleEntitiesModel> → BattleEntitiesModel._worldEntitiesModel
 → WorldEntitiesModel._battleCharacters (Dictionary<int, BattleCharacterModel>)
```

Даёт точный список акторов и флаг бота (`PlayerBattleModel == null`). Позиция модели читается из `<Transform>` (`_x/_y/_z` → `FloatData._value`), HP — из `<PrivateModel>.<Health>._health._value` / `_maxAmount`.

## Меню

`menu/ui.cpp`: табы слева (Aim / Visuals / Players / NPC / Misc / Configs), две панели по 229 px, кастомная отрисовка фона через `GetBackgroundDrawList`.
Глобальные переключатели: `esp_enabled, esp_boxes, esp_names, esp_distance, esp_skeleton, esp_npc, esp_tracers, esp_loot` и заглушки `aim_*`, `noclip`, `speedhack`, `no_recoil`.

`esp_npc` сейчас гейтит отрисовку всех персонажей (разделение NPC/игроки появится, когда будет доступ к модели сущности).
