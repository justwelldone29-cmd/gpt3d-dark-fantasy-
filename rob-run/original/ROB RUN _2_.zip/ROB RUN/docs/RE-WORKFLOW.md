# RE-WORKFLOW — как искать данные в этом билде

Билд: Unity 6000.3.18f1, IL2CPP, `global-metadata.dat` v39.
Путь к игре: `D:\steam\steamapps\common\Rob Run`.

Три маршрута, от самого дешёвого к самому точному.

## 1. Runtime-дамп IL2CPP (сделан)

Полный дамп уже снят: `dump/full_sdk.jsonl`, 38 077 классов с оффсетами полей и RVA методов. Повторить:

```powershell
python "C:\Users\sss\Desktop\ROB RUN\client\frida\run_dump.py"
```

Скрипт сам поднимает игру с заглушками `EOS_AntiCheatClient_*` (`stub_ac.js`), ждёт инициализацию IL2CPP и пишет JSONL. Без заглушек игра падает с `E-0501`.

Ниже — исходное описание подхода.

Статический Il2CppDumper не читает v39. Используется runtime-дампер, который цепляется к живому процессу и сам обходит `Il2CppDomain → assemblies → images → classes`.

- Longno242/IL2CPP-Dumper, режим `dumper.dll` (инжект в процесс) — выдаёт `_Offset` полей и `_RVA` методов.
- Что даёт: точные оффсеты для `BattleCharacterModel`, `BattleEntitiesModel`, `WorldEntitiesModel`, `HealthModel`, `FloatData._value` без гаданий по `dump/classes.jsonl`.

Порядок:

```
1. Запустить игру через harness (AC-заглушки), дойти до лобби.
2. Инжектить dumper.dll в ROB RUN.exe.
3. Забрать images/*.json (или .cs) и сохранить в dump/runtime/.
4. Сверить поля из docs/IL2CPP-MAP.md.
```

## 2. x64dbg (когда нужен момент создания объекта)

```
1. Игра запущена через harness.
2. x64dbg → File → Attach → ROB RUN.exe.
3. Modules → GameAssembly.dll (base).
4. Символы: экспорты il2cpp_* видны в Symbols.
```

Полезные точки:

| Что ищем | Куда ставить BP |
|---|---|
| Резолв классов игрой | `il2cpp_class_from_name` (RVA экспорта) |
| Получение оффсета поля | `il2cpp_field_get_offset` |
| Создание сущностей | `BattleEntitiesModelUpdater` методы (RVA из dump/classes.jsonl) |
| Чтение модели персонажа | `BattleCharacterModel.get_*` / `get_Value` у `PrimitiveModel` |

Практика: ставить hardware BP на поле `_battleCharacters` (адрес словаря) и смотреть, кто пишет; либо BP на `il2cpp_class_from_name` с фильтром по строке `BattleCharacterModel`.

## 3. Cheat Engine (если нужен статический указатель, а не IL2CPP API)

1. Найти координату персонажа (float, меняется при движении).
2. Pointer scan вверх до `WorldEntitiesModel._battleCharacters`.
3. Structure Dissect по найденному словарю — сверить с полями из дампа.
4. Записать цепочку оффсетов; помнить, что она ломается на каждом патче.

## 4. Наша собственная точка входа (уже в коде)

`features/esp.cpp` резолвит цепочку в рантайме через IL2CPP API и не зависит от статических оффсетов:

```
Start.UnityEntry._game
  → Game.Game.<GameModel>k__BackingField
  → GameModel._battleModel
  → BattleModel.<BattleEntitiesModel>k__BackingField
  → BattleEntitiesModel._worldEntitiesModel
  → WorldEntitiesModel._battleCharacters   (Dictionary<int, BattleCharacterModel>)
```

Проверено в игре: словарь перебирается, `actors=8..10`, `bots=7..9` (бот = `PlayerBattleModel == null`).

Не решено: привязка модели к отрисованному персонажу. `BattleCharacterModel.<CenterPosition>` пустой/не даёт координат — читать позицию из `<Transform>` (`TransformModel._x/_y/_z`, каждое — `IPrimitiveData<float>`, конкретный класс `FloatData`, значение в `BasePrimitiveData<float>._value`).

## 5. Правила

- Оффсеты не хардкодить: `il2cpp_field_get_offset` по имени поля в рантайме.
- Для generic-классов (`Dictionary<int,T>`, `PrimitiveData<T>`) методы искать у конкретного инстанса: `il2cpp_object_get_class` → `class_get_method_from_name`.
- Struct-энумератор словаря: `get_Values` → `GetEnumerator` (boxed), дальше `this` для `MoveNext/get_Current` — **указатель на распакованные данные** (`il2cpp_object_unbox`).
- Аттач отладчика к процессу с EAC-заглушками безопасен; к реальному EAC — нет.
