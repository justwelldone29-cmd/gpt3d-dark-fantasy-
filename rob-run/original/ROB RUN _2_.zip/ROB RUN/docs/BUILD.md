# BUILD — сборка и запуск

## Требования

| Что | Версия / путь |
|---|---|
| MSVC | VS 2022 BuildTools, `C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools` |
| Windows SDK | 10.0.22621 (ставится вместе с BuildTools) |
| Python | 3.x + `pip install frida frida-tools` |
| Steam | запущен, аккаунт залогинен (**тестовый**, не основной) |
| Игра | `D:\steam\steamapps\common\Rob Run\ROB RUN.exe` |

Пути к игре зашиты в `client/frida/run_menu_test.py` и `client/frida/menu_test.js`. При переносе игры — править оба файла (`EXE`, `CWD`, `DLL_PATH`).

## Сборка DLL

```bat
cd "C:\Users\sss\Desktop\ROB RUN\client\internal"
build.bat
```

Ожидаемый вывод — `BUILD_OK` и `internal.dll` (~820 КБ). Флаги: `/LD /std:c++20 /O2 /EHsc`, линковка `d3d11 dxgi user32 gdi32`.

Игра должна быть **закрыта**: загруженная DLL держит файл, линковка упадёт с `LNK1104`.

## Запуск (Frida harness)

```powershell
python "C:\Users\sss\Desktop\ROB RUN\client\frida\run_menu_test.py" 1800
```

Что делает harness (`run_menu_test.py` + `menu_test.js`):

1. `frida.spawn` игры с `cwd` каталога игры.
2. Загружает `EOSSDK-Win64-Shipping.dll` вручную.
3. Подменяет все 25 экспортов `EOS_AntiCheatClient_*` заглушками (`Interceptor.replace`), `EOS_Platform_GetAntiCheatClientInterface` возвращает пустышку.
4. `resume`, затем через 12 с — `Module.load(internal.dll)`.
5. Держит процесс `SECS` секунд, печатает `alive after`.

Аргумент — сколько секунд держать сессию (по умолчанию 180).

## Логи

Пишутся из DLL рядом с ней:

```
client\internal\internal.log
```

Префиксы: `[boot]`, `[init]`, `[hook]`, `[input]`, `[esp]`, `[rig]`, `[rigfail]`, `[slots]`, `[npc]`, `[marker]`, `[ov]`, `[local]`.
Лог открывается/закрывается на каждую запись — можно читать на ходу:

```powershell
Get-Content 'C:\Users\sss\Desktop\ROB RUN\client\internal\internal.log' -Tail 40
```

## Типовые проблемы

| Симптом | Причина | Решение |
|---|---|---|
| `BUILD_OK` не появился | синтаксис/линковка | смотреть вывод `cl.exe` выше |
| `LNK1104: internal.dll` | игра запущена | закрыть процесс `ROB RUN` |
| Игра висит на «подготовка шейдеров» | первый запуск/кэш | подождать 1–2 мин, при повторе — перезапуск |
| `SteamInitializationError E-0405` | Steam не запущен/не залогинен | запустить Steam |
| Меню не открывается | DLL не загрузилась | смотреть `[boot]`/`[hook]` в логе; проверить `MSG [+] internal.dll loaded` в консоли harness |
| Чёрный экран при старте | хук Present встал раньше устройства | перезапуск; в логе должно быть `[hook] first present` |
| Аккаунт заблокирован | серверный AC | ждать срок, тестить на другом аккаунте |

## Чистка

```powershell
Get-Process 'ROB RUN' -ErrorAction SilentlyContinue | Stop-Process -Force
Get-CimInstance Win32_Process -Filter "Name='python.exe'" |
  Where-Object { $_.CommandLine -like '*run_menu_test*' } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
```

## Kernel-путь (BYOVD)

`driver/` содержит инжектор и шеллкод. Направление рабочее; снят только carrier `gdrv.sys` — он дал BSOD `0x3B` (`gdrv+0x29F4`). Нужен новый подписанный драйвер: `diag.exe` → `proc_read.exe` → `inject.exe --go`, и только на ВМ с WinDbg.
