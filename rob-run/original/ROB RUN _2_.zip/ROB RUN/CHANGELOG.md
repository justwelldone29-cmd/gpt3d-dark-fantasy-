# CHANGELOG

## 0.6.0 — runtime SDK dump и данные из модели

- Снят полный дамп IL2CPP с живой игры: `dump/full_sdk.jsonl`, 38 077 классов, поля с оффсетами/флагами, методы с RVA. Скрипты: `client/frida/dump_il2cpp.js`, `run_dump.py`, `stub_ac.js`.
- Модель персонажа читается по точным оффсетам: `<Id>` +0x038, `<Transform>` +0x058, `<PrivateModel>` +0x010, `<PlayerBattleModel>` +0x258.
- Позиция: `TransformModel._x/_y/_z` → `IPrimitiveData<float>._value`.
- HP: `PrivateModel.Health` (+0x1B0) → `_health._value` / `_maxAmount` (+0x020); рисуется полоска слева от бокса.
- BOT: `<PlayerBattleModel> == null`, привязка модели к костям по позиции (2 м).

## 0.5.0 — модель сущностей и оптимизация рендера

- Найдена и проверена цепочка моделей: `Start.UnityEntry._game` → `Game.Game.<GameModel>` → `BattleModel.<BattleEntitiesModel>` → `WorldEntitiesModel._battleCharacters`. Перебор даёт `actors=8..10`, `bots=7..9`.
- W2S перенесён в C++: матрицы `worldToCameraMatrix × projectionMatrix` читаются один раз за кадр, кости проецируются умножением 4×4. Проверено: результат совпадает с `Camera.WorldToScreenPoint` пиксель-в-пиксель.
- Список персонажей — раз в 1 с, маркеры — раз в 3 с (было 400/1500 мс и тяжёлый скан `BattleCharacterEntityView`, дававший 47–63 мс фризы).
- Дедуп: ключ `hips`, слияние по позиции 0.35 м; фильтр разрушенных transform'ов (`y < -100`).
- Свой персонаж: отсев по «близко + по центру» и по высоте бокса > 62 % экрана.
- BOT: из модели (`PlayerBattleModel == null`), fallback — 3D-маркер над головой.
- Скелет: не дальше 120 м, при выключенном скелете читаются только 6 ключевых костей.
- Весь отладочный код и логи ESP вырезаны.

## 0.4.0 — ESP по костям

- Бокс строится по костям (`M_head_2` → стопы), а не по `Renderer.bounds`; ширина = 0.45 высоты.
- Скелет: рёбра `hips→spine2→spine3`, руки `arm0..arm3`, ноги `leg1..leg3→foot`, шея/голова.
- Голова — окружность в `M_head_2`, радиус от `head_1…head_2`.
- Матчинг костей по суффиксу (`_spine_1_jnt`, `L_arm_0_jnt`, …) — переживает префиксы `M_`/`F_` и варианты рига на 38/53/54/61/84/94 кости.
- Кэш `renderer → Rig`, имена костей читаются только на промахе.
- Дедуп персонажей: по `hips` + по позиции 0.9 м (убирает двойные скелеты LOD-клонов).
- Отсев своего персонажа: ближайший к камере `BattleCharacterEntityView` (offset `_FollowCamera` 88), проверка цепочки предков, отсев бокса выше 75 % экрана, fallback по ближайшему в радиусе 3.2 м.

## 0.3.0 — меню и ввод

- Present-хук переведён на поток Present-кадра; `ImGui_ImplWin32_WndProcHandler` больше не используется для меню.
- Ввод: `GetCursorPos` + `GetAsyncKeyState`, виртуальный курсор рисуется в `GetForegroundDrawList` (игра прячет системный).
- Меню таскается за шапку (`InvisibleButton` 26 px), позиция хранится в `menu_pos`.
- Все чекбоксы заменены на кастомные тумблеры (`InvisibleButton` + `IsItemClicked`).
- Добавлен таб **NPC** с отдельными тумблерами.

## 0.2.0 — классификация

- `PLAYER`/`BOT` метки; боты определяются по `NpcView` в иерархии и близости `Marker3DView` (жёлтый «!»).
- Попытка HP через `CharacterOverlayStatView._progress.fillAmount` — значение всегда 0, отрисовка заглушена.
- Логи `[npc]`, `[marker]`, `[ov]`, `[slots]`, `[rigfail]` для диагностики.

## 0.1.0 — база

- D3D11 Present hook, ImGui 1.90.7, меню с табами.
- IL2CPP-биндинги: резолв экспортов `GameAssembly.dll`, `invoke`, массивы, строки, оффсеты полей.
- Первый ESP: `FindObjectsOfTypeAll(SkinnedMeshRenderer)`, проекция `Camera.WorldToScreenPoint`.
