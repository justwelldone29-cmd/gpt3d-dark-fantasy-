import frida, time, sys

EXE = r"D:\steam\steamapps\common\Rob Run\ROB RUN.exe"
CWD = r"D:\steam\steamapps\common\Rob Run"
SCRIPT = r"C:\Users\sss\Desktop\ROB RUN\client\frida\proto3.js"
SECS = int(sys.argv[1]) if len(sys.argv) > 1 else 45

src = open(SCRIPT, encoding="utf-8").read()

dev = frida.get_local_device()
pid = dev.spawn([EXE], cwd=CWD)
print("spawned", pid, flush=True)
session = dev.attach(pid)
script = session.create_script(src)

def on_msg(msg, data):
    if msg.get("type") == "send":
        print("MSG", msg.get("payload"), flush=True)
    else:
        print("ERR", msg, flush=True)

script.on("message", on_msg)
script.load()
print("script loaded; resuming", flush=True)
dev.resume(pid)

time.sleep(SECS)

alive = any(p.pid == pid for p in dev.enumerate_processes())
print("alive after", SECS, "s:", alive, flush=True)
try:
    session.detach()
    print("detached", flush=True)
except Exception as e:
    print("detach err", e, flush=True)
