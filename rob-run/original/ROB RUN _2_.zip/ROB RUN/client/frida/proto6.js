// proto6.js — probe OnMessageToServer delivery: hook handler + try two Info layouts
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }
function hex(p, n) { try { const b = new Uint8Array(p.readByteArray(n)); let s=''; for (let i=0;i<b.length;i++) s+=b[i].toString(16).padStart(2,'0'); return s; } catch(e){ return 'ERR'; } }

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummyHandle = Memory.alloc(0x100);

let cbPtr = NULL, clientData = NULL, rxCount = 0;
let injectedA = false, injectedB = false;
let handlerHit = 0;

function inject(bufPtr, len, layout) {
    if (cbPtr.isNull()) { log('[!] cb null'); return; }
    try {
        const info = Memory.alloc(0x28);
        info.writeByteArray(new Uint8Array(0x28));
        if (layout === 'A') {
            info.writePointer(clientData);        // +0 ClientData
            info.add(8).writePointer(bufPtr);     // +8 MessageData
            info.add(16).writeU32(len);           // +16 Size
        } else {
            info.writeU32(1);                     // +0 ApiVersion
            info.add(8).writePointer(clientData); // +8 ClientData
            info.add(16).writePointer(bufPtr);    // +16 MessageData
            info.add(24).writeU32(len);           // +24 Size
        }
        const fn = new NativeFunction(cbPtr, 'void', ['pointer']);
        log('[inject ' + layout + '] cb=' + cbPtr + ' data=' + hex(bufPtr, len));
        fn(info);
        log('[inject ' + layout + '] returned');
    } catch (e) { log('[inject ' + layout + '] EXC ' + e.message); }
}

const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const cb = new NativeCallback(function (a, b, c, d) {
        try {
            if (name === 'EOS_AntiCheatClient_AddNotifyMessageToServer') {
                clientData = c; cbPtr = d;
                log('[+cb] clientData=' + c + ' cb=' + d);
            } else if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                const len = b.add(4).readU32();
                const pData = b.add(8).readPointer();
                rxCount++;
                if (rxCount <= 3) log('[rx ' + rxCount + '] len=' + len + ' HEX ' + hex(pData, len <= 128 ? len : 32));
                if (!injectedA && rxCount === 3 && len > 0 && len <= 128) {
                    injectedA = true;
                    const copy = Memory.alloc(len);
                    copy.writeByteArray(new Uint8Array(pData.readByteArray(len)));
                    inject(copy, len, 'A');
                } else if (!injectedB && rxCount === 10 && len > 0 && len <= 128) {
                    injectedB = true;
                    const copy = Memory.alloc(len);
                    copy.writeByteArray(new Uint8Array(pData.readByteArray(len)));
                    inject(copy, len, 'B');
                }
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return isNotify ? 1 : 0;
    }, isNotify ? 'uint64' : 'int', ['pointer','pointer','pointer','pointer','pointer','pointer']);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummyHandle); } });
} catch (e) { log('[!] GI: ' + e.message); }

// hooks for the game's AC handler methods
let hooked = false;
const timer = setInterval(function () {
    if (hooked) { clearInterval(timer); return; }
    const ga = Process.findModuleByName('GameAssembly.dll');
    if (!ga) return;
    try {
        function E(n) { return ga.getExportByName(n); }
        const fnDg = new NativeFunction(E('il2cpp_domain_get'), 'pointer', []);
        const fnDga = new NativeFunction(E('il2cpp_domain_get_assemblies'), 'pointer', ['pointer','pointer']);
        const fnAgi = new NativeFunction(E('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
        const fnCfn = new NativeFunction(E('il2cpp_class_from_name'), 'pointer', ['pointer','pointer','pointer']);
        const fnMgfn = new NativeFunction(E('il2cpp_class_get_method_from_name'), 'pointer', ['pointer','pointer','int']);
        const domain = fnDg();
        if (domain.isNull()) return;
        const cnt = Memory.alloc(8);
        const asms = fnDga(domain, cnt);
        const n = cnt.readU64().toNumber();
        if (n <= 0) return;
        const ns = Memory.allocUtf8String('Game.Battle.AntiCheat');
        const cl = Memory.allocUtf8String('AntiCheatBattleUpdater');
        let klass = NULL;
        for (let i = 0; i < n && i < 2000; i++) {
            const img = fnAgi(asms.add(i * Process.pointerSize).readPointer());
            if (img.isNull()) continue;
            const k = fnCfn(img, ns, cl);
            if (!k.isNull()) { klass = k; break; }
        }
        if (klass.isNull()) return;

        ['OnMessageToServer','SendMessageToServer'].forEach(function (mn) {
            const mi = fnMgfn(klass, Memory.allocUtf8String(mn), 1);
            if (mi.isNull()) return;
            const mp = mi.readPointer();
            Interceptor.attach(mp, {
                onEnter(args) {
                    try {
                        if (mn === 'OnMessageToServer') {
                            handlerHit++;
                            log('[handler] OnMessageToServer hit=' + handlerHit + ' arg=' + args[1] + ' raw48=' + hex(args[1], 0x30));
                        } else {
                            log('[game tx] SendMessageToServer obj=' + args[1]);
                        }
                    } catch (e) { log('[hook err] ' + e.message); }
                }
            });
            log('[+] hooked ' + mn + ' @ ' + mp);
        });
        hooked = true;
        clearInterval(timer);
    } catch (e) { /* retry */ }
}, 500);

log('[+] agent ready');
