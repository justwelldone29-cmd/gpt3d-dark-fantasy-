// proto.js — EAC protocol capture v1
// Keeps AC stubs so the game runs; dumps raw inbound AC messages + options.
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }
function hex(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    } catch (e) { return 'ERR ' + e.message; }
}
function ascii(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += (b[i] >= 32 && b[i] < 127) ? String.fromCharCode(b[i]) : '.';
        return s;
    } catch (e) { return 'ERR'; }
}
function readable(p, n) {
    try { const r = Process.findRangeByAddress(p); return r !== null && n < 0x100000; } catch (e) { return false; }
}

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
log('[+] base ' + mod.base);

const dummyHandle = Memory.alloc(0x100);
log('[+] dummy @ ' + dummyHandle);

const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
Interceptor.attach(gi, {
    onLeave(retval) { retval.replace(dummyHandle); }
});

const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports ' + acExports.length);
const cbArgs = ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer'];

let rxCount = 0;

acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const retType = isNotify ? 'uint64' : 'int';
    const retVal = isNotify ? 1 : 0;

    const cb = new NativeCallback(function (a, b, c, d, f, g) {
        try {
            if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                rxCount++;
                if (rxCount <= 10) {
                    log('[rx ' + rxCount + '] opt=' + b + ' raw=' + hex(b, 0x20));
                    const api = b.readS32();
                    const pData = b.add(8).readPointer();
                    const len = b.add(16).readU32();
                    log('[rx ' + rxCount + '] api=' + api + ' data=' + pData + ' len=' + len);
                    if (readable(pData, len) && len > 0 && len < 0x10000) {
                        log('[rx ' + rxCount + '] HEX ' + hex(pData, Math.min(len, 128)));
                        log('[rx ' + rxCount + '] ASC ' + ascii(pData, Math.min(len, 64)));
                    } else {
                        const pAlt = b.add(16).readPointer();
                        const lenAlt = b.add(24).readU32();
                        log('[rx ' + rxCount + '] alt p16=' + pAlt + ' len24=' + lenAlt);
                        if (readable(pAlt, lenAlt) && lenAlt > 0 && lenAlt < 0x10000) {
                            log('[rx ' + rxCount + '] ALT HEX ' + hex(pAlt, Math.min(lenAlt, 128)));
                        }
                    }
                } else if (rxCount % 25 === 0) {
                    log('[rx ' + rxCount + '] opt=' + b + ' raw=' + hex(b, 0x18));
                }
            } else if (name === 'EOS_AntiCheatClient_BeginSession') {
                log('[begin] opt=' + b + ' raw=' + hex(b, 0x30));
                const api = b.readS32();
                const uid = b.add(8).readPointer();
                const mode = b.add(16).readS32();
                log('[begin] api=' + api + ' uidPtr=' + uid + ' uidStr=' + (readable(uid, 64) ? ascii(uid, 48) : '?') + ' mode=' + mode);
            } else if (name === 'EOS_AntiCheatClient_GetModuleBuildId') {
                log('[buildid] h=' + a + ' opt=' + b + ' out=' + c + ' lenPtr=' + d);
                log('[buildid] optRaw=' + hex(b, 0x10));
                if (readable(c, 16)) log('[buildid] outBefore=' + ascii(c, 16));
                if (readable(d, 4)) log('[buildid] lenBefore=' + d.readU32());
            } else if (name === 'EOS_AntiCheatClient_AddNotifyMessageToServer') {
                log('[notify] h=' + a + ' opt=' + b + ' cb=' + c + ' clientData=' + d + ' optRaw=' + hex(b, 0x10));
            } else if (name === 'EOS_AntiCheatClient_AddNotifyClientIntegrityViolated') {
                log('[integrity] h=' + a + ' opt=' + b + ' cb=' + c + ' clientData=' + d);
            } else {
                log('[call] ' + name + ' a=' + a + ' b=' + b + ' c=' + c + ' d=' + d);
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return retVal;
    }, retType, cbArgs);

    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

log('[+] agent ready');
