// stub_ac.js — replace EOS AntiCheat client exports with no-ops so the game boots.
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }

try { Module.load(DLL_PATH); } catch (e) { log('[!] sdk load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummy = Memory.alloc(0x100);
const ac = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports: ' + ac.length);

ac.forEach(function (e) {
    const isNotify = e.name.indexOf('AddNotify') !== -1;
    const cb = new NativeCallback(function () { return isNotify ? 1 : 0; },
        isNotify ? 'uint64' : 'int', ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer']);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] replace ' + e.name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummy); } });
} catch (e) { log('[!] GI: ' + e.message); }
log('[+] AC stubs ready');
