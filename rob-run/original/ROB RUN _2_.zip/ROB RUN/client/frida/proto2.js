// proto2.js — EAC protocol capture, corrected options layout
// ReceiveMessageFromServerOptions: +0 ApiVersion(i32), +8 DataLength(u32), +16 Data(ptr), +24 aux(ptr)
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }
function hex(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    } catch (e) { return 'ERR'; }
}
function ascii(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += (b[i] >= 32 && b[i] < 127) ? String.fromCharCode(b[i]) : '.';
        return s;
    } catch (e) { return 'ERR'; }
}
function readable(p, n) {
    try { const r = Process.findRangeByAddress(p); return r !== null && n < 0x100000; } catch (e) { return false; }
}

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
log('[+] EOSSDK base ' + mod.base);
try { log('[+] GameAssembly base ' + Process.getModuleByName('GameAssembly.dll').base); } catch (e) {}

const dummyHandle = Memory.alloc(0x100);
const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports ' + acExports.length);
const cbArgs = ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer'];
let rxCount = 0;

acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const retType = isNotify ? 'uint64' : 'int';
    const retVal = isNotify ? 1 : 0;

    const cb = new NativeCallback(function (a, b, c, d, f, g) {
        try {
            if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                rxCount++;
                const api = b.readS32();
                const len = b.add(8).readU32();
                const pData = b.add(16).readPointer();
                const pAux = b.add(24).readPointer();
                log('[rx ' + rxCount + '] api=' + api + ' len=' + len + ' data=' + pData + ' aux=' + pAux);
                if (len > 0 && len <= 256 && readable(pData, len)) {
                    log('[rx ' + rxCount + '] HEX ' + hex(pData, len));
                    log('[rx ' + rxCount + '] ASC ' + ascii(pData, Math.min(len, 64)));
                }
                if (readable(pAux, 0x20)) log('[rx ' + rxCount + '] AUX ' + hex(pAux, Math.min(len > 0 && len <= 64 ? len : 32, 32)));
            } else if (name === 'EOS_AntiCheatClient_BeginSession') {
                const api = b.readS32();
                const uid = b.add(16).readPointer();
                const mode = b.add(24).readS32();
                log('[begin] api=' + api + ' uidPtr=' + uid + ' uid=' + (readable(uid, 64) ? ascii(uid, 48) : '?') + ' mode=' + mode);
                log('[begin] raw=' + hex(b, 0x40));
            } else if (name === 'EOS_AntiCheatClient_GetModuleBuildId') {
                log('[buildid] opt=' + hex(b, 0x10) + ' out=' + c + ' arg3=' + d);
                if (readable(c, 32)) log('[buildid] out=' + ascii(c, 32) + ' hex=' + hex(c, 32));
            } else if (name === 'EOS_AntiCheatClient_AddNotifyMessageToServer' ||
                       name === 'EOS_AntiCheatClient_AddNotifyClientIntegrityViolated' ||
                       name === 'EOS_AntiCheatClient_AddNotifyPeerActionRequired' ||
                       name === 'EOS_AntiCheatClient_AddNotifyPeerAuthStatusChanged' ||
                       name === 'EOS_AntiCheatClient_AddNotifyMessageToPeer') {
                log('[' + name.replace('EOS_AntiCheatClient_', '') + '] a=' + a + ' opt=' + b + ' c=' + c + ' cb=' + d);
            } else {
                log('[call] ' + name + ' a=' + a + ' b=' + b + ' c=' + c + ' d=' + d);
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return retVal;
    }, retType, cbArgs);

    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

// fake interface pointer
try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(retval) { retval.replace(dummyHandle); } });
} catch (e) { log('[!] GI: ' + e.message); }

log('[+] agent ready');
