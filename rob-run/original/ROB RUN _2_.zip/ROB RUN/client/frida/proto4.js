// proto4.js — inject a fabricated OnMessageToServer payload to probe server validation
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }
function hex(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    } catch (e) { return 'ERR'; }
}
function readable(p, n) {
    try { const r = Process.findRangeByAddress(p); return r !== null && n < 0x100000; } catch (e) { return false; }
}

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummyHandle = Memory.alloc(0x100);

let msgToServerCb = NULL;
let msgToServerClientData = 0;

// --- EOS stubs + capture ---
const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
const cbArgs = ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer'];

acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const retType = isNotify ? 'uint64' : 'int';
    const retVal = isNotify ? 1 : 0;
    const cb = new NativeCallback(function (a, b, c, d, f, g) {
        try {
            if (name === 'EOS_AntiCheatClient_AddNotifyMessageToServer') {
                msgToServerClientData = c.toInt32 ? c.toInt32() : 0;
                msgToServerCb = d;
                log('[+cb] MessageToServer clientData=' + c + ' cb=' + d);
            } else if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                const len = b.add(4).readU32();
                const pData = b.add(8).readPointer();
                if (len !== 24) log('[eos rx] len=' + len + ' HEX ' + (readable(pData, len) ? hex(pData, Math.min(len, 64)) : '?'));
            } else if (name === 'EOS_AntiCheatClient_BeginSession') {
                log('[begin] h=' + a);
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return retVal;
    }, retType, cbArgs);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummyHandle); } });
} catch (e) { log('[!] GI: ' + e.message); }

// --- Game-level hooks, installed after GameAssembly loads ---
let hooked = false;
let rxGame = 0;
let injected = false;

function callOnMessageToServer(bufPtr, len) {
    if (msgToServerCb.isNull()) { log('[!] cb not captured'); return; }
    try {
        const info = Memory.alloc(0x18);
        info.writePointer(ptr(msgToServerClientData));
        info.add(8).writePointer(bufPtr);
        info.add(16).writeU32(len);
        const fn = new NativeFunction(msgToServerCb, 'void', ['pointer']);
        log('[inject] calling cb ' + msgToServerCb + ' with ' + hex(bufPtr, len));
        fn(info);
        log('[inject] cb returned');
    } catch (e) {
        log('[inject] error ' + e.message);
    }
}

function tryHookGame() {
    const ga = Process.findModuleByName('GameAssembly.dll');
    if (!ga) return false;
    try {
        function E(n) { return ga.getExportByName(n); }
        const fnDg = new NativeFunction(E('il2cpp_domain_get'), 'pointer', []);
        const fnDga = new NativeFunction(E('il2cpp_domain_get_assemblies'), 'pointer', ['pointer', 'pointer']);
        const fnAgi = new NativeFunction(E('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
        const fnCfn = new NativeFunction(E('il2cpp_class_from_name'), 'pointer', ['pointer', 'pointer', 'pointer']);
        const fnMgfn = new NativeFunction(E('il2cpp_class_get_method_from_name'), 'pointer', ['pointer', 'pointer', 'int']);

        const domain = fnDg();
        if (domain.isNull()) return false;
        const cnt = Memory.alloc(8);
        const asms = fnDga(domain, cnt);
        const n = cnt.readU64().toNumber();
        if (n <= 0) return false;

        const nsStr = Memory.allocUtf8String('Game.Battle.AntiCheat');
        const clStr = Memory.allocUtf8String('AntiCheatBattleUpdater');
        let klass = NULL;
        for (let i = 0; i < n && i < 2000; i++) {
            const img = fnAgi(asms.add(i * Process.pointerSize).readPointer());
            if (img.isNull()) continue;
            const k = fnCfn(img, nsStr, clStr);
            if (!k.isNull()) { klass = k; break; }
        }
        if (klass.isNull()) return false;

        const mi = fnMgfn(klass, Memory.allocUtf8String('ReceiveMessageFromServer'), 1);
        if (mi.isNull()) return false;
        const mp = mi.readPointer();
        if (mp.isNull()) return false;

        Interceptor.attach(mp, {
            onEnter(args) {
                try {
                    rxGame++;
                    const arr = args[1];
                    const len = arr.add(24).readU32();
                    const data = arr.add(32);
                    log('[game rx ' + rxGame + '] len=' + len + ' HEX ' + (len > 0 && len <= 128 && readable(data, len) ? hex(data, len) : '?'));
                    if (!injected && rxGame >= 3) {
                        injected = true;
                        // copy payload, then inject
                        const copy = Memory.alloc(len);
                        copy.writeByteArray(new Uint8Array(data.readByteArray(len)));
                        callOnMessageToServer(copy, len);
                    }
                } catch (e) { log('[game hook err] ' + e.message); }
            }
        });

        // log server-bound messages
        const mi2 = fnMgfn(klass, Memory.allocUtf8String('SendMessageToServer'), 1);
        if (!mi2.isNull()) {
            const mp2 = mi2.readPointer();
            Interceptor.attach(mp2, { onEnter(a) { log('[game tx] obj=' + a[1]); } });
        }
        log('[+] game hooks installed, klass=' + klass + ' rx=' + mp);
        return true;
    } catch (e) {
        return false;
    }
}

const timer = setInterval(function () {
    if (hooked) { clearInterval(timer); return; }
    if (tryHookGame()) { hooked = true; clearInterval(timer); }
}, 500);

log('[+] agent ready');
