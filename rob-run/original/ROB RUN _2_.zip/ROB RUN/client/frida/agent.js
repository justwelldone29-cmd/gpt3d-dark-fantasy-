// agent.js — EOS AntiCheatClient emulation experiment v3
// Interceptor.replace: original EOS AC code never executes (no deref of the fake handle).
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
log('[+] base ' + mod.base);

const dummyHandle = Memory.alloc(0x100);
log('[+] dummy handle @ ' + dummyHandle);

// Fake interface pointer (original returns null when EAC module is absent)
try {
    const addr = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(addr, {
        onEnter(args) { log('[call] GetAntiCheatClientInterface'); },
        onLeave(retval) {
            log('[ret ] GetAntiCheatClientInterface orig=' + retval + ' -> dummy');
            retval.replace(dummyHandle);
        }
    });
} catch (e) { log('[!] GetAntiCheatClientInterface: ' + e.message); }

// Replace every AntiCheatClient export with a stub.
const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports: ' + acExports.length);
const cbArgs = ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer'];

acExports.forEach(function (e) {
    const isNotify = e.name.indexOf('AddNotify') !== -1;
    const retType = isNotify ? 'uint64' : 'int';
    const retVal = isNotify ? 1 : 0;
    try {
        const cb = new NativeCallback(function (a, b, c, d, f, g) {
            log('[call] ' + e.name);
            return retVal;
        }, retType, cbArgs);
        Interceptor.replace(e.address, cb);
    } catch (err) {
        log('[!] ' + e.name + ': ' + err.message);
    }
});

log('[+] agent ready');
