// dump_il2cpp.js — full runtime SDK dump via exported il2cpp API (Unity 6, metadata v39).
// Output: one JSON per class: {a: assembly, n: full name, p: parent, f: [[name, offset, type, flags]], m: [[name, argc, rva]]}

const GA = 'GameAssembly.dll';
const mod = Process.getModuleByName(GA);
const base = mod.base;

function E(n) {
    const p = mod.findExportByName(n);
    if (p.isNull()) throw new Error('missing export ' + n);
    return p;
}

const fn = {
    domain_get: new NativeFunction(E('il2cpp_domain_get'), 'pointer', []),
    domain_get_assemblies: new NativeFunction(E('il2cpp_domain_get_assemblies'), 'pointer', ['pointer', 'pointer']),
    assembly_get_image: new NativeFunction(E('il2cpp_assembly_get_image'), 'pointer', ['pointer']),
    image_get_name: new NativeFunction(E('il2cpp_image_get_name'), 'pointer', ['pointer']),
    image_get_class_count: new NativeFunction(E('il2cpp_image_get_class_count'), 'size_t', ['pointer']),
    image_get_class: new NativeFunction(E('il2cpp_image_get_class'), 'pointer', ['pointer', 'uint32']),
    class_get_name: new NativeFunction(E('il2cpp_class_get_name'), 'pointer', ['pointer']),
    class_get_namespace: new NativeFunction(E('il2cpp_class_get_namespace'), 'pointer', ['pointer']),
    class_get_parent: new NativeFunction(E('il2cpp_class_get_parent'), 'pointer', ['pointer']),
    class_get_fields: new NativeFunction(E('il2cpp_class_get_fields'), 'pointer', ['pointer', 'pointer']),
    field_get_name: new NativeFunction(E('il2cpp_field_get_name'), 'pointer', ['pointer']),
    field_get_offset: new NativeFunction(E('il2cpp_field_get_offset'), 'int32', ['pointer']),
    field_get_type: new NativeFunction(E('il2cpp_field_get_type'), 'pointer', ['pointer']),
    field_get_flags: new NativeFunction(E('il2cpp_field_get_flags'), 'uint32', ['pointer']),
    type_get_name: new NativeFunction(E('il2cpp_type_get_name'), 'pointer', ['pointer']),
    class_get_methods: new NativeFunction(E('il2cpp_class_get_methods'), 'pointer', ['pointer', 'pointer']),
    method_get_name: new NativeFunction(E('il2cpp_method_get_name'), 'pointer', ['pointer']),
    method_get_param_count: new NativeFunction(E('il2cpp_method_get_param_count'), 'uint32', ['pointer'])
};

function str(p) {
    if (!p || p.isNull()) return '';
    try { return p.readUtf8String() || ''; } catch (e) { return ''; }
}

const domain = fn.domain_get();
const countPtr = Memory.alloc(8);
const assemblies = fn.domain_get_assemblies(domain, countPtr);
const asmCount = countPtr.readU64().toNumber();
send('assemblies: ' + asmCount);

let batch = [];
let total = 0;

function flush(force) {
    if (batch.length === 0) return;
    send(JSON.stringify(batch));
    batch = [];
}

for (let i = 0; i < asmCount; i++) {
    const asm = assemblies.add(i * Process.pointerSize).readPointer();
    if (asm.isNull()) continue;
    const img = fn.assembly_get_image(asm);
    if (img.isNull()) continue;
    const imgName = str(fn.image_get_name(img));
    const classCount = fn.image_get_class_count(img).toNumber();

    for (let c = 0; c < classCount; c++) {
        const klass = fn.image_get_class(img, c);
        if (klass.isNull()) continue;

        const ns = str(fn.class_get_namespace(klass));
        const cn = str(fn.class_get_name(klass));
        const full = (ns ? ns + '.' : '') + cn;
        const parent = fn.class_get_parent(klass);
        const parentName = parent.isNull() ? ''
            : ((str(fn.class_get_namespace(parent)) ? str(fn.class_get_namespace(parent)) + '.' : '') + str(fn.class_get_name(parent)));

        const fields = [];
        const fIter = Memory.alloc(Process.pointerSize);
        fIter.writePointer(NULL);
        for (;;) {
            const fld = fn.class_get_fields(klass, fIter);
            if (fld.isNull()) break;
            const off = fn.field_get_offset(fld);
            const flags = fn.field_get_flags(fld);
            fields.push([str(fn.field_get_name(fld)), off, str(fn.type_get_name(fn.field_get_type(fld))), flags]);
            if (fields.length >= 512) break;
        }

        const methods = [];
        const mIter = Memory.alloc(Process.pointerSize);
        mIter.writePointer(NULL);
        for (;;) {
            const mi = fn.class_get_methods(klass, mIter);
            if (mi.isNull()) break;
            let rva = 0;
            try {
                const ptr = mi.readPointer();
                if (!ptr.isNull()) rva = ptr.sub(base).toUInt32();
            } catch (e) { rva = 0; }
            methods.push([str(fn.method_get_name(mi)), fn.method_get_param_count(mi), rva]);
            if (methods.length >= 512) break;
        }

        batch.push({ a: imgName, n: full, p: parentName, f: fields, m: methods });
        total++;
        if (batch.length >= 200) flush();
    }
    send('image ' + imgName + ' classes=' + classCount + ' total=' + total);
}

flush();
send('DONE ' + total);
