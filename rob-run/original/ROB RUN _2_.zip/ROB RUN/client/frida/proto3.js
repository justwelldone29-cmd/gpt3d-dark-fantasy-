// proto3.js — EAC protocol capture with correct options layout + game-level AC hooks
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';
const GA = 'GameAssembly.dll';

function log(m) { send(m); }
function hex(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    } catch (e) { return 'ERR'; }
}
function readable(p, n) {
    try { const r = Process.findRangeByAddress(p); return r !== null && n < 0x100000; } catch (e) { return false; }
}

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummyHandle = Memory.alloc(0x100);

// --- EOS layer: stubs + capture ---
const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports ' + acExports.length);
const cbArgs = ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer'];
let rxCount = 0;

acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const retType = isNotify ? 'uint64' : 'int';
    const retVal = isNotify ? 1 : 0;

    const cb = new NativeCallback(function (a, b, c, d, f, g) {
        try {
            if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                rxCount++;
                const api = b.readU32();
                const len = b.add(4).readU32();
                const pData = b.add(8).readPointer();
                if (rxCount <= 24) {
                    log('[eos rx ' + rxCount + '] api=' + api + ' len=' + len + ' data=' + pData + ' HEX ' + (len > 0 && len <= 256 && readable(pData, len) ? hex(pData, len) : 'unreadable'));
                } else if (rxCount % 25 === 0) {
                    log('[eos rx ' + rxCount + '] len=' + len);
                }
            } else if (name === 'EOS_AntiCheatClient_BeginSession') {
                log('[begin] h=' + a + ' opt=' + b + ' raw=' + hex(b, 0x30));
            } else if (name === 'EOS_AntiCheatClient_GetModuleBuildId') {
                log('[buildid] opt=' + hex(b, 0x10) + ' out=' + c + ' a3=' + d);
            } else if (name.indexOf('AddNotify') !== -1) {
                log('[' + name.replace('EOS_AntiCheatClient_', '') + '] c=' + c + ' cb=' + d);
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return retVal;
    }, retType, cbArgs);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummyHandle); } });
} catch (e) { log('[!] GI: ' + e.message); }

// --- Game layer: hook AntiCheatBattleUpdater.ReceiveMessageFromServer(byte[]) ---
try {
    const ga = Process.getModuleByName(GA);
    function E(n) { return ga.getExportByName(n); }
    const fnDg = new NativeFunction(E('il2cpp_domain_get'), 'pointer', []);
    const fnDga = new NativeFunction(E('il2cpp_domain_get_assemblies'), 'pointer', ['pointer', 'pointer']);
    const fnAgi = new NativeFunction(E('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
    const fnCfn = new NativeFunction(E('il2cpp_class_from_name'), 'pointer', ['pointer', 'pointer', 'pointer']);
    const fnMgfn = new NativeFunction(E('il2cpp_class_get_method_from_name'), 'pointer', ['pointer', 'pointer', 'int']);

    const domain = fnDg();
    const cnt = Memory.alloc(8);
    const asms = fnDga(domain, cnt);
    const n = cnt.readU64().toNumber();
    const nsStr = Memory.allocUtf8String('Game.Battle.AntiCheat');
    const clStr = Memory.allocUtf8String('AntiCheatBattleUpdater');
    let klass = NULL;
    for (let i = 0; i < n && i < 2000; i++) {
        const img = fnAgi(asms.add(i * Process.pointerSize).readPointer());
        const k = fnCfn(img, nsStr, clStr);
        if (!k.isNull()) { klass = k; break; }
    }
    if (klass.isNull()) {
        log('[!] AntiCheatBattleUpdater not found');
    } else {
        log('[+] AntiCheatBattleUpdater @ ' + klass);
        ['ReceiveMessageFromServer', 'SendMessageToServer'].forEach(function (mn) {
            const mi = fnMgfn(klass, Memory.allocUtf8String(mn), 1);
            if (mi.isNull()) { log('[!] method ' + mn + ' not found'); return; }
            const mp = mi.readPointer();
            log('[+] ' + mn + ' @ ' + mp);
            Interceptor.attach(mp, {
                onEnter(args) {
                    try {
                        if (mn === 'ReceiveMessageFromServer') {
                            const arr = args[1];
                            const len = arr.add(24).readU32();
                            const data = arr.add(32);
                            log('[game rx] len=' + len + ' HEX ' + (len > 0 && len <= 256 && readable(data, len) ? hex(data, len) : '?'));
                        } else {
                            log('[game tx] obj=' + args[1]);
                        }
                    } catch (e) { log('[game hook err] ' + e.message); }
                }
            });
        });
    }
} catch (e) {
    log('[!] game hooks: ' + e.message);
}

log('[+] agent ready');
