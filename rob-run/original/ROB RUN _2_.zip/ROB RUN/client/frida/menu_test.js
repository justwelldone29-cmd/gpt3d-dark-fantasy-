// menu_test.js — EOS AC stubs + load internal.dll into the running game (no kernel).
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';
const INTERNAL = 'C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.dll';

function log(m) { send(m); }

try { Module.load(DLL_PATH); } catch (e) { log('[!] sdk load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummy = Memory.alloc(0x100);
const ac = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
log('[+] AC exports: ' + ac.length);

ac.forEach(function (e) {
    const isNotify = e.name.indexOf('AddNotify') !== -1;
    const cb = new NativeCallback(function (a, b, c, d) { return isNotify ? 1 : 0; },
        isNotify ? 'uint64' : 'int', ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer']);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] replace ' + e.name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummy); } });
} catch (e) { log('[!] GI: ' + e.message); }
log('[+] AC stubs ready');

setTimeout(function () {
    try {
        const m = Module.load(INTERNAL);
        log('[+] internal.dll loaded at ' + m);
    } catch (e) {
        log('[!] internal.dll load failed: ' + e.message);
    }
}, 12000);

log('[+] agent ready');
