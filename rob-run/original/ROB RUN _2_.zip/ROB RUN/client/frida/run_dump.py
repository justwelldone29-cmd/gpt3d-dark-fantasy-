import frida, time, json, os

EXE = r"D:\steam\steamapps\common\Rob Run\ROB RUN.exe"
CWD = r"D:\steam\steamapps\common\Rob Run"
STUB = r"C:\Users\sss\Desktop\ROB RUN\client\frida\stub_ac.js"
DUMP = r"C:\Users\sss\Desktop\ROB RUN\client\frida\dump_il2cpp.js"
OUT = r"C:\Users\sss\Desktop\ROB RUN\dump\full_sdk.jsonl"

if os.path.exists(OUT):
    os.remove(OUT)

dev = frida.get_local_device()
pid = dev.spawn([EXE], cwd=CWD)
print("spawned", pid, flush=True)

session = dev.attach(pid)
stub = session.create_script(open(STUB, encoding="utf-8").read())
stub.on("message", lambda m, d: print("STUB", m.get("payload"), flush=True) if m.get("type") == "send" else None)
stub.load()
print("stubs loaded, resuming", flush=True)
dev.resume(pid)

for i in range(90):
    time.sleep(1)
    break
print("waiting for il2cpp init", flush=True)
time.sleep(30)

count = 0
done = False

def on_msg(msg, data):
    global count, done
    if msg.get("type") != "send":
        print("ERR", msg.get("description"), flush=True)
        return
    p = msg.get("payload")
    if not isinstance(p, str):
        return
    if p.startswith("DONE "):
        done = True
        print("DONE", p, flush=True)
        return
    if not p.startswith("["):
        print(p, flush=True)
        return
    try:
        arr = json.loads(p)
    except Exception as e:
        print("json err", e, flush=True)
        return
    with open(OUT, "a", encoding="utf-8") as f:
        for rec in arr:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    count += len(arr)
    if count % 2000 < 200:
        print("classes written", count, flush=True)

script = session.create_script(open(DUMP, encoding="utf-8").read())
script.on("message", on_msg)
script.load()

for _ in range(900):
    time.sleep(1)
    if done:
        break

print("written", count, "done", done, flush=True)
try:
    session.detach()
except Exception:
    pass
try:
    dev.kill(pid)
except Exception:
    pass
