// proto5.js — invoke OnMessageToServer from inside the EOS ReceiveMessageFromServer stub
const DLL = 'EOSSDK-Win64-Shipping.dll';
const DLL_PATH = 'D:\\steam\\steamapps\\common\\Rob Run\\ROB RUN_Data\\Plugins\\x86_64\\EOSSDK-Win64-Shipping.dll';

function log(m) { send(m); }
function hex(p, n) {
    try {
        const b = new Uint8Array(p.readByteArray(n));
        let s = '';
        for (let i = 0; i < b.length; i++) s += b[i].toString(16).padStart(2, '0');
        return s;
    } catch (e) { return 'ERR'; }
}

try { Module.load(DLL_PATH); } catch (e) { log('[!] load: ' + e.message); }
const mod = Process.getModuleByName(DLL);
const dummyHandle = Memory.alloc(0x100);

let cbPtr = NULL;
let clientData = NULL;
let rxCount = 0;
let injected = false;

function inject(bufPtr, len) {
    if (cbPtr.isNull()) { log('[!] cb null'); return; }
    try {
        const info = Memory.alloc(0x18);
        info.writePointer(clientData);
        info.add(8).writePointer(bufPtr);
        info.add(16).writeU32(len);
        const fn = new NativeFunction(cbPtr, 'void', ['pointer']);
        log('[inject] cb=' + cbPtr + ' clientData=' + clientData + ' len=' + len + ' data=' + hex(bufPtr, len));
        fn(info);
        log('[inject] returned');
    } catch (e) { log('[inject] EXC ' + e.message); }
}

const acExports = mod.enumerateExports().filter(e => e.name.startsWith('EOS_AntiCheatClient_'));
acExports.forEach(function (e) {
    const name = e.name;
    const isNotify = name.indexOf('AddNotify') !== -1;
    const cb = new NativeCallback(function (a, b, c, d) {
        try {
            if (name === 'EOS_AntiCheatClient_AddNotifyMessageToServer') {
                clientData = c;
                cbPtr = d;
                log('[+cb] clientData=' + c + ' cb=' + d);
            } else if (name === 'EOS_AntiCheatClient_ReceiveMessageFromServer') {
                const len = b.add(4).readU32();
                const pData = b.add(8).readPointer();
                rxCount++;
                if (rxCount <= 5) log('[rx ' + rxCount + '] len=' + len + ' HEX ' + (len <= 128 ? hex(pData, len) : '?'));
                if (!injected && rxCount === 3 && len > 0 && len <= 128) {
                    injected = true;
                    const copy = Memory.alloc(len);
                    copy.writeByteArray(new Uint8Array(pData.readByteArray(len)));
                    inject(copy, len);
                }
            } else if (name === 'EOS_AntiCheatClient_BeginSession') {
                log('[begin]');
            } else if (name === 'EOS_AntiCheatClient_AddNotifyClientIntegrityViolated') {
                log('[+cb integrity] c=' + c + ' cb=' + d);
            }
        } catch (err) { log('[err] ' + name + ': ' + err.message); }
        return isNotify ? 1 : 0;
    }, isNotify ? 'uint64' : 'int', ['pointer', 'pointer', 'pointer', 'pointer', 'pointer', 'pointer']);
    try { Interceptor.replace(e.address, cb); } catch (err) { log('[!] ' + name + ': ' + err.message); }
});

try {
    const gi = mod.getExportByName('EOS_Platform_GetAntiCheatClientInterface');
    Interceptor.attach(gi, { onLeave(r) { r.replace(dummyHandle); } });
} catch (e) { log('[!] GI: ' + e.message); }

// hook the game's SendMessageToServer to prove the callback path ran
let hooked = false;
const timer = setInterval(function () {
    if (hooked) { clearInterval(timer); return; }
    const ga = Process.findModuleByName('GameAssembly.dll');
    if (!ga) return;
    try {
        function E(n) { return ga.getExportByName(n); }
        const fnDg = new NativeFunction(E('il2cpp_domain_get'), 'pointer', []);
        const fnDga = new NativeFunction(E('il2cpp_domain_get_assemblies'), 'pointer', ['pointer', 'pointer']);
        const fnAgi = new NativeFunction(E('il2cpp_assembly_get_image'), 'pointer', ['pointer']);
        const fnCfn = new NativeFunction(E('il2cpp_class_from_name'), 'pointer', ['pointer', 'pointer', 'pointer']);
        const fnMgfn = new NativeFunction(E('il2cpp_class_get_method_from_name'), 'pointer', ['pointer', 'pointer', 'int']);
        const domain = fnDg();
        if (domain.isNull()) return;
        const cnt = Memory.alloc(8);
        const asms = fnDga(domain, cnt);
        const n = cnt.readU64().toNumber();
        if (n <= 0) return;
        const ns = Memory.allocUtf8String('Game.Battle.AntiCheat');
        const cl = Memory.allocUtf8String('AntiCheatBattleUpdater');
        let klass = NULL;
        for (let i = 0; i < n && i < 2000; i++) {
            const img = fnAgi(asms.add(i * Process.pointerSize).readPointer());
            if (img.isNull()) continue;
            const k = fnCfn(img, ns, cl);
            if (!k.isNull()) { klass = k; break; }
        }
        if (klass.isNull()) return;
        const mi = fnMgfn(klass, Memory.allocUtf8String('SendMessageToServer'), 1);
        if (mi.isNull()) return;
        const mp = mi.readPointer();
        Interceptor.attach(mp, { onEnter(a) { log('[game tx] SendMessageToServer obj=' + a[1]); } });
        log('[+] SendMessageToServer hooked @ ' + mp);
        hooked = true;
        clearInterval(timer);
    } catch (e) { /* retry */ }
}, 500);

log('[+] agent ready');
