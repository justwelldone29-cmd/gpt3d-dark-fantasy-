@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
cd /d "%~dp0"

cl /nologo /LD /std:c++20 /O2 /EHsc /DUNICODE /D_UNICODE /I imgui /I menu /I features ^
 imgui\imgui.cpp imgui\imgui_draw.cpp imgui\imgui_tables.cpp imgui\imgui_widgets.cpp ^
 imgui\imgui_impl_dx11.cpp imgui\imgui_impl_win32.cpp ^
 menu\ui.cpp menu\menu_compat.cpp features\il2cpp.cpp features\esp.cpp hook\present.cpp dllmain.cpp ^
 /Fe:internal.dll /link d3d11.lib dxgi.lib user32.lib gdi32.lib

if errorlevel 1 exit /b 1
echo BUILD_OK
