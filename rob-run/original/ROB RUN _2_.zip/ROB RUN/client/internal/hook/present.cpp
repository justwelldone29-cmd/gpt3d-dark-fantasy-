// C++20, present.cpp вЂ” D3D11 Present hook + ImGui render for the internal build.
#include "present.h"
#include <d3d11.h>
#include <dxgi.h>
#include <cstdio>
#include <cstdarg>
#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"
#include "ui.h"
#include "esp.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

namespace {

constexpr const char* kLogPath = "C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.log";
constexpr int kPresentIndex = 8;
constexpr int kToggleKey = VK_INSERT;

using PresentFn = HRESULT(WINAPI*)(IDXGISwapChain*, UINT, UINT);

PresentFn g_original_present = nullptr;
WNDPROC g_original_wndproc = nullptr;
HWND g_hwnd = nullptr;
ID3D11Device* g_device = nullptr;
ID3D11DeviceContext* g_context = nullptr;
ID3D11RenderTargetView* g_rtv = nullptr;
UINT g_width = 0;
UINT g_height = 0;
bool g_imgui_ready = false;
ImVec2 g_vcursor(0.f, 0.f);
bool g_vinit = false;
POINT g_last_real{};
bool g_prev_lmb = false;
bool g_prev_rmb = false;

void Log(const char* fmt, ...) {
    FILE* f = nullptr;
    if (fopen_s(&f, kLogPath, "a") != 0 || !f) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_KEYDOWN && wp == kToggleKey) {
        g_menu_open = !g_menu_open;
        if (g_menu_open) ClipCursor(nullptr);
        return 0;
    }
    if (g_imgui_ready) {
        if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wp, lp))
            return 1;
    }
    // While the menu is open the game must not see mouse/keyboard input:
    // it otherwise captures the mouse and the menu loses button-up events.
    if (g_menu_open) {
        switch (msg) {
        case WM_MOUSEMOVE:
        case WM_LBUTTONDOWN: case WM_LBUTTONUP:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP:
        case WM_MBUTTONDOWN: case WM_MBUTTONUP:
        case WM_XBUTTONDOWN: case WM_XBUTTONUP:
        case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
        case WM_KEYDOWN: case WM_KEYUP:
        case WM_SYSKEYDOWN: case WM_SYSKEYUP:
        case WM_CHAR: case WM_SYSCHAR:
        case WM_INPUT:
            return 0;
        default:
            break;
        }
    }
    return CallWindowProcW(g_original_wndproc, hwnd, msg, wp, lp);
}

void CreateRTV(IDXGISwapChain* sc) {
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
    ID3D11Texture2D* backbuffer = nullptr;
    if (SUCCEEDED(sc->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&backbuffer))) && backbuffer) {
        g_device->CreateRenderTargetView(backbuffer, nullptr, &g_rtv);
        backbuffer->Release();
    }
}

void InitImGui(IDXGISwapChain* sc) {
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&g_device))) || !g_device)
        return;
    g_device->GetImmediateContext(&g_context);

    DXGI_SWAP_CHAIN_DESC desc{};
    if (SUCCEEDED(sc->GetDesc(&desc))) {
        g_hwnd = desc.OutputWindow;
        g_width = desc.BufferDesc.Width;
        g_height = desc.BufferDesc.Height;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();
    LoadMenuFonts();

    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_device, g_context);
    CreateRTV(sc);

    if (g_hwnd) {
        g_original_wndproc = reinterpret_cast<WNDPROC>(
            SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProc)));
    }
    g_imgui_ready = true;
    Log("[init] hwnd=%p device=%p ctx=%p %ux%u", g_hwnd, g_device, g_context, g_width, g_height);
}

void Render(IDXGISwapChain* sc) {
    if (!g_imgui_ready) return;
    DXGI_SWAP_CHAIN_DESC desc{};
    if (SUCCEEDED(sc->GetDesc(&desc))) {
        if (desc.BufferDesc.Width != g_width || desc.BufferDesc.Height != g_height) {
            g_width = desc.BufferDesc.Width;
            g_height = desc.BufferDesc.Height;
            CreateRTV(sc);
        }
    }
    if (g_menu_open) {
        ClipCursor(nullptr);
    }
    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    if (g_menu_open && g_hwnd) {
        ImGuiIO& io = ImGui::GetIO();
        POINT p{};
        if (GetCursorPos(&p) && ScreenToClient(g_hwnd, &p)) {
            if (!g_vinit) {
                g_vcursor = ImVec2((float)p.x, (float)p.y);
                g_last_real = p;
                g_vinit = true;
            } else {
                const int dx = p.x - g_last_real.x;
                const int dy = p.y - g_last_real.y;
                if (abs(dx) < 250 && abs(dy) < 250) {
                    g_vcursor.x += (float)dx;
                    g_vcursor.y += (float)dy;
                }
                g_last_real = p;
            }
            if (g_vcursor.x < 0.f) g_vcursor.x = 0.f;
            if (g_vcursor.y < 0.f) g_vcursor.y = 0.f;
            if (g_vcursor.x > io.DisplaySize.x - 1.f) g_vcursor.x = io.DisplaySize.x - 1.f;
            if (g_vcursor.y > io.DisplaySize.y - 1.f) g_vcursor.y = io.DisplaySize.y - 1.f;
            io.AddMousePosEvent(g_vcursor.x, g_vcursor.y);
        }
        const bool lmb = (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        const bool rmb = (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        if (lmb != g_prev_lmb) { io.AddMouseButtonEvent(0, lmb); g_prev_lmb = lmb; }
        if (rmb != g_prev_rmb) { io.AddMouseButtonEvent(1, rmb); g_prev_rmb = rmb; }
    } else {
        g_vinit = false;
    }
    ImGui::NewFrame();
    esp::Render(ImGui::GetBackgroundDrawList());
    if (g_menu_open) {
        DrawMenu();
    }
    if (g_menu_open) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        const ImVec2 c = g_vcursor;
        fg->AddTriangleFilled(ImVec2(c.x, c.y), ImVec2(c.x, c.y + 17.f), ImVec2(c.x + 12.f, c.y + 12.f), IM_COL32(255, 255, 255, 255));
        fg->AddTriangle(ImVec2(c.x, c.y), ImVec2(c.x, c.y + 17.f), ImVec2(c.x + 12.f, c.y + 12.f), IM_COL32(0, 0, 0, 255), 1.5f);
    }
    ImGui::Render();
    g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

HRESULT WINAPI HookedPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    if (!g_imgui_ready) InitImGui(sc);
    Render(sc);
    return g_original_present(sc, sync, flags);
}

bool PatchVtable() {
    WNDCLASSEXW wc{ sizeof(wc) };
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"##internal_probe";
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName, L"probe", WS_OVERLAPPEDWINDOW,
        0, 0, 64, 64, nullptr, nullptr, wc.hInstance, nullptr);
    if (!hwnd) { UnregisterClassW(wc.lpszClassName, wc.hInstance); return false; }

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* sc = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;
    D3D_FEATURE_LEVEL level;
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
        nullptr, 0, D3D11_SDK_VERSION, &sd, &sc, &dev, &level, &ctx);
    if (FAILED(hr) || !sc) {
        DestroyWindow(hwnd);
        UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return false;
    }

    void** vtable = *reinterpret_cast<void***>(sc);
    g_original_present = reinterpret_cast<PresentFn>(vtable[kPresentIndex]);

    DWORD old = 0;
    if (!VirtualProtect(&vtable[kPresentIndex], sizeof(void*), PAGE_READWRITE, &old)) {
        Log("[hook] VirtualProtect failed %lu", GetLastError());
        sc->Release(); dev->Release(); ctx->Release();
        DestroyWindow(hwnd); UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return false;
    }
    vtable[kPresentIndex] = reinterpret_cast<void*>(&HookedPresent);
    VirtualProtect(&vtable[kPresentIndex], sizeof(void*), old, &old);

    sc->Release();
    dev->Release();
    ctx->Release();
    DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);

    Log("[hook] present=%p original=%p", &HookedPresent, g_original_present);
    return g_original_present != nullptr;
}

} // namespace

namespace present_hook {

bool Install() {
    return PatchVtable();
}

} // namespace present_hook
