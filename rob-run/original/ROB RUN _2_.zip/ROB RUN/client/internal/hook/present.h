#pragma once
#include <windows.h>

namespace present_hook {
bool Install();
}
