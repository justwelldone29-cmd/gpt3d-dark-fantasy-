#pragma once
#include "imgui.h"

// Compatibility object required by the patched ImGui core (child/slider rendering).
class Menu {
public:
    ImFont* nameCheat = nullptr;
    ImFont* nameCheat2 = nullptr;
    ImFont* nameTable = nullptr;
    ImFont* generalTable = nullptr;
    ImFont* leftTable = nullptr;
    ImFont* Icons = nullptr;
    ImFont* font = nullptr;
    ImFont* smallFont = nullptr;
    ImFont* introFont = nullptr;
};

extern Menu menu;
