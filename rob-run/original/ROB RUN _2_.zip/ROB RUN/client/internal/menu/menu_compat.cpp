#include "menu_compat.h"

Menu menu;
