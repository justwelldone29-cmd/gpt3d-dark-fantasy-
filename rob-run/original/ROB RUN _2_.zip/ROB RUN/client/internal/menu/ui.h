#pragma once
#include "imgui.h"

struct MenuFonts {
    ImFont* title = nullptr;
    ImFont* title2 = nullptr;
    ImFont* small_font = nullptr;
    ImFont* general = nullptr;
    ImFont* left = nullptr;
    ImFont* icons = nullptr;
};

extern MenuFonts g_fonts;
extern bool g_menu_open;

void LoadMenuFonts();
void DrawMenu();
void DrawWatermark();
