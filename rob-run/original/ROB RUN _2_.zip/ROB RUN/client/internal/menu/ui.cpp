// C++20, ui.cpp РІР‚вЂќ styled internal menu adapted from the GILA base.
#include "ui.h"
#include "regular.h"
#include "Icons.h"
#include "imgui_internal.h"
#include "menu_compat.h"
#include <map>

MenuFonts g_fonts;
bool g_menu_open = true;

static bool watermark = true;
static bool keybinds = false;
static int active_tab = 2;

// feature placeholders (wired to the feature layer later)
bool esp_enabled = true;
bool esp_boxes = true;
bool esp_names = true;
bool esp_distance = true;
bool esp_skeleton = true;
bool esp_npc = true;
bool esp_tracers = false;
bool esp_loot = false;
static bool aim_enabled = false;
static float aim_fov = 90.f;
static float aim_smooth = 5.f;
static int aim_bone = 0;
static bool aim_team = true;
static bool noclip = false;
static bool speedhack = false;
static bool no_recoil = false;

void LoadMenuFonts() {
    ImGuiIO& io = ImGui::GetIO();
    g_fonts.title = io.Fonts->AddFontFromMemoryTTF(lexend_bold, sizeof(lexend_bold), 18.f);
    g_fonts.title2 = io.Fonts->AddFontFromMemoryTTF(lexend_bold, sizeof(lexend_bold), 19.f);
    g_fonts.small_font = io.Fonts->AddFontFromMemoryTTF(lexend_bold, sizeof(lexend_bold), 12.f);
    g_fonts.general = io.Fonts->AddFontFromMemoryTTF(lexend_bold, sizeof(lexend_bold), 14.f);
    g_fonts.left = io.Fonts->AddFontFromMemoryTTF(lexend_bold, sizeof(lexend_bold), 16.f);
    g_fonts.icons = io.Fonts->AddFontFromMemoryTTF(IconFont, sizeof(IconFont), 19, nullptr, io.Fonts->GetGlyphRangesCyrillic());

    menu.nameCheat = g_fonts.title;
    menu.nameCheat2 = g_fonts.title2;
    menu.nameTable = g_fonts.general;
    menu.generalTable = g_fonts.general;
    menu.leftTable = g_fonts.left;
    menu.Icons = g_fonts.icons;
    menu.smallFont = g_fonts.small_font;
    menu.font = g_fonts.general;
    menu.introFont = g_fonts.title;
}

static void Tab(const char* icon, const char* label, int id) {
    ImVec2 pos = ImGui::GetCursorPos();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    const ImGuiID tab_id = window->GetID(label);

    static std::map<ImGuiID, int> alpha_bg;
    static std::map<ImGuiID, int> alpha_bar;
    auto it_bg = alpha_bg.find(tab_id);
    auto it_bar = alpha_bar.find(tab_id);
    if (it_bg == alpha_bg.end()) { alpha_bg.insert({ tab_id, 0 }); it_bg = alpha_bg.find(tab_id); }
    if (it_bar == alpha_bar.end()) { alpha_bar.insert({ tab_id, 0 }); it_bar = alpha_bar.find(tab_id); }

    ImGui::SetCursorPos(pos);
    if (ImGui::InvisibleButton(label, ImVec2(135, 28))) active_tab = id;

    const bool selected = active_tab == id;
    const bool hovered = ImGui::IsItemHovered();
    const int target_bg = selected ? 163 : (hovered ? 133 : 0);
    const int target_bar = selected ? 255 : (hovered ? 111 : 0);
    it_bg->second += (it_bg->second < target_bg) ? 5 : (it_bg->second > target_bg ? -5 : 0);
    it_bar->second += (it_bar->second < target_bar) ? 5 : (it_bar->second > target_bar ? -5 : 0);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(ImVec2(window->Pos.x + pos.x, window->Pos.y + pos.y),
        ImVec2(window->Pos.x + pos.x + 3, window->Pos.y + pos.y + 28),
        ImColor(139, 130, 159, it_bar->second), 5, ImDrawFlags_RoundCornersRight);
    dl->AddRectFilled(ImVec2(window->Pos.x + pos.x + 7, window->Pos.y + pos.y),
        ImVec2(window->Pos.x + pos.x + 135, window->Pos.y + pos.y + 28),
        ImColor(20, 23, 22, it_bg->second), 5);

    const ImVec4 text_color = selected ? ImVec4(1.f, 1.f, 1.f, 1.f)
        : (hovered ? ImVec4(0.86f, 0.86f, 0.86f, 1.f) : ImVec4(0.52f, 0.53f, 0.55f, 1.f));
    ImGui::SetCursorPos(pos);
    ImGui::PushFont(g_fonts.icons);
    ImGui::SetCursorPos(ImVec2(pos.x + 10, pos.y + 3));
    ImGui::TextColored(text_color, "%s", icon);
    ImGui::PopFont();
    ImGui::PushFont(g_fonts.left);
    ImGui::SetCursorPos(ImVec2(pos.x + 35, pos.y + 5));
    ImGui::TextColored(text_color, "%s", label);
    ImGui::PopFont();
}

static void RenderTabs() {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    ImDrawList* dl = window->DrawList;

    dl->AddLine(ImVec2(window->Pos.x, window->Pos.y + 15), ImVec2(window->Pos.x + 8, window->Pos.y + 15), ImColor(26, 29, 28, 255), 1.5f);
    dl->AddText(g_fonts.small_font, 12.f, ImVec2(window->Pos.x + 13, window->Pos.y + 9), ImColor(133, 133, 133, 255), "COMBAT");
    dl->AddLine(ImVec2(window->Pos.x + 68, window->Pos.y + 15), ImVec2(window->Pos.x + 136, window->Pos.y + 15), ImColor(26, 29, 28, 255), 1.5f);

    ImGui::SetCursorPos(ImVec2(0, 30));
    ImGui::BeginGroup();
    Tab("1", "Aim", 1);
    ImGui::Spacing(); ImGui::Spacing();
    Tab("2", "Visuals", 2);
    ImGui::EndGroup();

    dl->AddLine(ImVec2(window->Pos.x, window->Pos.y + 105), ImVec2(window->Pos.x + 8, window->Pos.y + 105), ImColor(26, 29, 28, 255), 1.5f);
    dl->AddText(g_fonts.small_font, 12.f, ImVec2(window->Pos.x + 13, window->Pos.y + 99), ImColor(133, 133, 133, 255), "WORLD");
    dl->AddLine(ImVec2(window->Pos.x + 54, window->Pos.y + 105), ImVec2(window->Pos.x + 136, window->Pos.y + 105), ImColor(26, 29, 28, 255), 1.5f);

    ImGui::SetCursorPos(ImVec2(0, 110));
    ImGui::BeginGroup();
    ImGui::Spacing(); ImGui::Spacing();
    Tab("3", "Players", 3);
    ImGui::Spacing(); ImGui::Spacing();
    Tab("6", "NPC", 6);
    ImGui::Spacing(); ImGui::Spacing();
    Tab("4", "Misc", 4);
    ImGui::EndGroup();

    dl->AddLine(ImVec2(window->Pos.x, window->Pos.y + 225), ImVec2(window->Pos.x + 8, window->Pos.y + 225), ImColor(26, 29, 28, 255), 1.5f);
    dl->AddText(g_fonts.small_font, 12.f, ImVec2(window->Pos.x + 13, window->Pos.y + 219), ImColor(133, 133, 133, 255), "SYSTEM");
    dl->AddLine(ImVec2(window->Pos.x + 63, window->Pos.y + 225), ImVec2(window->Pos.x + 136, window->Pos.y + 225), ImColor(26, 29, 28, 255), 1.5f);

    ImGui::SetCursorPos(ImVec2(0, 240));
    ImGui::BeginGroup();
    Tab("5", "Configs", 5);
    ImGui::EndGroup();
}

void DrawWatermark() {
    if (!watermark) return;
    ImGui::SetNextWindowSize(ImVec2(230, 30));
    ImGui::Begin("##watermark", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground);
    {
        ImVec2 xy = ImGui::GetWindowPos();
        auto bg = ImGui::GetBackgroundDrawList();
        auto dl = ImGui::GetWindowDrawList();
        bg->AddShadowRect(xy, ImVec2(xy.x + 230, xy.y + 30), ImColor(26, 28, 96), 100.f, ImVec2(0, 0));
        dl->AddText(g_fonts.small_font, 15.f, ImVec2(xy.x + 10, xy.y + 8), ImColor(133, 133, 133, 255), "ROB RUN | internal");
    }
    ImGui::End();
}


static bool Toggle(const char* label, bool* v) {
    ImGui::PushID(label);
    ImVec2 p = ImGui::GetCursorScreenPos();
    const float sz = 19.f;
    ImGui::InvisibleButton("##t", ImVec2(sz, sz));
    const bool hovered = ImGui::IsItemHovered();
    bool changed = false;
    if (ImGui::IsItemClicked(0)) { *v = !*v; changed = true; }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + sz, p.y + sz), *v ? IM_COL32(80, 110, 210, 255) : IM_COL32(36, 40, 40, 255), 3.f);
    dl->AddRect(p, ImVec2(p.x + sz, p.y + sz), hovered ? IM_COL32(200, 200, 255, 255) : IM_COL32(70, 74, 74, 255), 3.f);
    if (*v) {
        dl->AddLine(ImVec2(p.x + 4, p.y + 9), ImVec2(p.x + 8, p.y + 14), IM_COL32(255, 255, 255, 255), 2.f);
        dl->AddLine(ImVec2(p.x + 8, p.y + 14), ImVec2(p.x + 15, p.y + 5), IM_COL32(255, 255, 255, 255), 2.f);
    }
    ImGui::SameLine();
    ImGui::TextUnformatted(label);
    ImGui::PopID();
    return changed;
}

void DrawMenu() {
    ImGuiIO& io = ImGui::GetIO();
    static ImVec2 menu_pos(0.f, 0.f);
    static bool menu_pos_init = false;
    if (!menu_pos_init) {
        menu_pos = ImVec2(io.DisplaySize.x / 2 - 310, io.DisplaySize.y / 2 - 235);
        menu_pos_init = true;
    }
    ImGui::SetNextWindowPos(menu_pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(620, 471));
    ImGui::Begin("##main", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove);
    ImGui::SetCursorPos(ImVec2(0.f, 0.f));
    ImGui::InvisibleButton("##drag", ImVec2(620.f, 26.f));
    if (ImGui::IsItemActive())
        menu_pos = ImVec2(menu_pos.x + io.MouseDelta.x, menu_pos.y + io.MouseDelta.y);
    {
        auto bg = ImGui::GetBackgroundDrawList();
        auto dl = ImGui::GetWindowDrawList();
        ImVec2 xy = ImGui::GetWindowPos();

        bg->AddShadowRect(xy, ImVec2(xy.x + 620, xy.y + 471), ImColor(26, 28, 96), 100.f, ImVec2(0, 0));
        bg->AddRectFilled(xy, ImVec2(xy.x + 620, xy.y + 471), ImColor(17, 19, 19), 5, ImDrawFlags_RoundCornersAll);
        dl->AddRectFilled(xy, ImVec2(xy.x + 140, xy.y + 471), ImColor(12, 15, 14), 5, ImDrawFlags_RoundCornersLeft);
        dl->AddLine(ImVec2(xy.x + 140, xy.y), ImVec2(xy.x + 140, xy.y + 472), ImColor(26, 29, 28), 1.5f);
        dl->AddLine(ImVec2(xy.x + 140, xy.y + 38), ImVec2(xy.x + 620, xy.y + 38), ImColor(26, 29, 28), 1.5f);
        RenderTabs();

        dl->AddText(g_fonts.title, 18, ImVec2(xy.x + 156, xy.y + 11), ImColor(255, 255, 255, 255), "ROB");
        dl->AddText(g_fonts.title2, 19, ImVec2(xy.x + 197, xy.y + 10), ImColor(102, 101, 134, 255), "RUN");

        ImGui::SetCursorPos(ImVec2(148, 50));
        ImGui::BeginChild("SETTINGS", ImVec2(229, 402));
        {
            ImGui::PushFont(g_fonts.general);
            ImGui::SetCursorPosY(45.f);
            if (active_tab == 1) {
                Toggle("Aimbot", &aim_enabled);
                ImGui::SliderFloat("FOV", &aim_fov, 1.f, 180.f, "%.0f");
                ImGui::SliderFloat("Smooth", &aim_smooth, 1.f, 30.f, "%.1f");
                ImGui::Combo("Bone", &aim_bone, "Head\0Neck\0Chest\0");
                Toggle("Team check", &aim_team);
            } else if (active_tab == 2) {
                Toggle("ESP", &esp_enabled);
                Toggle("Boxes", &esp_boxes);
                Toggle("Names", &esp_names);
                Toggle("Distance", &esp_distance);
                Toggle("Skeleton", &esp_skeleton);
            } else if (active_tab == 3) {
                ImGui::TextDisabled("player list");
                ImGui::Separator();
                ImGui::TextDisabled("populated from entity list");
            } else if (active_tab == 6) {
                Toggle("NPC ESP", &esp_npc);
                Toggle("Boxes", &esp_boxes);
                Toggle("Names", &esp_names);
                Toggle("Distance", &esp_distance);
                Toggle("Skeleton", &esp_skeleton);
            } else if (active_tab == 4) {
                Toggle("Noclip", &noclip);
                Toggle("Speedhack", &speedhack);
                Toggle("No recoil", &no_recoil);
                Toggle("Watermark", &watermark);
                Toggle("Keybinds", &keybinds);
            } else if (active_tab == 5) {
                ImGui::TextDisabled("config slots");
                ImGui::Separator();
                ImGui::Button("Save##cfg", ImVec2(219, 25));
                ImGui::Button("Load##cfg", ImVec2(219, 25));
            }
            ImGui::PopFont();
        }
        ImGui::EndChild();

        ImGui::SetCursorPos(ImVec2(384, 50));
        ImGui::BeginChild("FEATURES", ImVec2(229, 402));
        {
            ImGui::PushFont(g_fonts.general);
            ImGui::SetCursorPosY(45.f);
            if (active_tab == 2) {
                Toggle("Tracers", &esp_tracers);
                Toggle("Loot", &esp_loot);
                ImGui::Separator();
                ImGui::TextDisabled("colors / thickness");
            } else if (active_tab == 6) {
                ImGui::TextDisabled("npcs: bots and quest actors");
                ImGui::Separator();
                ImGui::TextDisabled("players get their own pass");
            } else {
                ImGui::TextDisabled("feature panel");
                ImGui::Separator();
                ImGui::TextDisabled("wired to the runtime layer");
            }
            ImGui::PopFont();
        }
        ImGui::EndChild();
    }
    ImGui::End();
    DrawWatermark();
}
