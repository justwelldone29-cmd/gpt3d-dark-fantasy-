// C++20, dllmain.cpp вЂ” internal DLL entry.
#include <windows.h>
#include "hook/present.h"

namespace {
DWORD WINAPI InitThread(LPVOID) {
    Sleep(150);
    present_hook::Install();
    return 0;
}
} // namespace

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(module);
        HANDLE thread = CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
        if (thread) CloseHandle(thread);
    }
    return TRUE;
}
