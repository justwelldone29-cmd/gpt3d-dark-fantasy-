#pragma once
#include <cstdint>
#include <string>

struct Il2CppObject { void* klass; void* monitor; };
struct Il2CppClass;
struct MethodInfo;
struct FieldInfo;
struct Il2CppType;
struct Il2CppArray;

namespace il2 {

bool init();
bool ready();

Il2CppClass* find_class(const char* ns, const char* name);
const MethodInfo* find_method(Il2CppClass* klass, const char* name, int argc);
Il2CppClass* class_of(Il2CppObject* obj);
const char* class_name(Il2CppClass* klass);
int field_offset(Il2CppClass* klass, const char* name);
Il2CppObject* type_object(Il2CppClass* klass);

void* invoke(const MethodInfo* method, void* obj, void** params);
void* unbox(void* boxed);

uintptr_t array_length(Il2CppArray* arr);
void* array_at(Il2CppArray* arr, uintptr_t index);
std::string object_name(Il2CppObject* obj);

void ensure_thread();

} // namespace il2
