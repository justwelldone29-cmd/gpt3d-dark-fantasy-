// C++20, esp.cpp — IL2CPP player ESP: boxes from bones, skeleton, player/bot tags.
#define NOMINMAX
#include "esp.h"
#include "il2cpp.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <cmath>
#include <cstdio>
#include <cstdarg>
#include <string>

extern bool esp_enabled;
extern bool esp_boxes;
extern bool esp_names;
extern bool esp_distance;
extern bool esp_skeleton;
extern bool esp_npc;

namespace {

constexpr uint64_t k_chars_ms = 1000;     // character list rebuild
constexpr uint64_t k_actors_ms = 3000;    // local player / npc / markers
constexpr float k_max_dist = 300.f;
constexpr float k_dup_radius = 0.35f;
constexpr float k_box_width = 0.45f;
constexpr int   k_slots = 22;

void Log(const char* fmt, ...) {
    FILE* f = nullptr;
    if (fopen_s(&f, "C:\\Users\\sss\\Desktop\\ROB RUN\\client\\internal\\internal.log", "a") != 0 || !f) return;
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f); fclose(f);
}

struct V3 { float x, y, z; };
struct Mat { float m[16]{}; };

Mat mat_mul(const Mat& a, const Mat& b) {   // c = a * b, column-major storage
    Mat c;
    for (int r = 0; r < 4; ++r)
        for (int col = 0; col < 4; ++col) {
            float s = 0.f;
            for (int k = 0; k < 4; ++k) s += a.m[k * 4 + r] * b.m[col * 4 + k];
            c.m[col * 4 + r] = s;
        }
    return c;
}

bool project_mvp(const Mat& mvp, const V3& w, const ImVec2& screen, ImVec2& out) {
    const float x = mvp.m[0] * w.x + mvp.m[4] * w.y + mvp.m[8] * w.z + mvp.m[12];
    const float y = mvp.m[1] * w.x + mvp.m[5] * w.y + mvp.m[9] * w.z + mvp.m[13];
    const float wc = mvp.m[3] * w.x + mvp.m[7] * w.y + mvp.m[11] * w.z + mvp.m[15];
    if (wc < 0.1f) return false;
    const float nx = x / wc, ny = y / wc;
    out = ImVec2((nx * 0.5f + 0.5f) * screen.x, (0.5f - ny * 0.5f) * screen.y);
    return true;
}

enum Slot {
    HIPS, SPINE2, SPINE3, NECK, HEAD1, HEAD2,
    ARM_L0, ARM_L1, ARM_L2, ARM_L3,
    ARM_R0, ARM_R1, ARM_R2, ARM_R3,
    LEG_L0, LEG_L1, LEG_L2,
    LEG_R0, LEG_R1, LEG_R2,
    FOOT_L, FOOT_R
};

struct Rig {
    void* b[k_slots]{};
    bool ok = false;
};

struct Api {
    Il2CppClass* camera = nullptr;
    Il2CppClass* smr = nullptr;
    Il2CppClass* resources = nullptr;
    Il2CppClass* marker = nullptr;
    const MethodInfo* main = nullptr;
    const MethodInfo* w2s = nullptr;
    const MethodInfo* world_to_camera = nullptr;
    const MethodInfo* projection = nullptr;
    const MethodInfo* transform_of = nullptr;
    const MethodInfo* position = nullptr;
    const MethodInfo* forward = nullptr;
    const MethodInfo* name_of = nullptr;
    const MethodInfo* bones_of = nullptr;
    const MethodInfo* visible_of = nullptr;
    const MethodInfo* find_all = nullptr;
    bool ok = false;
};

struct Char {
    void* renderer = nullptr;
    void* hips = nullptr;
    Rig rig;
    bool vis = false;
    bool npc = false;
    bool seen = false;
    float hp = -1.f;
    V3 last_pos{};
    uint64_t last_ms = 0;
    float speed = 0.f;
};

Api api;
std::vector<Char> chars;
std::unordered_map<void*, Char> known;   // hips -> character, keeps one renderer per actor
std::unordered_map<void*, Rig> rig_cache;
std::vector<V3> markers;

struct ModelActor { int id; bool bot; V3 pos; int hp; int hp_max; };
std::vector<ModelActor> actors;
void* entry_obj = nullptr;
uint64_t last_models = 0;

struct ModelPath {
    Il2CppClass* entry = nullptr;
    Il2CppClass* game = nullptr;
    Il2CppClass* gmodel = nullptr;
    Il2CppClass* bmodel = nullptr;
    Il2CppClass* ents = nullptr;
    Il2CppClass* world = nullptr;
    Il2CppClass* chmodel = nullptr;
    Il2CppClass* posmodel = nullptr;
    const MethodInfo* get_values = nullptr;
    const MethodInfo* get_enum = nullptr;
    const MethodInfo* move_next = nullptr;
    const MethodInfo* get_current = nullptr;
    int o_game = -1, o_gm = -1, o_bm = -1, o_ent = -1, o_world = -1, o_chars = -1;
    int o_id = -1, o_pbm = -1, o_center = -1, o_x = -1, o_y = -1, o_z = -1;
    int o_private = -1, o_health = -1, o_hdata = -1, o_hmax = -1;
    int o_tx = -1, o_ty = -1, o_tz = -1;
    bool ok = false;
    bool en_checked = false;
    bool en_unboxed = false;
} mp;

template <typename T>
T read_at(void* base, int off) {
    if (!base || off < 0) return T{};
    void* p = reinterpret_cast<uint8_t*>(base) + off;
    if (IsBadReadPtr(p, sizeof(T))) return T{};
    return *reinterpret_cast<T*>(p);
}

bool resolve_models() {
    if (mp.ok) return true;
    mp.entry = il2::find_class("Start", "UnityEntry");
    mp.game = il2::find_class("Game", "Game");
    mp.gmodel = il2::find_class("Game", "GameModel");
    mp.bmodel = il2::find_class("Game.Battle", "BattleModel");
    mp.ents = il2::find_class("Game.Battle", "BattleEntitiesModel");
    mp.world = il2::find_class("Models.Models.WorldEntities", "WorldEntitiesModel");
    mp.chmodel = il2::find_class("Models.Models.BattleCharacter", "BattleCharacterModel");
    mp.posmodel = il2::find_class("Models.Models.PositionModel", "PositionModel");
    if (!mp.entry || !mp.game || !mp.gmodel || !mp.bmodel || !mp.ents || !mp.world || !mp.chmodel)
        return false;

    mp.o_game = il2::field_offset(mp.entry, "_game");
    mp.o_gm = il2::field_offset(mp.game, "<GameModel>k__BackingField");
    mp.o_bm = il2::field_offset(mp.gmodel, "_battleModel");
    mp.o_ent = il2::field_offset(mp.bmodel, "<BattleEntitiesModel>k__BackingField");
    mp.o_world = il2::field_offset(mp.ents, "_worldEntitiesModel");
    mp.o_chars = il2::field_offset(mp.world, "_battleCharacters");
    mp.o_id = il2::field_offset(mp.chmodel, "<Id>k__BackingField");
    mp.o_pbm = il2::field_offset(mp.chmodel, "<PlayerBattleModel>k__BackingField");
    mp.o_center = il2::field_offset(mp.chmodel, "<CenterPosition>k__BackingField");
    mp.o_private = il2::field_offset(mp.chmodel, "<PrivateModel>k__BackingField");
    mp.o_tx = il2::field_offset(mp.chmodel, "<Transform>k__BackingField");
    if (auto* priv = il2::find_class("Models.Models.BattleCharacterPrivate", "BattleCharacterPrivateModel")) {
        mp.o_health = il2::field_offset(priv, "<Health>k__BackingField");
    }
    if (auto* h = il2::find_class("Models.Models.Health", "HealthModel")) {
        mp.o_hdata = il2::field_offset(h, "_health");
        mp.o_hmax = il2::field_offset(h, "_maxAmount");
    }
    if (auto* tm = il2::find_class("Models.Models.TransformModel", "TransformModel")) {
        mp.o_x = il2::field_offset(tm, "_x");
        mp.o_y = il2::field_offset(tm, "_y");
        mp.o_z = il2::field_offset(tm, "_z");
    }
    if (mp.posmodel) {
        mp.o_x = il2::field_offset(mp.posmodel, "<X>k__BackingField");
        mp.o_y = il2::field_offset(mp.posmodel, "<Y>k__BackingField");
        mp.o_z = il2::field_offset(mp.posmodel, "<Z>k__BackingField");
    }
    mp.ok = mp.o_game >= 0 && mp.o_gm >= 0 && mp.o_bm >= 0 && mp.o_ent >= 0 &&
        mp.o_world >= 0 && mp.o_chars >= 0 && mp.o_id >= 0 && mp.o_pbm >= 0 &&
        mp.o_private >= 0 && mp.o_health >= 0 && mp.o_hdata >= 0 && mp.o_hmax >= 0 &&
        mp.o_tx >= 0 && mp.o_x >= 0 && mp.o_y >= 0 && mp.o_z >= 0;
    return mp.ok;
}

void refresh_models();
uint64_t last_chars = 0;
uint64_t last_actors = 0;

V3 pos_of(void* tr) {
    V3 v{};
    if (!tr) return v;
    void* boxed = il2::invoke(api.position, tr, nullptr);
    if (auto* p = boxed ? static_cast<V3*>(il2::unbox(boxed)) : nullptr) v = *p;
    return v;
}

bool project(void* cam, const V3& world, const ImVec2& screen, ImVec2& out) {
    V3 arg = world;
    void* args[1] = { &arg };
    void* boxed = il2::invoke(api.w2s, cam, args);
    auto* v = boxed ? static_cast<V3*>(il2::unbox(boxed)) : nullptr;
    if (!v || v->z < 0.1f) return false;
    out = ImVec2(v->x, screen.y - v->y);
    return true;
}

std::string object_name(void* obj) {
    void* s = il2::invoke(api.name_of, obj, nullptr);
    return s ? il2::object_name(static_cast<Il2CppObject*>(s)) : std::string();
}

bool ends_with(const std::string& s, const char* suffix) {
    const size_t n = std::char_traits<char>::length(suffix);
    return s.size() >= n && s.compare(s.size() - n, n, suffix) == 0;
}

bool valid(void* renderer) {
    if (!api.visible_of) return true;
    void* boxed = il2::invoke(api.visible_of, renderer, nullptr);
    auto* b = boxed ? static_cast<bool*>(il2::unbox(boxed)) : nullptr;
    return b ? *b : true;
}

Rig build_rig(void* renderer) {
    Rig rig;
    void* bones = il2::invoke(api.bones_of, renderer, nullptr);
    if (!bones) return rig;
    auto* arr = static_cast<Il2CppArray*>(bones);
    const uintptr_t n = il2::array_length(arr);
    if (n < 30 || n > 256) return rig;

    for (uintptr_t i = 0; i < n; ++i) {
        void* bone = il2::array_at(arr, i);
        if (!bone) continue;
        const std::string s = object_name(bone);
        if (s.empty()) continue;
        if (ends_with(s, "_spine_1_jnt")) rig.b[HIPS] = bone;
        else if (ends_with(s, "_spine_2_jnt")) rig.b[SPINE2] = bone;
        else if (ends_with(s, "_spine_3_jnt")) rig.b[SPINE3] = bone;
        else if (ends_with(s, "_neck_jnt")) rig.b[NECK] = bone;
        else if (ends_with(s, "_head_1_jnt")) rig.b[HEAD1] = bone;
        else if (ends_with(s, "_head_2_jnt")) rig.b[HEAD2] = bone;
        else if (ends_with(s, "L_arm_0_jnt")) rig.b[ARM_L0] = bone;
        else if (ends_with(s, "L_arm_1_jnt")) rig.b[ARM_L1] = bone;
        else if (ends_with(s, "L_arm_2_jnt")) rig.b[ARM_L2] = bone;
        else if (ends_with(s, "L_arm_3_jnt")) rig.b[ARM_L3] = bone;
        else if (ends_with(s, "R_arm_0_jnt")) rig.b[ARM_R0] = bone;
        else if (ends_with(s, "R_arm_1_jnt")) rig.b[ARM_R1] = bone;
        else if (ends_with(s, "R_arm_2_jnt")) rig.b[ARM_R2] = bone;
        else if (ends_with(s, "R_arm_3_jnt")) rig.b[ARM_R3] = bone;
        else if (ends_with(s, "L_leg_1_jnt")) rig.b[LEG_L0] = bone;
        else if (ends_with(s, "L_leg_2_jnt")) rig.b[LEG_L1] = bone;
        else if (ends_with(s, "L_leg_3_jnt")) rig.b[LEG_L2] = bone;
        else if (ends_with(s, "R_leg_1_jnt")) rig.b[LEG_R0] = bone;
        else if (ends_with(s, "R_leg_2_jnt")) rig.b[LEG_R1] = bone;
        else if (ends_with(s, "R_leg_3_jnt")) rig.b[LEG_R2] = bone;
        else if (ends_with(s, "L_foot_1_jnt")) rig.b[FOOT_L] = bone;
        else if (ends_with(s, "R_foot_1_jnt")) rig.b[FOOT_R] = bone;
    }
    rig.ok = rig.b[HIPS] && rig.b[FOOT_L] && rig.b[FOOT_R] &&
        (rig.b[HEAD2] || rig.b[HEAD1] || rig.b[NECK]);
    return rig;
}

bool resolve() {
    if (api.ok) return true;
    if (!il2::init()) return false;

    api.camera = il2::find_class("UnityEngine", "Camera");
    api.smr = il2::find_class("UnityEngine", "SkinnedMeshRenderer");
    api.resources = il2::find_class("UnityEngine", "Resources");
    api.marker = il2::find_class("Game.Battle.Markers.Markers3D.View", "Marker3DView");
    if (!api.camera || !api.smr || !api.resources) return false;

    auto* component = il2::find_class("UnityEngine", "Component");
    auto* transform = il2::find_class("UnityEngine", "Transform");
    auto* object = il2::find_class("UnityEngine", "Object");
    auto* renderer = il2::find_class("UnityEngine", "Renderer");

    api.main = il2::find_method(api.camera, "get_main", 0);
    api.w2s = il2::find_method(api.camera, "WorldToScreenPoint", 1);
    api.world_to_camera = il2::find_method(api.camera, "get_worldToCameraMatrix", 0);
    api.projection = il2::find_method(api.camera, "get_projectionMatrix", 0);
    api.transform_of = il2::find_method(component, "get_transform", 0);
    api.position = il2::find_method(transform, "get_position", 0);
    api.forward = il2::find_method(transform, "get_forward", 0);
    api.name_of = il2::find_method(object, "get_name", 0);
    api.bones_of = il2::find_method(api.smr, "get_bones", 0);
    api.find_all = il2::find_method(api.resources, "FindObjectsOfTypeAll", 1);
    if (renderer) api.visible_of = il2::find_method(renderer, "get_isVisible", 0);

    api.ok = api.main && api.w2s && api.position && api.bones_of && api.find_all;
    if (!api.ok) Log("[esp] api failed");
    return api.ok;
}

template <typename Fn>
void for_each(Il2CppClass* klass, Fn fn) {
    if (!klass) return;
    void* type = il2::type_object(klass);
    if (!type) return;
    void* args[1] = { type };
    void* arr = il2::invoke(api.find_all, nullptr, args);
    if (!arr) return;
    auto* a = static_cast<Il2CppArray*>(arr);
    const uintptr_t n = std::min<uintptr_t>(il2::array_length(a), 1024);
    for (uintptr_t i = 0; i < n; ++i)
        if (void* obj = il2::array_at(a, i)) fn(obj);
}

void refresh_models() {
    static int last_stage = 0;
    auto stage = [](int s) {
        static int seen = 0;
        if (s > seen) { seen = s; Log("[m] stage=%d", s); }
    };
    if (!resolve_models()) return;
    if (!entry_obj) {
        for_each(mp.entry, [](void* obj) { if (!entry_obj) entry_obj = obj; });
        if (!entry_obj) return;
    }

    void* game = read_at<void*>(entry_obj, mp.o_game);
    void* gm = read_at<void*>(game, mp.o_gm);
    void* bm = read_at<void*>(gm, mp.o_bm);
    void* em = read_at<void*>(bm, mp.o_ent);
    void* world = read_at<void*>(em, mp.o_world);
    void* dict = read_at<void*>(world, mp.o_chars);
    if (!dict) return;

    if (!mp.get_values) {
        auto* dk = il2::class_of(static_cast<Il2CppObject*>(dict));
        if (!dk) return;
        mp.get_values = il2::find_method(dk, "get_Values", 0);
    }
    if (!mp.get_values) return;

    void* values = il2::invoke(mp.get_values, dict, nullptr);
    if (!values) return;
    if (!mp.get_enum) {
        auto* vk = il2::class_of(static_cast<Il2CppObject*>(values));
        if (!vk) return;
        mp.get_enum = il2::find_method(vk, "GetEnumerator", 0);
    }
    if (!mp.get_enum) return;

    stage(1);
    void* en_boxed = il2::invoke(mp.get_enum, values, nullptr);
    if (!en_boxed) return;
    stage(2);
    // struct enumerators are boxed by the runtime; some builds expect the boxed pointer,
    // some the unboxed data pointer. Probe once and remember which one yields models.
    void* en = en_boxed;
    if (!mp.move_next || !mp.get_current) {
        auto* ek = il2::class_of(static_cast<Il2CppObject*>(en_boxed));
        if (!ek) return;
        mp.move_next = il2::find_method(ek, "MoveNext", 0);
        mp.get_current = il2::find_method(ek, "get_Current", 0);
    }
    if (!mp.move_next || !mp.get_current) return;

    if (!mp.en_checked) {
        mp.en_checked = true;
        void* probe = il2::invoke(mp.move_next, en, nullptr);
        auto* more = probe ? static_cast<bool*>(il2::unbox(probe)) : nullptr;
        void* cur = (more && *more) ? il2::invoke(mp.get_current, en, nullptr) : nullptr;
        auto* ck = cur ? il2::class_of(static_cast<Il2CppObject*>(cur)) : nullptr;
        const std::string cname = ck ? il2::class_name(ck) : "";
        if (cname.find("BattleCharacterModel") == std::string::npos) {
            void* raw = il2::unbox(en_boxed);
            if (raw) {
                probe = il2::invoke(mp.move_next, raw, nullptr);
                more = probe ? static_cast<bool*>(il2::unbox(probe)) : nullptr;
                cur = (more && *more) ? il2::invoke(mp.get_current, raw, nullptr) : nullptr;
                ck = cur ? il2::class_of(static_cast<Il2CppObject*>(cur)) : nullptr;
                const std::string cname2 = ck ? il2::class_name(ck) : "";
                if (cname2.find("BattleCharacterModel") != std::string::npos) {
                    mp.en_unboxed = true;
                    en = raw;
                }
            }
        }
        Log("[m] enumerator boxed=%d (%s)", (int)!mp.en_unboxed, cname.c_str());
    }
    if (mp.en_unboxed) {
        void* raw = il2::unbox(en_boxed);
        if (raw) en = raw;
    }
    stage(3);


    actors.clear();
    stage(4);
    for (int guard = 0; guard < 512; ++guard) {
        void* boxed = il2::invoke(mp.move_next, en, nullptr);
        auto* more = boxed ? static_cast<bool*>(il2::unbox(boxed)) : nullptr;
        if (!more || !*more) break;
        void* model = il2::invoke(mp.get_current, en, nullptr);
        if (!model) continue;

        ModelActor a{};
        a.id = read_at<int>(model, mp.o_id);
        a.bot = read_at<void*>(model, mp.o_pbm) == nullptr;

        // position: TransformModel._x/_y/_z -> IPrimitiveData<float> -> _value
        void* tr = read_at<void*>(model, mp.o_tx);
        if (tr) {
            auto axis = [&](int off) -> float {
                void* d = read_at<void*>(tr, off);
                if (!d) return 0.f;
                auto* k = il2::class_of(static_cast<Il2CppObject*>(d));
                const int vo = k ? il2::field_offset(k, "_value") : -1;
                return read_at<float>(d, vo);
            };
            a.pos.x = axis(mp.o_x);
            a.pos.y = axis(mp.o_y);
            a.pos.z = axis(mp.o_z);
        }

        // health: PrivateModel.Health._health._value / _maxAmount
        void* priv = read_at<void*>(model, mp.o_private);
        void* health = priv ? read_at<void*>(priv, mp.o_health) : nullptr;
        if (health) {
            a.hp_max = read_at<int>(health, mp.o_hmax);
            void* hd = read_at<void*>(health, mp.o_hdata);
            if (hd) {
                auto* k = il2::class_of(static_cast<Il2CppObject*>(hd));
                const int vo = k ? il2::field_offset(k, "_value") : -1;
                a.hp = read_at<int>(hd, vo);
            }
        }
        actors.push_back(a);
    }


}


void refresh_models_safe() {
    __try {
        refresh_models();
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        static bool once = false;
        if (!once) { once = true; Log("[models] guarded access violation"); }
    }
}

void rebuild_chars() {    for (auto& kv : known) kv.second.seen = false;

    for_each(api.smr, [&](void* renderer) {
        Rig rig;
        auto it = rig_cache.find(renderer);
        if (it != rig_cache.end()) rig = it->second;
        else rig = rig_cache.emplace(renderer, build_rig(renderer)).first->second;
        if (!rig.ok) return;

        // LOD copies of one skeleton share the hips transform, different actors do not
        void* key = rig.b[HIPS];

        auto known_it = known.find(key);
        if (known_it != known.end()) {
            Char& c = known_it->second;
            c.seen = true;
            c.renderer = renderer;   // keep the live renderer for this skeleton
            const V3 p = pos_of(c.hips);
            const uint64_t t = GetTickCount64();
            if (c.last_ms && t > c.last_ms) {
                const float dx = p.x - c.last_pos.x, dy = p.y - c.last_pos.y, dz = p.z - c.last_pos.z;
                const float inst = std::sqrt(dx * dx + dy * dy + dz * dz) * 1000.f / float(t - c.last_ms);
                c.speed = c.speed * 0.7f + inst * 0.3f;
            }
            c.last_pos = p;
            c.last_ms = t;
            return;
        }

        Char c;
        c.renderer = renderer;
        c.hips = rig.b[HIPS];
        c.rig = rig;
        c.vis = valid(renderer);
        c.seen = true;
        c.last_pos = pos_of(c.hips);
        c.last_ms = GetTickCount64();
        known.emplace(key, c);
    });

    chars.clear();
    for (auto it = known.begin(); it != known.end();) {
        if (!it->second.seen) it = known.erase(it);
        else { chars.push_back(it->second); ++it; }
    }

    // a second skeleton of the same actor sits on top of the first one
    std::vector<Char> merged;
    std::vector<V3> spots;
    for (const Char& c : chars) {
        const V3 p = pos_of(c.hips);
        if (p.y < -100.f || p.y > 5000.f) continue;   // destroyed / garbage transform
        bool dup = false;
        for (const V3& q : spots) {
            const float dx = p.x - q.x, dy = p.y - q.y, dz = p.z - q.z;
            if (dx * dx + dy * dy + dz * dz < k_dup_radius * k_dup_radius) { dup = true; break; }
        }
        if (dup) continue;
        spots.push_back(p);
        merged.push_back(c);
    }
    chars.swap(merged);

    // bot flag: authoritative from the game model; markers are only a fallback
    for (Char& c : chars) c.npc = false;
    if (!actors.empty()) {
        for (const ModelActor& a : actors) {
            size_t best = SIZE_MAX;
            float best_d = 2.0f;
            for (size_t i = 0; i < spots.size(); ++i) {
                const float dx = spots[i].x - a.pos.x, dy = spots[i].y - a.pos.y, dz = spots[i].z - a.pos.z;
                const float d = std::sqrt(dx * dx + dy * dy + dz * dz);
                if (d < best_d) { best_d = d; best = i; }
            }
            if (best == SIZE_MAX) {
                static int missed = 0;
                if (missed < 5) { missed++; Log("[m] miss id=%d bot=%d pos=%.1f,%.1f,%.1f", a.id, (int)a.bot, a.pos.x, a.pos.y, a.pos.z); }
                continue;
            }
            chars[best].npc = a.bot;
            chars[best].hp = a.hp_max > 0 ? float(a.hp) / float(a.hp_max) : -1.f;
            static int dbg = 0;
            if (dbg < 5) {
                dbg++;
                Log("[m] ok id=%d bot=%d d=%.2f hp=%d/%d pos=%.1f,%.1f,%.1f",
                    a.id, (int)a.bot, best_d, a.hp, a.hp_max, a.pos.x, a.pos.y, a.pos.z);
            }
        }
    } else {
        // a marker hangs over exactly one actor: the nearest one gets it
        for (const V3& m : markers) {
            size_t best = SIZE_MAX;
            float best_d = 3.0f;
            for (size_t i = 0; i < chars.size(); ++i) {
                const Rig& r = chars[i].rig;
                const int hs = r.b[HEAD1] ? HEAD1 : (r.b[HEAD2] ? HEAD2 : NECK);
                if (!r.b[hs]) continue;
                const V3 h = pos_of(r.b[hs]);
                const float dx = h.x - m.x, dy = h.y - m.y, dz = h.z - m.z;
                const float d = std::sqrt(dx * dx + dy * dy + dz * dz);
                if (d < best_d) { best_d = d; best = i; }
            }
            if (best != SIZE_MAX) chars[best].npc = true;
        }
    }

    if (rig_cache.size() > 4096) rig_cache.clear();
}

void rebuild_actors() {
    markers.clear();
    for_each(api.marker, [](void* view) {
        if (void* tr = il2::invoke(api.transform_of, view, nullptr)) markers.push_back(pos_of(tr));
    });

}

} // namespace

namespace esp {

void Render(ImDrawList* dl) {
    if (!esp_enabled || !esp_npc || !dl) return;
    if (!resolve()) return;

    ImGuiIO& io = ImGui::GetIO();
    void* cam = il2::invoke(api.main, nullptr, nullptr);
    if (!cam) return;
    void* cam_tr = il2::invoke(api.transform_of, cam, nullptr);
    const V3 cam_pos = pos_of(cam_tr);
    V3 cam_fwd{0.f, 0.f, 1.f};
    if (cam_tr && api.forward) {
        void* boxed = il2::invoke(api.forward, cam_tr, nullptr);
        if (auto* f = boxed ? static_cast<V3*>(il2::unbox(boxed)) : nullptr) cam_fwd = *f;
    }

    const uint64_t now = GetTickCount64();
    uint64_t t0 = 0;
    if (now - last_chars > k_chars_ms) {
        last_chars = now;
        t0 = GetTickCount64();
        rebuild_chars();
    }
    if (now - last_actors > k_actors_ms) { last_actors = now; rebuild_actors(); }
    if (now - last_models > 2000) { last_models = now; refresh_models_safe(); }
    if (t0) {
        const uint64_t dt = GetTickCount64() - t0;
        if (dt >= 3) Log("[perf] chars %llu ms", (unsigned long long)dt);
    }


    Mat mvp;
    bool mvp_ok = false;
    if (api.world_to_camera && api.projection) {
        void* vm = il2::invoke(api.world_to_camera, cam, nullptr);
        void* pm = il2::invoke(api.projection, cam, nullptr);
        auto* v = vm ? static_cast<Mat*>(il2::unbox(vm)) : nullptr;
        auto* p = pm ? static_cast<Mat*>(il2::unbox(pm)) : nullptr;
        if (v && p) { mvp = mat_mul(*p, *v); mvp_ok = true; }
    }
    auto proj = [&](const V3& w, ImVec2& out) {
        return mvp_ok ? project_mvp(mvp, w, io.DisplaySize, out) : project(cam, w, io.DisplaySize, out);
    };

    static const ImU32 k_player = IM_COL32(150, 215, 255, 230);
    static const ImU32 k_bot = IM_COL32(255, 175, 80, 235);
    static const int edges[][2] = {
        { HIPS, SPINE2 }, { SPINE2, SPINE3 },
        { SPINE3, ARM_L0 }, { ARM_L0, ARM_L1 }, { ARM_L1, ARM_L2 }, { ARM_L2, ARM_L3 },
        { SPINE3, ARM_R0 }, { ARM_R0, ARM_R1 }, { ARM_R1, ARM_R2 }, { ARM_R2, ARM_R3 },
        { HIPS, LEG_L0 }, { LEG_L0, LEG_L1 }, { LEG_L1, LEG_L2 }, { LEG_L2, FOOT_L },
        { HIPS, LEG_R0 }, { LEG_R0, LEG_R1 }, { LEG_R1, LEG_R2 }, { LEG_R2, FOOT_R }
    };

    for (const Char& c : chars) {
        const V3 hp = pos_of(c.hips);
        const float dx = hp.x - cam_pos.x, dy = hp.y - cam_pos.y, dz = hp.z - cam_pos.z;
        const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.5f || dist > k_max_dist) continue;

        // own body sits below the camera axis; every other actor is in front of it
        if (dist < 4.5f && (dx * cam_fwd.x + dy * cam_fwd.y + dz * cam_fwd.z) / dist < 0.5f) continue;

        ImVec2 p[k_slots];
        V3 wp[k_slots]{};
        bool ok[k_slots]{};
        const bool want_skeleton = esp_skeleton && dist < 120.f;
        for (int i = 0; i < k_slots; ++i) {
            if (!c.rig.b[i]) continue;
            if (!want_skeleton && !(i == HIPS || i == HEAD1 || i == HEAD2 || i == NECK ||
                                    i == FOOT_L || i == FOOT_R))
                continue;
            wp[i] = pos_of(c.rig.b[i]);
            ok[i] = proj(wp[i], p[i]);
        }
        if (!mvp_ok && !ok[HIPS]) continue;
        const int head_slot = ok[HEAD2] ? HEAD2 : (ok[HEAD1] ? HEAD1 : (ok[NECK] ? NECK : -1));
        if (head_slot < 0 || !ok[FOOT_L] || !ok[FOOT_R] || !ok[HIPS]) continue;

        const bool bot = c.npc;
        const ImU32 color = bot ? k_bot : k_player;
        const ImVec2 head = p[head_slot];
        const float bottom = std::max(p[FOOT_L].y, p[FOOT_R].y);
        float height = bottom - head.y;
        if (height < 10.f || height > io.DisplaySize.y * 1.6f) continue;

        const float pad = height * 0.06f;
        const float top = head.y - pad;
        const float bot_y = bottom + pad;
        height = bot_y - top;
        const float cx = p[HIPS].x;

        // own body: close and centred on screen (the camera boom sits behind it)
        if (dist < 3.5f && std::abs(cx - io.DisplaySize.x * 0.5f) < io.DisplaySize.x * 0.12f)
            continue;

        // own body: the boom keeps it huge on screen; no other actor fills the frame like that
        if (height > io.DisplaySize.y * 0.62f) continue;

        if (esp_boxes) {
            const float w = height * k_box_width;
            dl->AddRect(ImVec2(cx - w * 0.5f, top), ImVec2(cx + w * 0.5f, bot_y), color, 0.f, 0, 1.4f);

            if (c.hp >= 0.f) {
                const float bar_w = 3.f;
                const float x0 = cx - w * 0.5f - bar_w - 3.f;
                dl->AddRectFilled(ImVec2(x0, top), ImVec2(x0 + bar_w, bot_y), IM_COL32(0, 0, 0, 170));
                const float hf = std::clamp(c.hp, 0.f, 1.f);
                const ImU32 hc = IM_COL32((int)(255 * (1.f - hf)), (int)(220 * hf), 60, 235);
                dl->AddRectFilled(ImVec2(x0, bot_y - (bot_y - top) * hf), ImVec2(x0 + bar_w, bot_y), hc);
            }

            if (esp_names) {
                const char* tag = bot ? "BOT" : "PLAYER";
                const ImVec2 ts = ImGui::CalcTextSize(tag);
                dl->AddText(ImVec2(cx - ts.x * 0.5f, bot_y + 2.f), color, tag);
            }
            if (esp_distance) {
                char buf[32]{};
                std::snprintf(buf, sizeof(buf), "%.0fm", dist);
                const ImVec2 ts = ImGui::CalcTextSize(buf);
                dl->AddText(ImVec2(cx - ts.x * 0.5f, top - ts.y - 2.f), color, buf);
            }
        }

        if (esp_skeleton && want_skeleton) {
            for (const auto& ed : edges) {
                const int a = ed[0], b = ed[1];
                if (!ok[a] || !ok[b]) continue;
                const float ex = p[a].x - p[b].x, ey = p[a].y - p[b].y;
                if (std::sqrt(ex * ex + ey * ey) > height * 1.6f) continue;   // bone jump
                dl->AddLine(p[a], p[b], color, 1.2f);
            }
            const int anchor = ok[HEAD1] ? HEAD1 : head_slot;
            dl->AddCircle(p[anchor], std::clamp(height * 0.05f, 4.f, 14.f), color, 16, 1.3f);
        }
    }
}

} // namespace esp
