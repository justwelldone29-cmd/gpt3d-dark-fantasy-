// C++20, il2cpp.cpp — runtime IL2CPP helpers (GameAssembly exports).
#include "il2cpp.h"
#include <windows.h>
#include <vector>
#include <cstring>

namespace il2 {

namespace {

using t_domain_get = void* (*)();
using t_domain_get_assemblies = void* (*)(void*, size_t*);
using t_assembly_get_image = void* (*)(void*);
using t_class_from_name = void* (*)(void*, const char*, const char*);
using t_class_get_method_from_name = const void* (*)(void*, const char*, int);
using t_class_get_field_from_name = void* (*)(void*, const char*);
using t_field_get_offset = int (*)(void*);
using t_runtime_invoke = void* (*)(const void*, void*, void**, void**);
using t_object_unbox = void* (*)(void*);
using t_object_get_class = void* (*)(void*);
using t_class_get_name = const char* (*)(void*);
using t_class_get_type = void* (*)(void*);
using t_type_get_object = void* (*)(void*);
using t_array_length = uintptr_t (*)(void*);
using t_thread_attach = void* (*)(void*);
using t_runtime_class_init = void (*)(void*);

t_domain_get p_domain_get = nullptr;
t_domain_get_assemblies p_domain_get_assemblies = nullptr;
t_assembly_get_image p_assembly_get_image = nullptr;
t_class_from_name p_class_from_name = nullptr;
t_class_get_method_from_name p_class_get_method_from_name = nullptr;
t_class_get_field_from_name p_class_get_field_from_name = nullptr;
t_field_get_offset p_field_get_offset = nullptr;
t_runtime_invoke p_runtime_invoke = nullptr;
t_object_unbox p_object_unbox = nullptr;
t_object_get_class p_object_get_class = nullptr;
t_class_get_name p_class_get_name = nullptr;
t_class_get_type p_class_get_type = nullptr;
t_type_get_object p_type_get_object = nullptr;
t_array_length p_array_length = nullptr;
t_thread_attach p_thread_attach = nullptr;
t_runtime_class_init p_runtime_class_init = nullptr;

std::vector<void*> g_images;
bool g_ready = false;
thread_local bool g_attached = false;

template <typename T>
bool resolve(HMODULE mod, const char* name, T& out) {
    out = reinterpret_cast<T>(GetProcAddress(mod, name));
    return out != nullptr;
}

} // namespace

bool init() {
    if (g_ready) return true;
    HMODULE ga = GetModuleHandleW(L"GameAssembly.dll");
    if (!ga) return false;

    bool ok = true;
    ok &= resolve(ga, "il2cpp_domain_get", p_domain_get);
    ok &= resolve(ga, "il2cpp_domain_get_assemblies", p_domain_get_assemblies);
    ok &= resolve(ga, "il2cpp_assembly_get_image", p_assembly_get_image);
    ok &= resolve(ga, "il2cpp_class_from_name", p_class_from_name);
    ok &= resolve(ga, "il2cpp_class_get_method_from_name", p_class_get_method_from_name);
    ok &= resolve(ga, "il2cpp_class_get_field_from_name", p_class_get_field_from_name);
    ok &= resolve(ga, "il2cpp_field_get_offset", p_field_get_offset);
    ok &= resolve(ga, "il2cpp_runtime_invoke", p_runtime_invoke);
    ok &= resolve(ga, "il2cpp_object_unbox", p_object_unbox);
    ok &= resolve(ga, "il2cpp_object_get_class", p_object_get_class);
    ok &= resolve(ga, "il2cpp_class_get_name", p_class_get_name);
    ok &= resolve(ga, "il2cpp_class_get_type", p_class_get_type);
    ok &= resolve(ga, "il2cpp_type_get_object", p_type_get_object);
    ok &= resolve(ga, "il2cpp_array_length", p_array_length);
    ok &= resolve(ga, "il2cpp_thread_attach", p_thread_attach);
    ok &= resolve(ga, "il2cpp_runtime_class_init", p_runtime_class_init);
    if (!ok) return false;

    void* domain = p_domain_get();
    if (!domain) return false;
    size_t count = 0;
    void** assemblies = static_cast<void**>(p_domain_get_assemblies(domain, &count));
    if (!assemblies) return false;
    g_images.clear();
    for (size_t i = 0; i < count && i < 4096; ++i) {
        void* image = p_assembly_get_image(assemblies[i]);
        if (image) g_images.push_back(image);
    }
    g_ready = !g_images.empty();
    return g_ready;
}

bool ready() { return g_ready; }

void ensure_thread() {
    if (g_attached || !p_thread_attach || !p_domain_get) return;
    void* domain = p_domain_get();
    if (domain) {
        p_thread_attach(domain);
        g_attached = true;
    }
}

Il2CppClass* find_class(const char* ns, const char* name) {
    if (!g_ready) return nullptr;
    for (void* image : g_images) {
        void* k = p_class_from_name(image, ns, name);
        if (k) return static_cast<Il2CppClass*>(k);
    }
    return nullptr;
}

const MethodInfo* find_method(Il2CppClass* klass, const char* name, int argc) {
    if (!klass || !p_class_get_method_from_name) return nullptr;
    return static_cast<const MethodInfo*>(p_class_get_method_from_name(klass, name, argc));
}

Il2CppClass* class_of(Il2CppObject* obj) {
    if (!obj || !p_object_get_class) return nullptr;
    return static_cast<Il2CppClass*>(p_object_get_class(obj));
}

const char* class_name(Il2CppClass* klass) {
    if (!klass || !p_class_get_name) return "";
    return p_class_get_name(klass);
}

int field_offset(Il2CppClass* klass, const char* name) {
    if (!klass || !p_class_get_field_from_name) return -1;
    void* field = p_class_get_field_from_name(klass, name);
    if (!field) return -1;
    return p_field_get_offset(field);
}

Il2CppObject* type_object(Il2CppClass* klass) {
    if (!klass || !p_class_get_type || !p_type_get_object) return nullptr;
    void* type = p_class_get_type(klass);
    if (!type) return nullptr;
    return static_cast<Il2CppObject*>(p_type_get_object(type));
}

void* invoke(const MethodInfo* method, void* obj, void** params) {
    if (!method || !p_runtime_invoke) return nullptr;
    ensure_thread();
    void* exception = nullptr;
    void* result = p_runtime_invoke(method, obj, params, &exception);
    return exception ? nullptr : result;
}

void* unbox(void* boxed) {
    if (!boxed || !p_object_unbox) return nullptr;
    return p_object_unbox(boxed);
}

uintptr_t array_length(Il2CppArray* arr) {
    if (!arr || !p_array_length) return 0;
    return p_array_length(arr);
}

void* array_at(Il2CppArray* arr, uintptr_t index) {
    if (!arr) return nullptr;
    auto* base = reinterpret_cast<uint8_t*>(arr);
    auto* vector = reinterpret_cast<void**>(base + 0x20);
    return vector[index];
}

std::string object_name(Il2CppObject* obj) {
    if (!obj) return {};
    auto* base = reinterpret_cast<uint8_t*>(obj);
    int32_t length = *reinterpret_cast<int32_t*>(base + 0x10);
    if (length <= 0 || length > 256) return {};
    const wchar_t* chars = reinterpret_cast<const wchar_t*>(base + 0x14);
    char buffer[512]{};
    int written = WideCharToMultiByte(CP_UTF8, 0, chars, length, buffer, sizeof(buffer) - 1, nullptr, nullptr);
    if (written <= 0) return {};
    buffer[written] = 0;
    return std::string(buffer);
}

} // namespace il2
