#pragma once
#include "imgui.h"

namespace esp {
void Render(ImDrawList* dl);
}
