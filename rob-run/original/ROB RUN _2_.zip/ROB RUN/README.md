# ROB RUN — internal research build

Внутренний чит для **ROB RUN** (Steam appid `4262460`): ImGui-меню + ESP, инжектится DLL в процесс игры.
Проект также содержит разведку (IL2CPP-дампы, протокол EAC) и заброшенный kernel-инжектор.

> Статус: ESP и меню работают в живой игре. Инжект под реальным EAC — открытая задача.
> Онлайн-тесты на основном аккаунте запрещены: сервер выдаёт временный бан (см. `docs/STATUS.md`).

## Что уже работает

| Фича | Состояние | Где |
|---|---|---|
| ImGui-меню (D3D11 Present hook) | работает | `client/internal/hook/present.cpp`, `client/internal/menu/ui.cpp` |
| Виртуальный курсор + ввод мышью | работает | `hook/present.cpp` |
| ESP-боксы по костям скелета | работает | `client/internal/features/esp.cpp` |
| Скелет (spine/arms/legs/head) | работает | `features/esp.cpp` |
| Метки `PLAYER` / `BOT` | частично (боты — по 3D-маркерам и `NpcView`) | `features/esp.cpp` |
| HP-бар | заглушён (`Image.fillAmount` у HUD-оверлея всегда 0) | `features/esp.cpp` |
| Инжект под EAC | нет | `driver/`, `client/frida/` |

## Структура

```
ROB RUN/
├─ client/
│  ├─ internal/          # сама DLL (C++20, MSVC, без зависимостей кроме WinAPI)
│  │  ├─ dllmain.cpp     # DllMain + поток инициализации
│  │  ├─ hook/           # Present hook, окно, ввод
│  │  ├─ menu/           # ImGui-меню, шрифты, иконки
│  │  ├─ features/       # IL2CPP-биндинги и ESP
│  │  ├─ imgui/          # Dear ImGui 1.90.7
│  │  └─ build.bat       # сборка internal.dll
│  └─ frida/             # harness: спавн игры, заглушки EOS AC, загрузка DLL
├─ driver/               # ТОЛЬКО исходники kernel-инжектора, драйверов нет (см. driver/README.md)
├─ dump/classes.jsonl    # 20 282 IL2CPP-класса (name/namespace/fields/methods)
├─ recon/                # ledger.md (журнал разведки), drivers.md (разбор BYOVD)
└─ docs/                 # HANDOFF / ARCHITECTURE / IL2CPP-MAP / BUILD / STATUS
```

## Быстрый старт (текущий путь — без EAC)

1. Закрыть игру и CS2.
2. Собрать DLL: `client\internal\build.bat` → `BUILD_OK`.
3. Запустить harness (Steam должен быть запущен, аккаунт — **не основной**):

```powershell
python "C:\Users\sss\Desktop\ROB RUN\client\frida\run_menu_test.py" 1800
```

4. Игра стартует, через 12 с грузится `internal.dll`. `Insert` — меню.

Подробности: `docs/BUILD.md`.

## Документация

- `docs/HANDOFF.md` — **начинать отсюда**, если проект передаётся другому инженеру/ИИ: контекст, ограничения, задачи, грабли.
- `docs/ARCHITECTURE.md` — как устроена DLL: хук, IL2CPP, конвейер ESP, ввод.
- `docs/IL2CPP-MAP.md` — какие классы/методы/поля и имена костей используются и что перепроверять на новом билде.
- `docs/BUILD.md` — сборка, harness, логи, типовые ошибки.
- `docs/STATUS.md` — текущее состояние, бан, роадмап, риски.
- `driver/README.md` — почему kernel-путь закрыт.
- `CHANGELOG.md` — что менялось по итерациям ESP.

## Ограничения

- **EAC.** Игра ходит на сервер с EOS Anti-Cheat. Клиентские заглушки EAC позволяют дойти до матча, но сервер это видит: кик `403` и временный бан аккаунта.
- **BYOVD Разрешен.** `gdrv.sys` уже дал BSOD `0x3B` в `gdrv+0x29F4`; драйвер грузить но другой.
- **CS2.** Не запускать kernel-тесты, пока запущен CS2 на этой машине.
- Сборка требует закрытой игры: `internal.dll` залочен, пока загружен.

## Правовое

Код предназначен для исследования защиты собственного клиента и оффлайн-тестов. Использование в онлайн-игре нарушает правила сервиса и приводит к бану аккаунта — это ожидаемый и уже подтверждённый исход.
